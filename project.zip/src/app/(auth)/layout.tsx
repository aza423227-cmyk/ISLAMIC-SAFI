import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/session";

export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const user = await getSessionUser();
  if (user) redirect("/");
  return <div className="min-h-dvh bg-app">{children}</div>;
}
