import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { notifications } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { readJson, unauthorized } from "@/lib/http";
import { getNotifications } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const list = await getNotifications(viewer.id);
  return NextResponse.json({
    notifications: list,
    unread: list.filter((item) => !item.read).length,
  });
}

export async function PATCH(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  if (typeof body.id === "string" && body.id) {
    await db
      .update(notifications)
      .set({ read: true })
      .where(and(eq(notifications.id, body.id), eq(notifications.userId, viewer.id)));
  } else {
    await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.userId, viewer.id));
  }
  return NextResponse.json({ ok: true });
}
