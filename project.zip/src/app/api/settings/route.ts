import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { userSettings } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { readJson, unauthorized } from "@/lib/http";

const allowedLanguages = ["en", "ar", "fr", "tr", "ur"];
const allowedThemes = ["light", "dark", "system"];
const allowedPrivacy = ["everyone", "followers", "noone"];

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const existing = await db.query.userSettings.findFirst({
    where: eq(userSettings.userId, viewer.id),
  });
  return NextResponse.json({ settings: existing ?? null });
}

export async function PATCH(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);

  const values: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof body.language === "string" && allowedLanguages.includes(body.language)) {
    values.language = body.language;
  }
  if (typeof body.theme === "string" && allowedThemes.includes(body.theme)) {
    values.theme = body.theme;
  }
  if (typeof body.prayerMethod === "string" && /^\d{1,2}$/.test(body.prayerMethod)) {
    values.prayerMethod = body.prayerMethod;
  }
  if (typeof body.latitude === "string") values.latitude = body.latitude.slice(0, 20);
  if (typeof body.longitude === "string") values.longitude = body.longitude.slice(0, 20);
  if (typeof body.city === "string") values.city = body.city.slice(0, 80);
  if (typeof body.country === "string") values.country = body.country.slice(0, 80);
  if (typeof body.remindersEnabled === "boolean") values.remindersEnabled = body.remindersEnabled;
  if (typeof body.reminderMinutes === "number") {
    values.reminderMinutes = Math.min(Math.max(Math.round(body.reminderMinutes), 0), 60);
  }
  if (typeof body.tasbihTotal === "number") {
    values.tasbihTotal = Math.max(0, Math.round(body.tasbihTotal));
  }
  if (typeof body.tasbihTarget === "number") {
    values.tasbihTarget = Math.min(Math.max(Math.round(body.tasbihTarget), 1), 10000);
  }
  if (typeof body.messagePrivacy === "string" && allowedPrivacy.includes(body.messagePrivacy)) {
    values.messagePrivacy = body.messagePrivacy;
  }
  if (typeof body.activityStatus === "boolean") values.activityStatus = body.activityStatus;
  if (typeof body.mediaFilterStrict === "boolean") values.mediaFilterStrict = body.mediaFilterStrict;

  const [settings] = await db
    .insert(userSettings)
    .values({ userId: viewer.id, ...values })
    .onConflictDoUpdate({ target: userSettings.userId, set: values })
    .returning();

  return NextResponse.json({ settings });
}
