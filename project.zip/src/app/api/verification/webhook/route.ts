import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { user } from "@/lib/schema";
import { eq } from "drizzle-orm";
import { getPlan, recordPayment, verifyWebhookSignature } from "@/lib/verification";

export async function POST(request: Request) {
  const raw = await request.text();
  const signature = request.headers.get("x-razorpay-signature") ?? "";
  if (!verifyWebhookSignature(raw, signature)) {
    return NextResponse.json({ error: "errors.forbidden" }, { status: 401 });
  }

  let payload: {
    event?: string;
    payload?: {
      payment?: { entity?: { id?: string; order_id?: string; notes?: Record<string, string> } };
      order?: { entity?: { id?: string; notes?: Record<string, string> } };
    };
  };
  try {
    payload = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "errors.invalid" }, { status: 400 });
  }

  const payment = payload.payload?.payment?.entity;
  const order = payload.payload?.order?.entity;
  const orderId = payment?.order_id ?? order?.id;
  const notes = payment?.notes ?? order?.notes;
  const plan = notes?.planId ? getPlan(notes.planId) : null;
  const userId = notes?.userId;

  if (!orderId || !plan || !userId) {
    return NextResponse.json({ received: true });
  }
  const exists = await db.query.user.findFirst({ where: eq(user.id, userId) });
  if (!exists) return NextResponse.json({ received: true });

  if (payload.event === "payment.captured" || payload.event === "order.paid") {
    await recordPayment({
      userId,
      plan,
      status: "captured",
      provider: "razorpay",
      providerOrderId: orderId,
      providerPaymentId: payment?.id ?? null,
    });
  }

  return NextResponse.json({ received: true });
}
