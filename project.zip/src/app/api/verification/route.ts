import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { user } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import {
  createRazorpayOrder,
  currentVerification,
  getPlan,
  razorpayConfigured,
  recordPayment,
  verificationPlans,
} from "@/lib/verification";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const row = await db.query.user.findFirst({ where: eq(user.id, viewer.id) });
  const latest = await currentVerification(viewer.id);
  const active = Boolean(
    row?.verified && (!row.verifiedUntil || new Date(row.verifiedUntil).getTime() > Date.now()),
  );
  return NextResponse.json({
    plans: verificationPlans.map(({ id, amount, currency, interval, label }) => ({
      id,
      amount,
      currency,
      interval,
      label,
    })),
    configured: razorpayConfigured(),
    active,
    verifiedUntil: row?.verifiedUntil ?? latest?.endsAt ?? null,
    payment: latest
      ? { id: latest.id, planId: latest.planId, status: latest.status, endedAt: latest.endsAt }
      : null,
  });
}

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const planId = str(body.planId, 40);
  const plan = getPlan(planId);
  if (!plan) return badRequest("errors.invalid");

  if (!razorpayConfigured()) {
    const record = await recordPayment({
      userId: viewer.id,
      plan,
      status: "captured",
      provider: "sandbox",
      providerPaymentId: `sandbox_${viewer.id}_${Date.now()}`,
    });
    return NextResponse.json({
      mode: "sandbox",
      active: true,
      verifiedUntil: record?.endsAt ?? null,
    });
  }

  try {
    const orderId = await createRazorpayOrder(plan, viewer.id);
    await recordPayment({
      userId: viewer.id,
      plan,
      status: "created",
      provider: "razorpay",
      providerOrderId: orderId,
    });
    return NextResponse.json({
      mode: "razorpay",
      orderId,
      keyId: process.env.RAZORPAY_KEY_ID,
      amount: plan.amount * 100,
      currency: plan.currency,
      planId: plan.id,
    });
  } catch {
    return NextResponse.json({ error: "errors.paymentFailed" }, { status: 502 });
  }
}
