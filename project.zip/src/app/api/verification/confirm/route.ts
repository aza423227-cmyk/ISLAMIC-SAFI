import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { verificationPayments } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import { getPlan, recordPayment, verifyRazorpaySignature } from "@/lib/verification";

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const orderId = str(body.razorpay_order_id, 120);
  const paymentId = str(body.razorpay_payment_id, 120);
  const signature = str(body.razorpay_signature, 200);
  if (!orderId || !paymentId || !signature) return badRequest("errors.required");

  const payment = await db.query.verificationPayments.findFirst({
    where: and(
      eq(verificationPayments.providerOrderId, orderId),
      eq(verificationPayments.userId, viewer.id),
    ),
  });
  if (!payment) return badRequest("errors.invalid");
  const plan = getPlan(payment.planId);
  if (!plan) return badRequest("errors.invalid");

  if (!verifyRazorpaySignature(orderId, paymentId, signature)) {
    return NextResponse.json({ error: "errors.paymentFailed" }, { status: 400 });
  }

  const record = await recordPayment({
    userId: viewer.id,
    plan,
    status: "captured",
    provider: "razorpay",
    providerOrderId: orderId,
    providerPaymentId: paymentId,
  });

  return NextResponse.json({ active: true, verifiedUntil: record?.endsAt ?? null });
}
