import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { unauthorized } from "@/lib/http";
import { searchUsers } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? "").trim();
  if (!q) return NextResponse.json({ users: [] });
  const users = await searchUsers(q, user.id);
  return NextResponse.json({ users });
}
