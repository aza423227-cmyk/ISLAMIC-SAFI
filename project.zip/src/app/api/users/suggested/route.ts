import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { unauthorized } from "@/lib/http";
import { suggestedUsers } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const users = await suggestedUsers(user.id, 6);
  return NextResponse.json({ users });
}
