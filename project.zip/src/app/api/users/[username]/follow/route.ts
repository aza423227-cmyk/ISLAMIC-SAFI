import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { blockedUsers, follows, notifications, user } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";

export async function POST(
  _request: Request,
  context: { params: Promise<{ username: string }> },
) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const { username } = await context.params;
  const target = await db.query.user.findFirst({
    where: sql`lower(${user.username}) = lower(${username})`,
  });
  if (!target) return apiError("errors.notFound", 404);
  if (target.id === viewer.id) return apiError("errors.forbidden", 403);

  const blocked = await db.query.blockedUsers.findFirst({
    where: and(eq(blockedUsers.userId, target.id), eq(blockedUsers.blockedId, viewer.id)),
  });
  if (blocked) return apiError("errors.forbidden", 403);

  const existing = await db.query.follows.findFirst({
    where: and(eq(follows.followerId, viewer.id), eq(follows.followingId, target.id)),
  });

  if (existing) {
    await db
      .delete(follows)
      .where(and(eq(follows.followerId, viewer.id), eq(follows.followingId, target.id)));
  } else {
    await db.insert(follows).values({ followerId: viewer.id, followingId: target.id });
    await db.insert(notifications).values({
      userId: target.id,
      actorId: viewer.id,
      type: "follow",
    });
  }

  const result = await db.execute(
    sql`select count(*)::int as count from follows where following_id = ${target.id}`,
  );
  return NextResponse.json({
    following: !existing,
    followers: (result.rows[0] as { count: number }).count,
  });
}
