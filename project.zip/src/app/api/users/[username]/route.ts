import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";
import { getPosts, getProfile, suggestedUsers } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ username: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { username } = await context.params;
  const profile = await getProfile(username, user.id);
  if (!profile) return apiError("errors.notFound", 404);
  if (profile.blocked) return apiError("errors.forbidden", 403);

  const isSelf = profile.id === user.id;
  const canView = !profile.is_private || isSelf || profile.is_following;
  const posts = canView
    ? await getPosts({ viewerId: user.id, scope: "profile", profileId: profile.id })
    : [];
  const suggestions = isSelf || !canView ? [] : await suggestedUsers(user.id, 5);

  return NextResponse.json({
    profile,
    posts,
    isSelf,
    canView,
    suggestions,
    viewerId: user.id,
  });
}
