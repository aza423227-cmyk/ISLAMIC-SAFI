import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { media, user } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import { moderateText } from "@/lib/moderation";

export async function PATCH(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();

  const body = await readJson(request);
  const patch: Record<string, unknown> = { updatedAt: new Date() };

  if (typeof body.name === "string") {
    const name = str(body.name, 60);
    if (!name) return badRequest("errors.required");
    const check = moderateText(name);
    if (!check.ok) return badRequest("errors.moderation");
    patch.name = name;
  }
  if (typeof body.bio === "string") {
    const bio = str(body.bio, 160);
    const check = moderateText(bio);
    if (!check.ok) return badRequest("errors.moderation");
    patch.bio = bio;
  }
  if (typeof body.website === "string") {
    const website = str(body.website, 120);
    if (website && !/^https?:\/\/[^\s]+$/i.test(website)) return badRequest("errors.invalid");
    patch.website = website;
  }
  if (typeof body.isPrivate === "boolean") patch.isPrivate = body.isPrivate;

  if (typeof body.imageId === "string" && body.imageId) {
    const asset = await db.query.media.findFirst({
      where: and(eq(media.id, body.imageId), eq(media.ownerId, viewer.id)),
    });
    if (!asset || asset.kind !== "image") return badRequest("errors.invalid");
    patch.image = `/api/media/${asset.id}`;
  }
  if (body.removeImage === true) patch.image = null;

  const [updated] = await db
    .update(user)
    .set(patch)
    .where(eq(user.id, viewer.id))
    .returning({
      id: user.id,
      name: user.name,
      username: user.username,
      displayUsername: user.displayUsername,
      image: user.image,
      bio: user.bio,
      website: user.website,
      isPrivate: user.isPrivate,
      verified: user.verified,
      verifiedUntil: user.verifiedUntil,
    });

  return NextResponse.json({ user: updated });
}
