import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { media, notifications, posts } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import { isContentCategory, moderateText } from "@/lib/moderation";
import { getPostById } from "@/lib/queries";

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const body = await readJson(request);
  const caption = str(body.caption, 2200);
  const mediaId = str(body.mediaId, 64);
  const category = str(body.category, 20) || "islamic";
  const isReel = body.isReel === true;
  const location = str(body.location, 120);

  if (!mediaId) return badRequest("errors.required");
  if (!isContentCategory(category)) return badRequest("errors.moderation");

  const moderation = moderateText(caption);
  if (!moderation.ok) return badRequest("errors.moderation");

  const asset = await db.query.media.findFirst({
    where: and(eq(media.id, mediaId), eq(media.ownerId, user.id)),
  });
  if (!asset) return badRequest("errors.required");
  if (asset.kind === "audio") return badRequest("errors.moderation");
  if (isReel && asset.kind !== "video") return badRequest("errors.invalid");

  const [post] = await db
    .insert(posts)
    .values({
      userId: user.id,
      mediaId: asset.id,
      caption,
      kind: asset.kind,
      category,
      isReel: isReel && asset.kind === "video",
      location: location || null,
    })
    .returning({ id: posts.id });

  await db.execute(sql`
    insert into notifications (user_id, actor_id, type, post_id)
    select f.follower_id, ${user.id}, 'post', ${post.id}
    from follows f where f.following_id = ${user.id}
  `);

  const created = await getPostById(post.id, user.id);
  return NextResponse.json({ post: created });
}
