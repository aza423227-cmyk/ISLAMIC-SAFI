import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { saves, posts } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";

export async function POST(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const post = await db.query.posts.findFirst({ where: eq(posts.id, id) });
  if (!post) return apiError("errors.notFound", 404);

  const existing = await db.query.saves.findFirst({
    where: and(eq(saves.postId, id), eq(saves.userId, user.id)),
  });
  if (existing) {
    await db.delete(saves).where(and(eq(saves.postId, id), eq(saves.userId, user.id)));
  } else {
    await db.insert(saves).values({ postId: id, userId: user.id });
  }
  return NextResponse.json({ saved: !existing });
}
