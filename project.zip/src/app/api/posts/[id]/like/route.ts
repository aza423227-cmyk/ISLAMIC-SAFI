import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { notifications, postLikes, posts } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";

export async function POST(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const post = await db.query.posts.findFirst({ where: eq(posts.id, id) });
  if (!post) return apiError("errors.notFound", 404);

  const existing = await db.query.postLikes.findFirst({
    where: and(eq(postLikes.postId, id), eq(postLikes.userId, user.id)),
  });

  if (existing) {
    await db
      .delete(postLikes)
      .where(and(eq(postLikes.postId, id), eq(postLikes.userId, user.id)));
  } else {
    await db.insert(postLikes).values({ postId: id, userId: user.id });
    if (post.userId !== user.id) {
      await db.insert(notifications).values({
        userId: post.userId,
        actorId: user.id,
        type: "like",
        postId: id,
      });
    }
  }

  const result = await db.execute(
    sql`select count(*)::int as count from post_likes where post_id = ${id}`,
  );
  const count = (result.rows[0] as { count: number }).count;
  return NextResponse.json({ liked: !existing, likes: count });
}
