import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { comments, notifications, posts } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, badRequest, readJson, str, unauthorized } from "@/lib/http";
import { moderateText } from "@/lib/moderation";
import { getComments } from "@/lib/queries";

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const list = await getComments(id);
  return NextResponse.json({ comments: list });
}

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const post = await db.query.posts.findFirst({ where: eq(posts.id, id) });
  if (!post) return apiError("errors.notFound", 404);
  if (post.commentsDisabled) return badRequest("errors.forbidden");

  const body = await readJson(request);
  const text = str(body.body, 1000);
  if (!text) return badRequest("errors.required");
  const moderation = moderateText(text);
  if (!moderation.ok) return badRequest("errors.moderation");

  const [comment] = await db
    .insert(comments)
    .values({ postId: id, userId: user.id, body: text })
    .returning();

  if (post.userId !== user.id) {
    await db.insert(notifications).values({
      userId: post.userId,
      actorId: user.id,
      type: "comment",
      postId: id,
    });
  }

  return NextResponse.json({
    comment: {
      ...comment,
      created_at: comment.createdAt,
      name: user.name,
      username: user.username,
      display_username: user.displayUsername,
      image: user.image,
      verified: user.verified ?? false,
      user_id: user.id,
    },
  });
}
