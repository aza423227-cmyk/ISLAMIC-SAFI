import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { posts, media } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, readJson, str, unauthorized } from "@/lib/http";
import { moderateText } from "@/lib/moderation";

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const post = await db.query.posts.findFirst({ where: eq(posts.id, id) });
  if (!post) return apiError("errors.notFound", 404);
  if (post.userId !== user.id) return apiError("errors.forbidden", 403);
  await db.delete(posts).where(eq(posts.id, id));
  if (post.mediaId) await db.delete(media).where(eq(media.id, post.mediaId));
  return NextResponse.json({ ok: true });
}

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const post = await db.query.posts.findFirst({ where: eq(posts.id, id) });
  if (!post) return apiError("errors.notFound", 404);
  if (post.userId !== user.id) return apiError("errors.forbidden", 403);

  const body = await readJson(request);
  const caption = str(body.caption, 2200);
  const moderation = moderateText(caption);
  if (!moderation.ok) return apiError("errors.moderation", 400);
  const [updated] = await db
    .update(posts)
    .set({ caption, commentsDisabled: body.commentsDisabled === true })
    .where(eq(posts.id, id))
    .returning();
  return NextResponse.json({ post: updated });
}

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const { getPostById } = await import("@/lib/queries");
  const post = await getPostById(id, user.id);
  if (!post) return apiError("errors.notFound", 404);
  return NextResponse.json({ post });
}
