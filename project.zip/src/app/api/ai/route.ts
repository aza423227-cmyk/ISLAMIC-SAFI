import { NextResponse } from "next/server";
import { desc, eq, asc } from "drizzle-orm";
import { db } from "@/lib/db";
import { aiChats } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import { isLocale, type Locale } from "@/lib/i18n";
import { answerIslamicQuestion } from "@/lib/islamic-knowledge";
import { moderateText } from "@/lib/moderation";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const history = await db
    .select()
    .from(aiChats)
    .where(eq(aiChats.userId, viewer.id))
    .orderBy(asc(aiChats.createdAt))
    .limit(80);
  return NextResponse.json({ messages: history });
}

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const question = str(body.question, 1200);
  const locale: Locale = isLocale(body.locale) ? body.locale : "en";
  if (!question) return badRequest("errors.required");
  const moderation = moderateText(question);
  if (!moderation.ok) return badRequest("errors.moderation");

  const { answer, id } = answerIslamicQuestion(question, locale);

  const inserted = await db
    .insert(aiChats)
    .values([
      { userId: viewer.id, role: "user", content: question },
      { userId: viewer.id, role: "assistant", content: answer },
    ])
    .returning();

  const last = await db
    .select({ id: aiChats.id })
    .from(aiChats)
    .where(eq(aiChats.userId, viewer.id))
    .orderBy(desc(aiChats.createdAt))
    .limit(1);

  return NextResponse.json({
    messages: inserted,
    topic: id,
    latestId: last[0]?.id ?? null,
  });
}

export async function DELETE() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  await db.delete(aiChats).where(eq(aiChats.userId, viewer.id));
  return NextResponse.json({ cleared: true });
}
