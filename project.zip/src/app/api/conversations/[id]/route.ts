import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { conversationParticipants, conversations } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const { id } = await context.params;
  const participant = await db.query.conversationParticipants.findFirst({
    where: (table, { and, eq: equals }) =>
      and(equals(table.conversationId, id), equals(table.userId, viewer.id)),
  });
  if (!participant) return apiError("errors.notFound", 404);
  await db.delete(conversations).where(eq(conversations.id, id));
  await db
    .delete(conversationParticipants)
    .where(eq(conversationParticipants.conversationId, id));
  return NextResponse.json({ deleted: true });
}
