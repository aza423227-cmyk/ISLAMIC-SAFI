import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import {
  conversationParticipants,
  conversations,
  media,
  messages,
  notifications,
  user,
} from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, badRequest, readJson, str, unauthorized } from "@/lib/http";
import { moderateText } from "@/lib/moderation";
import { getMessages } from "@/lib/queries";

export const dynamic = "force-dynamic";

async function ensureParticipant(conversationId: string, userId: string) {
  return db.query.conversationParticipants.findFirst({
    where: and(
      eq(conversationParticipants.conversationId, conversationId),
      eq(conversationParticipants.userId, userId),
    ),
  });
}

export async function GET(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const { id } = await context.params;
  const participant = await ensureParticipant(id, viewer.id);
  if (!participant) return apiError("errors.notFound", 404);

  const { searchParams } = new URL(request.url);
  const after = searchParams.get("after");

  const all = await getMessages(id, 120);
  const filtered = after
    ? all.filter((message) => new Date(message.created_at).getTime() > new Date(after).getTime())
    : all;

  const otherRows = await db.execute(sql`
    select u.id, u.name, u.username, u.display_username, u.image, u.verified
    from conversation_participants cp join "user" u on u.id = cp.user_id
    where cp.conversation_id = ${id} and cp.user_id <> ${viewer.id}
    limit 1
  `);

  await db
    .update(conversationParticipants)
    .set({ lastReadAt: new Date() })
    .where(
      and(
        eq(conversationParticipants.conversationId, id),
        eq(conversationParticipants.userId, viewer.id),
      ),
    );

  return NextResponse.json({
    messages: filtered,
    other: otherRows.rows[0] ?? null,
    viewerId: viewer.id,
  });
}

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const { id } = await context.params;
  const participant = await ensureParticipant(id, viewer.id);
  if (!participant) return apiError("errors.notFound", 404);

  const body = await readJson(request);
  const text = str(body.body, 2000);
  const mediaId = str(body.mediaId, 64);
  const kind = ["text", "image", "video", "voice"].includes(String(body.kind))
    ? String(body.kind)
    : "text";
  const durationSec =
    typeof body.durationSec === "number"
      ? Math.min(Math.max(Math.round(body.durationSec), 0), 600)
      : null;

  if (kind === "text" && !text) return badRequest("errors.required");
  if (kind !== "text" && !mediaId) return badRequest("errors.required");

  const moderation = moderateText(text);
  if (!moderation.ok) return badRequest("errors.moderation");

  if (mediaId) {
    const asset = await db.query.media.findFirst({
      where: and(eq(media.id, mediaId), eq(media.ownerId, viewer.id)),
    });
    if (!asset) return badRequest("errors.invalid");
    if (kind === "voice" && asset.kind !== "audio") return badRequest("errors.moderation");
    if (kind !== "voice" && asset.kind === "audio") return badRequest("errors.moderation");
  }

  const [message] = await db
    .insert(messages)
    .values({
      conversationId: id,
      senderId: viewer.id,
      body: text,
      mediaId: mediaId || null,
      kind,
      durationSec,
    })
    .returning();

  await db
    .update(conversations)
    .set({ lastMessageAt: new Date() })
    .where(eq(conversations.id, id));

  const others = await db.execute(sql`
    select user_id from conversation_participants
    where conversation_id = ${id} and user_id <> ${viewer.id}
  `);
  for (const row of others.rows as { user_id: string }[]) {
    await db.insert(notifications).values({
      userId: row.user_id,
      actorId: viewer.id,
      type: "message",
      conversationId: id,
    });
  }

  const sender = await db.query.user.findFirst({ where: eq(user.id, viewer.id) });

  return NextResponse.json({
    message: {
      id: message.id,
      conversation_id: message.conversationId,
      sender_id: message.senderId,
      body: message.body,
      media_id: message.mediaId,
      mime: null,
      kind: message.kind,
      duration_sec: message.durationSec,
      created_at: message.createdAt,
      sender_name: sender?.name ?? viewer.name,
      sender_image: sender?.image ?? viewer.image,
    },
  });
}
