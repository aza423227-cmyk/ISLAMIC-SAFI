import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import {
  blockedUsers,
  conversationParticipants,
  conversations,
  notifications,
  user,
  userSettings,
} from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, badRequest, readJson, str, unauthorized } from "@/lib/http";
import { findDirectConversation, getConversations } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const list = await getConversations(viewer.id);
  return NextResponse.json({ conversations: list });
}

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const targetId = str(body.userId, 64);
  if (!targetId || targetId === viewer.id) return badRequest("errors.invalid");

  const target = await db.query.user.findFirst({ where: eq(user.id, targetId) });
  if (!target) return apiError("errors.notFound", 404);

  const blocked = await db.query.blockedUsers.findFirst({
    where: and(eq(blockedUsers.userId, targetId), eq(blockedUsers.blockedId, viewer.id)),
  });
  if (blocked) return apiError("errors.forbidden", 403);

  const existing = await findDirectConversation(viewer.id, targetId);
  if (existing) return NextResponse.json({ conversationId: existing });

  const settings = await db.query.userSettings.findFirst({
    where: eq(userSettings.userId, targetId),
  });
  if (settings?.messagePrivacy === "noone") return apiError("errors.forbidden", 403);
  if (settings?.messagePrivacy === "followers") {
    const followsViewer = await db.execute(sql`
      select 1 from follows where follower_id = ${targetId} and following_id = ${viewer.id} limit 1
    `);
    if (followsViewer.rows.length === 0) return apiError("errors.forbidden", 403);
  }

  const [conversation] = await db.insert(conversations).values({}).returning();
  await db.insert(conversationParticipants).values([
    { conversationId: conversation.id, userId: viewer.id },
    { conversationId: conversation.id, userId: targetId },
  ]);
  await db.insert(notifications).values({
    userId: targetId,
    actorId: viewer.id,
    type: "message",
    conversationId: conversation.id,
  });

  return NextResponse.json({ conversationId: conversation.id });
}
