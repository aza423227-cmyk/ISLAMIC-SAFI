import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { unauthorized } from "@/lib/http";
import { getPosts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const { searchParams } = new URL(request.url);
  const scope = searchParams.get("scope") ?? "home";
  const offset = Number(searchParams.get("offset") ?? "0");
  const profileId = searchParams.get("profileId") ?? undefined;

  const allowed = ["home", "explore", "reels", "profile", "saved"] as const;
  type Scope = (typeof allowed)[number];
  const safeScope: Scope = (allowed as readonly string[]).includes(scope)
    ? (scope as Scope)
    : "home";

  const posts = await getPosts({
    viewerId: user.id,
    scope: safeScope,
    profileId,
    offset: Number.isFinite(offset) ? Math.max(0, offset) : 0,
  });
  return NextResponse.json({ posts });
}
