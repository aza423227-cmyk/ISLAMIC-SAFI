import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { stories, storyViews } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, unauthorized } from "@/lib/http";

export async function POST(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { id } = await context.params;
  const story = await db.query.stories.findFirst({ where: eq(stories.id, id) });
  if (!story) return apiError("errors.notFound", 404);

  await db.insert(storyViews).values({ storyId: id, viewerId: user.id }).onConflictDoNothing();
  const result = await db.execute(
    sql`select count(*)::int as count from story_views where story_id = ${id}`,
  );
  const count = (result.rows[0] as { count: number }).count;
  return NextResponse.json({ viewers: count });
}
