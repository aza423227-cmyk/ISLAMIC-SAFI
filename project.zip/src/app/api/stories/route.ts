import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { media, stories } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";
import { moderateText } from "@/lib/moderation";
import { getStoryGroups } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const groups = await getStoryGroups(user.id);
  return NextResponse.json({ groups, viewerId: user.id });
}

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const body = await readJson(request);
  const mediaId = str(body.mediaId, 64);
  const caption = str(body.caption, 300);
  if (!mediaId) return badRequest("errors.required");
  const moderation = moderateText(caption);
  if (!moderation.ok) return badRequest("errors.moderation");

  const asset = await db.query.media.findFirst({
    where: and(eq(media.id, mediaId), eq(media.ownerId, user.id)),
  });
  if (!asset || asset.kind === "audio") return badRequest("errors.moderation");

  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const [story] = await db
    .insert(stories)
    .values({ userId: user.id, mediaId, caption, expiresAt })
    .returning();
  return NextResponse.json({ story });
}
