import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { user } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";

export async function DELETE(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const password = str(body.password, 200);
  if (!password) return badRequest("errors.required");

  try {
    await auth.api.deleteUser({
      body: { password },
      headers: await headers(),
    });
  } catch {
    return badRequest("auth.invalidCredentials");
  }

  await db.delete(user).where(eq(user.id, viewer.id)).catch(() => undefined);
  return NextResponse.json({ deleted: true });
}
