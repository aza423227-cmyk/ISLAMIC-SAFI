import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { reports } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";

const TARGETS = ["post", "user", "message", "comment"];

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const targetType = str(body.targetType, 20);
  const targetId = str(body.targetId, 64);
  const reason = str(body.reason, 500);
  if (!TARGETS.includes(targetType) || !targetId || !reason) {
    return badRequest("errors.required");
  }
  await db.insert(reports).values({
    reporterId: viewer.id,
    targetType,
    targetId,
    reason,
  });
  return NextResponse.json({ reported: true });
}
