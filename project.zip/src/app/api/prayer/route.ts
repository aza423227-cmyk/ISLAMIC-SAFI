import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { badRequest, unauthorized } from "@/lib/http";

export const revalidate = 0;

export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const { searchParams } = new URL(request.url);
  const lat = Number(searchParams.get("lat"));
  const lng = Number(searchParams.get("lng"));
  const method = searchParams.get("method") ?? "2";
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return badRequest("errors.required");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 9000);
  try {
    const today = new Date();
    const dateParam = `${String(today.getDate()).padStart(2, "0")}-${String(today.getMonth() + 1).padStart(2, "0")}-${today.getFullYear()}`;
    const url = `https://api.aladhan.com/v1/timings/${dateParam}?latitude=${lat}&longitude=${lng}&method=${encodeURIComponent(method)}&school=0`;
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
      cache: "no-store",
    });
    if (!response.ok) return NextResponse.json({ error: "errors.generic" }, { status: 502 });
    const json = (await response.json()) as {
      data?: {
        timings: Record<string, string>;
        date: { readable: string; gregorian: { date: string } };
        meta: { timezone: string; method: { name: string } };
      };
    };
    if (!json.data) return NextResponse.json({ error: "errors.generic" }, { status: 502 });

    const timings = json.data.timings;
    const clean = (key: string) => (timings[key] ?? "").split(" ")[0];
    return NextResponse.json({
      date: json.data.date.readable,
      isoDate: json.data.date.gregorian.date,
      timezone: json.data.meta.timezone,
      method: json.data.meta.method.name,
      timings: {
        Fajr: clean("Fajr"),
        Sunrise: clean("Sunrise"),
        Dhuhr: clean("Dhuhr"),
        Asr: clean("Asr"),
        Maghrib: clean("Maghrib"),
        Isha: clean("Isha"),
      },
    });
  } catch {
    return NextResponse.json({ error: "errors.generic" }, { status: 502 });
  } finally {
    clearTimeout(timeout);
  }
}
