import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { blockedUsers, user } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { badRequest, readJson, str, unauthorized } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const result = await db.execute(sql`
    select u.id, u.name, u.username, u.display_username, u.image, u.verified
    from blocked_users b join "user" u on u.id = b.blocked_id
    where b.user_id = ${viewer.id}
    order by b.created_at desc
  `);
  return NextResponse.json({ users: result.rows });
}

export async function POST(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const body = await readJson(request);
  const userId = str(body.userId, 64);
  if (!userId || userId === viewer.id) return badRequest("errors.invalid");
  const target = await db.query.user.findFirst({ where: eq(user.id, userId) });
  if (!target) return badRequest("errors.notFound");
  await db
    .insert(blockedUsers)
    .values({ userId: viewer.id, blockedId: userId })
    .onConflictDoNothing();
  return NextResponse.json({ blocked: true });
}

export async function DELETE(request: Request) {
  const viewer = await getSessionUser();
  if (!viewer) return unauthorized();
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId") ?? "";
  if (!userId) return badRequest("errors.required");
  await db
    .delete(blockedUsers)
    .where(and(eq(blockedUsers.userId, viewer.id), eq(blockedUsers.blockedId, userId)));
  return NextResponse.json({ blocked: false });
}
