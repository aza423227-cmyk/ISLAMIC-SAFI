import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { media } from "@/lib/schema";
import { getSessionUser } from "@/lib/session";
import { apiError, badRequest, unauthorized } from "@/lib/http";
import {
  MAX_IMAGE_BYTES,
  MAX_AUDIO_BYTES,
  MAX_UPLOAD_BYTES,
  isAllowedMime,
  mediaKindFor,
  moderateText,
} from "@/lib/moderation";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const form = await request.formData().catch(() => null);
  if (!form) return badRequest();
  const file = form.get("file");
  const purpose = String(form.get("purpose") ?? "post");
  if (!(file instanceof File)) return badRequest("errors.required");
  if (file.size === 0) return badRequest("errors.required");
  if (file.size > MAX_UPLOAD_BYTES) return badRequest("errors.tooLarge");

  const mime = file.type || "application/octet-stream";
  if (!isAllowedMime(mime)) return badRequest("errors.moderation");

  const kind = mediaKindFor(mime);
  if (kind === "image" && file.size > MAX_IMAGE_BYTES) return badRequest("errors.tooLarge");
  if (kind === "audio" && file.size > MAX_AUDIO_BYTES) return badRequest("errors.tooLarge");

  const filename = file.name || "";
  const moderation = moderateText(filename);
  if (!moderation.ok) return badRequest("errors.moderation");

  if (purpose === "avatar" && kind !== "image") return badRequest("errors.moderation");
  if (purpose === "voice") {
    if (kind !== "audio") return badRequest("errors.moderation");
  } else if (purpose === "message") {
    if (kind === "audio") return badRequest("errors.moderation");
  } else if (kind === "audio") {
    return badRequest("errors.moderation");
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  if (bytes.length > MAX_UPLOAD_BYTES) return badRequest("errors.tooLarge");

  const [row] = await db
    .insert(media)
    .values({
      ownerId: user.id,
      mime,
      kind,
      bytes: bytes.length,
      data: bytes,
    })
    .returning({ id: media.id, kind: media.kind, mime: media.mime });

  return NextResponse.json({
    id: row.id,
    kind: row.kind,
    mime: row.mime,
    url: `/api/media/${row.id}`,
  });
}

export async function DELETE(request: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return badRequest("errors.required");
  const row = await db.query.media.findFirst({ where: eq(media.id, id) });
  if (!row) return apiError("errors.notFound", 404);
  if (row.ownerId !== user.id) return apiError("errors.forbidden", 403);
  await db.delete(media).where(eq(media.id, id));
  return NextResponse.json({ ok: true });
}
