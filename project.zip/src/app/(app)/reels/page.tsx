"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bookmark,
  Heart,
  Loader2,
  MessageCircle,
  Music2,
  Play,
  Send,
  Volume2,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import type { FeedPost } from "@/lib/queries";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { useApp } from "@/components/app/app-context";
import { Button } from "@/components/ui/button";

export default function ReelsPage() {
  const { t } = useI18n();
  const { openCompose } = useApp();
  const [reels, setReels] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ posts: FeedPost[] }>("/api/feed?scope=reels");
      setReels(data.posts);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <div className="grid h-[calc(100dvh-104px-env(safe-area-inset-bottom))] place-items-center md:h-dvh">
        <Loader2 className="size-6 animate-spin text-subtle" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-[calc(100dvh-104px-env(safe-area-inset-bottom))] flex-col items-center justify-center gap-3 md:h-dvh">
        <p className="text-[13px] text-subtle">{error}</p>
        <Button variant="outline" size="sm" onClick={load}>
          {t("common.retry")}
        </Button>
      </div>
    );
  }

  if (reels.length === 0) {
    return (
      <div className="flex h-[calc(100dvh-104px-env(safe-area-inset-bottom))] flex-col items-center justify-center gap-3 px-6 text-center md:h-dvh">
        <div className="grid size-16 place-items-center rounded-full border border-line">
          <Play className="size-7" strokeWidth={1.4} />
        </div>
        <p className="text-[16px] font-semibold">{t("reels.emptyTitle")}</p>
        <p className="max-w-[18rem] text-[13px] leading-relaxed text-subtle">
          {t("reels.emptyBody")}
        </p>
        <Button
          onClick={openCompose}
          className="mt-1 h-9 rounded-lg bg-brand px-5 text-[13px] font-semibold text-white hover:bg-brand-hover"
        >
          {t("reels.create")}
        </Button>
      </div>
    );
  }

  return (
    <div className="h-[calc(100dvh-104px-env(safe-area-inset-bottom))] snap-y snap-mandatory overflow-y-scroll bg-black no-scrollbar md:h-dvh">
      {reels.map((reel) => (
        <Reel key={reel.id} reel={reel} onDeleted={() => setReels((c) => c.filter((r) => r.id !== reel.id))} />
      ))}
    </div>
  );
}

function Reel({ reel, onDeleted }: { reel: FeedPost; onDeleted: () => void }) {
  const { t } = useI18n();
  const { viewer } = useApp();
  const router = useRouter();
  const [liked, setLiked] = useState(reel.liked);
  const [likes, setLikes] = useState(reel.likes);
  const [saved, setSaved] = useState(reel.saved);
  const [muted, setMuted] = useState(true);
  const profileHref = reel.username ? `/u/${reel.username}` : "/explore";

  async function toggleLike() {
    setLiked((value) => !value);
    setLikes((value) => value + (liked ? -1 : 1));
    try {
      const result = await api<{ liked: boolean; likes: number }>(
        `/api/posts/${reel.id}/like`,
        { method: "POST" },
      );
      setLiked(result.liked);
      setLikes(result.likes);
    } catch (err) {
      setLiked(liked);
      setLikes(likes);
      toast.error(errorMessage(err, t));
    }
  }

  async function toggleSave() {
    setSaved((value) => !value);
    try {
      const result = await api<{ saved: boolean }>(`/api/posts/${reel.id}/save`, {
        method: "POST",
      });
      setSaved(result.saved);
    } catch (err) {
      setSaved(saved);
      toast.error(errorMessage(err, t));
    }
  }

  async function share() {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/p/${reel.id}`);
      toast.success(t("common.linkCopied"));
    } catch {
      toast.error(t("errors.generic"));
    }
  }

  async function remove() {
    try {
      await api(`/api/posts/${reel.id}`, { method: "DELETE" });
      onDeleted();
      router.refresh();
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  return (
    <section className="relative mx-auto flex h-full w-full snap-start items-center justify-center bg-black md:max-w-[430px] md:py-3">
      <div className="relative h-full w-full overflow-hidden md:rounded-xl">
        {reel.media_id ? (
          <video
            src={`/api/media/${reel.media_id}`}
            className="size-full object-cover"
            autoPlay
            muted={muted}
            loop
            playsInline
            onClick={(event) => {
              const video = event.currentTarget;
              if (video.paused) video.play().catch(() => undefined);
              else video.pause();
            }}
          />
        ) : (
          <div className="grid size-full place-items-center text-subtle">{t("common.noResults")}</div>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />

        <button
          type="button"
          onClick={() => setMuted((value) => !value)}
          aria-label={muted ? t("quran.play") : t("quran.pause")}
          className="absolute end-3 top-3 grid size-9 place-items-center rounded-full bg-black/40 text-white backdrop-blur"
        >
          <Volume2 className={`size-4 ${muted ? "opacity-50" : ""}`} />
        </button>

        <div className="absolute inset-x-0 bottom-0 flex items-end gap-3 p-3 pb-6">
          <div className="min-w-0 flex-1 text-white">
            <Link href={profileHref} className="flex items-center gap-2">
              <UserAvatar name={reel.name} image={reel.image} size="sm" className="border border-white/60" />
              <span className="flex items-center gap-1 text-[13px] font-semibold">
                {reel.username ?? reel.name}
                {reel.verified ? <VerifiedBadge size={12} /> : null}
              </span>
            </Link>
            {reel.caption ? (
              <p className="mt-1.5 line-clamp-2 text-[12px] leading-relaxed text-white/90">
                {reel.caption}
              </p>
            ) : null}
            <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-white/80">
              <Music2 className="size-3" /> {t("reels.originalAudio")} · {reel.name}
            </p>
          </div>

          <div className="flex flex-col items-center gap-3.5 text-white">
            <button
              type="button"
              onClick={toggleLike}
              aria-label={t("common.like")}
              className="flex flex-col items-center gap-1"
            >
              <Heart className={`size-7 ${liked ? "fill-[#ff3040] text-[#ff3040]" : ""}`} />
              <span className="text-[11px]">{likes}</span>
            </button>
            <Link href={`/p/${reel.id}`} className="flex flex-col items-center gap-1" aria-label={t("common.comment")}>
              <MessageCircle className="size-7" />
              <span className="text-[11px]">{reel.comments}</span>
            </Link>
            <button
              type="button"
              onClick={share}
              aria-label={t("common.share")}
              className="flex flex-col items-center gap-1"
            >
              <Send className="size-7" />
              <span className="text-[11px]">{t("common.share")}</span>
            </button>
            <button
              type="button"
              onClick={toggleSave}
              aria-label={t("common.saved")}
              className="flex flex-col items-center gap-1"
            >
              <Bookmark className={`size-7 ${saved ? "fill-white" : ""}`} />
            </button>
            {viewer.id === reel.user_id ? (
              <button
                type="button"
                onClick={remove}
                className="text-[10px] text-white/70 underline"
              >
                {t("common.delete")}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
