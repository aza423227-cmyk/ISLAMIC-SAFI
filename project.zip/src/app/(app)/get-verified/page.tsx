"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { VerificationView } from "@/components/verification/verification-view";

export default function GetVerifiedPage() {
  const { t } = useI18n();
  return (
    <div className="mx-auto w-full max-w-[560px] px-4 pb-12 pt-4 md:pt-8">
      <div className="mb-5 flex items-center gap-3">
        <Link
          href="/settings"
          aria-label={t("common.back")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
        >
          <ArrowLeft className="size-5 rtl:rotate-180" />
        </Link>
        <h1 className="text-[17px] font-semibold">{t("verify.title")}</h1>
      </div>
      <VerificationView />
    </div>
  );
}
