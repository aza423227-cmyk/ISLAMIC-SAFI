"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, RotateCcw, Volume2, VolumeX, Vibrate, VibrateOff } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api } from "@/lib/api";
import { formatNumber } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const DHIKR = [
  { key: "tasbih.subhanallah", arabic: "سُبْحَانَ اللَّهِ" },
  { key: "tasbih.alhamdulillah", arabic: "الْحَمْدُ لِلَّهِ" },
  { key: "tasbih.allahuakbar", arabic: "اللَّهُ أَكْبَرُ" },
];

export default function TasbihPage() {
  const { t, locale } = useI18n();
  const [dhikr, setDhikr] = useState(0);
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  const [total, setTotal] = useState(0);
  const [vibration, setVibration] = useState(true);
  const [sound, setSound] = useState(false);
  const [loading, setLoading] = useState(true);
  const [resetOpen, setResetOpen] = useState(false);
  const [completed, setCompleted] = useState(false);
  const audioRef = useRef<AudioContext | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const totalRef = useRef(0);
  const targetRef = useRef(33);
  const completedRef = useRef(false);

  useEffect(() => {
    totalRef.current = total;
  }, [total]);
  useEffect(() => {
    targetRef.current = target;
  }, [target]);

  useEffect(() => {
    api<{
      settings: {
        tasbihTotal: number;
        tasbihTarget: number;
      } | null;
    }>("/api/settings")
      .then((data) => {
        if (data.settings) {
          setTotal(data.settings.tasbihTotal);
          totalRef.current = data.settings.tasbihTotal;
          setTarget(data.settings.tasbihTarget);
          targetRef.current = data.settings.tasbihTarget;
        }
      })
      .catch(() => undefined)
      .finally(() => setLoading(false));
    try {
      const prefs = localStorage.getItem("ib-tasbih-prefs");
      if (prefs) {
        const parsed = JSON.parse(prefs) as { vibration: boolean; sound: boolean };
        setVibration(parsed.vibration ?? true);
        setSound(parsed.sound ?? false);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback((nextTotal: number, nextTarget: number) => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      api("/api/settings", {
        method: "PATCH",
        body: JSON.stringify({ tasbihTotal: nextTotal, tasbihTarget: nextTarget }),
      }).catch(() => undefined);
    }, 1500);
  }, []);

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      if (totalRef.current > 0) {
        api("/api/settings", {
          method: "PATCH",
          body: JSON.stringify({
            tasbihTotal: totalRef.current,
            tasbihTarget: targetRef.current,
          }),
        }).catch(() => undefined);
      }
    };
  }, []);

  function beep() {
    if (!sound) return;
    try {
      const ctx = audioRef.current ?? new AudioContext();
      audioRef.current = ctx;
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = 660;
      gain.gain.value = 0.025;
      oscillator.connect(gain);
      gain.connect(ctx.destination);
      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.045);
    } catch {
      /* ignore */
    }
  }

  function tap() {
    const next = count + 1;
    const nextTotal = total + 1;
    setCount(next);
    setTotal(nextTotal);
    persist(nextTotal, target);
    if (vibration && typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(12);
    }
    beep();
    if (next >= target && !completedRef.current) {
      completedRef.current = true;
      setCompleted(true);
      if (vibration && navigator.vibrate) navigator.vibrate([35, 60, 35]);
      toast.success(t("tasbih.completed"));
    }
  }

  function reset() {
    setCount(0);
    setCompleted(false);
    completedRef.current = false;
    setResetOpen(false);
  }

  function updateTarget(nextTarget: number) {
    setTarget(nextTarget);
    persist(total, nextTarget);
  }

  function toggleVibration() {
    const next = !vibration;
    setVibration(next);
    try {
      localStorage.setItem("ib-tasbih-prefs", JSON.stringify({ vibration: next, sound }));
    } catch {
      /* ignore */
    }
  }

  function toggleSound() {
    const next = !sound;
    setSound(next);
    try {
      localStorage.setItem("ib-tasbih-prefs", JSON.stringify({ vibration, sound: next }));
    } catch {
      /* ignore */
    }
  }

  const progress = Math.min(1, count / target);
  const radius = 128;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className="mx-auto w-full max-w-[560px] px-4 pb-12 pt-4 md:pt-8">
      <div className="mb-5 flex items-start justify-between">
        <div>
          <h1 className="text-[20px] font-semibold">{t("tasbih.title")}</h1>
          <p className="text-[12px] text-subtle">{t("tasbih.subtitle")}</p>
        </div>
        <button
          type="button"
          onClick={() => setResetOpen(true)}
          aria-label={t("tasbih.reset")}
          className="grid size-9 place-items-center rounded-full text-subtle transition-colors hover:bg-hover hover:text-ink"
        >
          <RotateCcw className="size-4" />
        </button>
      </div>

      <div className="mb-5 flex gap-2">
        {DHIKR.map((item, index) => (
          <button
            key={item.key}
            type="button"
            onClick={() => {
              setDhikr(index);
              reset();
            }}
            className={cn(
              "flex-1 rounded-xl border px-2 py-2.5 text-center transition-colors",
              dhikr === index
                ? "border-[#c8a45c]/70 bg-[#c8a45c]/10"
                : "border-line bg-surface hover:bg-hover/40",
            )}
          >
            <span className="font-arabic text-[15px]" dir="rtl">
              {item.arabic}
            </span>
            <span className="mt-1 block text-[10px] text-subtle">{t(item.key)}</span>
          </button>
        ))}
      </div>

      <div className="relative mx-auto flex aspect-square w-full max-w-[340px] items-center justify-center">
        <svg viewBox="0 0 300 300" className="absolute inset-0 size-full -rotate-90">
          <circle cx="150" cy="150" r={radius} fill="none" stroke="currentColor" strokeWidth="5" className="text-line" />
          <circle
            cx="150"
            cy="150"
            r={radius}
            fill="none"
            stroke="#c8a45c"
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - progress)}
            className="transition-[stroke-dashoffset] duration-200 ease-out"
          />
        </svg>
        <button
          type="button"
          onClick={tap}
          aria-label={t("tasbih.tapToCount")}
          className="group flex size-[78%] flex-col items-center justify-center gap-1 rounded-full bg-gradient-to-br from-[#142a22] via-[#0f1f1a] to-[#0a1210] text-[#efe6d2] shadow-[0_12px_40px_rgba(0,0,0,0.25)] transition-transform active:scale-[0.97]"
        >
          <span className="font-arabic text-[26px] leading-relaxed" dir="rtl">
            {DHIKR[dhikr].arabic}
          </span>
          <span className="font-wordmark text-[64px] font-semibold leading-none tabular-nums">
            {loading ? "—" : formatNumber(count, locale)}
          </span>
          <span className="text-[11px] uppercase tracking-[0.2em] text-[#c9bda2]">
            / {formatNumber(target, locale)}
          </span>
        </button>
        {loading ? (
          <span className="absolute bottom-2 grid place-items-center rounded-full bg-surface p-1">
            <Loader2 className="size-4 animate-spin text-subtle" />
          </span>
        ) : null}
      </div>

      <p className="mt-3 text-center text-[11px] text-subtle">{t("tasbih.press")}</p>
      {completed ? (
        <p className="mt-2 text-center text-[12px] font-medium text-[#a8853f]">
          {t("tasbih.completed")}
        </p>
      ) : null}

      <div className="mt-6 space-y-3">
        <div className="rounded-xl border border-line bg-surface p-4">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-subtle">
            {t("tasbih.target")}
          </p>
          <div className="flex gap-2">
            {[33, 99, 100, 1000].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => updateTarget(value)}
                className={cn(
                  "h-9 flex-1 rounded-lg border text-[12px] font-semibold transition-colors",
                  target === value
                    ? "border-[#c8a45c]/70 bg-[#c8a45c]/10 text-[#8a6d2f] dark:text-[#d9b86f]"
                    : "border-line bg-app text-subtle hover:bg-hover",
                )}
              >
                {formatNumber(value, locale)}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
          <div className="flex items-center justify-between px-4 py-3">
            <span className="flex items-center gap-2 text-[13px]">
              {vibration ? <Vibrate className="size-4" /> : <VibrateOff className="size-4" />}
              {t("tasbih.vibration")}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleVibration}
              className={cn(
                "h-7 px-3 text-[11px] font-semibold",
                vibration ? "text-brand" : "text-subtle",
              )}
            >
              {vibration ? t("common.on") : t("common.off")}
            </Button>
          </div>
          <div className="flex items-center justify-between px-4 py-3">
            <span className="flex items-center gap-2 text-[13px]">
              {sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
              {t("tasbih.sound")}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleSound}
              className={cn(
                "h-7 px-3 text-[11px] font-semibold",
                sound ? "text-brand" : "text-subtle",
              )}
            >
              {sound ? t("common.on") : t("common.off")}
            </Button>
          </div>
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-[13px]">{t("tasbih.total")}</span>
            <span className="text-[14px] font-semibold tabular-nums">
              {formatNumber(total, locale)}
            </span>
          </div>
        </div>
      </div>

      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("tasbih.reset")}</AlertDialogTitle>
            <AlertDialogDescription>{t("tasbih.resetConfirm")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={reset}>{t("common.confirm")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
