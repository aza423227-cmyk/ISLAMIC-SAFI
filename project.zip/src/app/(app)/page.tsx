"use client";

import { StoriesBar } from "@/components/feed/stories-bar";
import { Feed } from "@/components/feed/feed";
import { SuggestionsCard } from "@/components/feed/suggestions-card";
import { PrayerMiniCard } from "@/components/feed/prayer-mini-card";

export default function HomePage() {
  return (
    <div className="mx-auto flex w-full max-w-[975px] gap-12 md:px-4 lg:px-6 lg:py-6">
      <div className="mx-auto w-full max-w-[630px] lg:mx-0">
        <StoriesBar />
        <div className="sm:mt-4">
          <Feed scope="home" />
        </div>
      </div>
      <aside className="hidden w-[320px] shrink-0 lg:block">
        <div className="sticky top-6 space-y-2">
          <SuggestionsCard />
          <PrayerMiniCard />
          <p className="px-1 pt-4 text-[11px] leading-relaxed text-subtle/70">
            © {new Date().getFullYear()} ISLAMIC BESSAFI
          </p>
        </div>
      </aside>
    </div>
  );
}
