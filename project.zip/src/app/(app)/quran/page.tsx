"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, Loader2, Pause, Play, Search, X } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { reciters, surahAudioUrl, surahs } from "@/lib/quran-data";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { formatNumber } from "@/lib/i18n";

export default function QuranPage() {
  const { t, locale, dir } = useI18n();
  const [reciter, setReciter] = useState(reciters[0].id);
  const [query, setQuery] = useState("");
  const [current, setCurrent] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loadingAudio, setLoadingAudio] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("ib-reciter");
      if (stored && reciters.some((item) => item.id === stored)) setReciter(stored);
    } catch {
      /* ignore */
    }
  }, []);

  const filtered = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return surahs;
    return surahs.filter(
      (surah) =>
        String(surah.number) === value ||
        surah.name.includes(query.trim()) ||
        surah.englishName.toLowerCase().includes(value) ||
        surah.translation.toLowerCase().includes(value),
    );
  }, [query]);

  const currentSurah = current ? surahs.find((surah) => surah.number === current) : null;
  const activeReciter = reciters.find((item) => item.id === reciter) ?? reciters[0];
  const src = current ? surahAudioUrl(reciter, current) : undefined;

  useEffect(() => {
    if (!current || !audioRef.current) return;
    setLoadingAudio(true);
    audioRef.current.load();
    audioRef.current.play().catch(() => {
      setLoadingAudio(false);
      setPlaying(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current, reciter]);

  function toggle(surahNumber: number) {
    if (current === surahNumber) {
      const audio = audioRef.current;
      if (!audio) return;
      if (audio.paused) audio.play().catch(() => toast.error(t("quran.audioError")));
      else audio.pause();
    } else {
      setCurrent(surahNumber);
      setPlaying(true);
    }
  }

  function changeReciter(value: string) {
    setReciter(value);
    try {
      localStorage.setItem("ib-reciter", value);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="mx-auto w-full max-w-[760px] px-4 pb-32 pt-4 md:pt-8">
      <div className="mb-4 flex items-start gap-3">
        <span className="grid size-11 place-items-center rounded-full bg-[#c8a45c]/10 text-[#a8853f]">
          <BookOpen className="size-5" strokeWidth={1.6} />
        </span>
        <div>
          <h1 className="text-[20px] font-semibold">{t("quran.title")}</h1>
          <p className="text-[12px] leading-relaxed text-subtle">{t("quran.subtitle")}</p>
        </div>
      </div>

      <div className="mb-3 flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-subtle" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("quran.searchSurah")}
            aria-label={t("quran.searchSurah")}
            className="h-10 rounded-lg border-line bg-surface ps-9 text-[13px]"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label={t("common.close")}
              className="absolute inset-y-0 end-2 my-auto grid size-7 place-items-center rounded-full text-subtle hover:bg-hover"
            >
              <X className="size-3.5" />
            </button>
          ) : null}
        </div>
        <Select value={reciter} onValueChange={changeReciter}>
          <SelectTrigger
            aria-label={t("quran.reciter")}
            className="h-10 w-full border-line bg-surface text-[13px] sm:w-[230px]"
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {reciters.map((item) => (
              <SelectItem key={item.id} value={item.id}>
                <span dir="rtl">{item.arabic}</span>
                <span className="ms-2 text-subtle">{item.name}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-xl border border-line bg-surface py-14 text-center">
          <BookOpen className="size-8 text-subtle" strokeWidth={1.3} />
          <p className="text-[13px] font-medium">{t("common.noResults")}</p>
        </div>
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
          {filtered.map((surah) => {
            const isCurrent = current === surah.number;
            return (
              <li key={surah.number}>
                <button
                  type="button"
                  onClick={() => toggle(surah.number)}
                  className={cn(
                    "flex w-full items-center gap-3 px-3.5 py-3 text-start transition-colors hover:bg-hover/40",
                    isCurrent && "bg-[#c8a45c]/5",
                  )}
                >
                  <span
                    className={cn(
                      "grid size-9 shrink-0 place-items-center rounded-full text-[11px] font-semibold",
                      isCurrent
                        ? "bg-[#c8a45c] text-[#1b1405]"
                        : "bg-hover text-subtle",
                    )}
                  >
                    {isCurrent && playing ? (
                      <Pause className="size-3.5" />
                    ) : isCurrent ? (
                      <Play className="size-3.5" />
                    ) : (
                      surah.number
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-[13px] font-semibold">
                        {surah.englishName}
                      </span>
                      <span className="shrink-0 font-arabic text-[16px]" dir="rtl">
                        {surah.name}
                      </span>
                    </span>
                    <span className="mt-0.5 flex items-center gap-1.5 text-[11px] text-subtle">
                      <span className="truncate">{surah.translation}</span>
                      <span>·</span>
                      <span>
                        {formatNumber(surah.ayahs, locale)} {t("quran.verseCount")}
                      </span>
                      <span>·</span>
                      <span>
                        {surah.revelation === "Meccan" ? t("quran.meccan") : t("quran.medinan")}
                      </span>
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {current && currentSurah ? (
        <div className="fixed inset-x-0 bottom-[calc(56px+env(safe-area-inset-bottom))] z-30 border-t border-line bg-surface/98 px-3 py-2.5 backdrop-blur md:bottom-0 md:start-[72px] xl:start-[244px]">
          <div className="mx-auto flex w-full max-w-[760px] items-center gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#c8a45c]/12 text-[#a8853f]">
              {loadingAudio ? (
                <Loader2 className="size-4 animate-spin" />
              ) : playing ? (
                <Play className="size-4" />
              ) : (
                <Pause className="size-4" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12px] font-semibold">
                {t("quran.nowPlaying")} · {currentSurah.englishName}
                <span className="ms-1 font-arabic" dir="rtl">
                  {currentSurah.name}
                </span>
              </p>
              <p className="truncate text-[10px] text-subtle" dir={dir}>
                {activeReciter.name}
              </p>
            </div>
            <audio
              ref={audioRef}
              src={src}
              controls
              preload="none"
              className="h-9 w-[190px] max-w-[45vw]"
              onPlay={() => {
                setPlaying(true);
                setLoadingAudio(false);
              }}
              onPause={() => setPlaying(false)}
              onEnded={() => setPlaying(false)}
              onError={() => {
                setLoadingAudio(false);
                setPlaying(false);
                toast.error(t("quran.audioError"));
              }}
              onLoadStart={() => setLoadingAudio(true)}
              onCanPlay={() => setLoadingAudio(false)}
            />
            <button
              type="button"
              onClick={() => {
                audioRef.current?.pause();
                setCurrent(null);
                setPlaying(false);
              }}
              aria-label={t("quran.stop")}
              className="grid size-8 shrink-0 place-items-center rounded-full text-subtle hover:bg-hover"
            >
              <X className="size-4" />
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
