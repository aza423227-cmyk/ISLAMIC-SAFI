"use client";

import { useState } from "react";
import { Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n/provider";
import { authClient } from "@/lib/auth-client";
import { SettingsGroup, SettingsShell } from "@/components/settings/settings-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function SecuritySettingsPage() {
  const { t } = useI18n();
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [pending, setPending] = useState(false);
  const [revoking, setRevoking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function changePassword(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setSuccess(null);
    if (newPassword.length < 8) {
      setError(t("auth.passwordShort"));
      return;
    }
    if (newPassword !== confirm) {
      setError(t("errors.invalid"));
      return;
    }
    setPending(true);
    try {
      const result = await authClient.changePassword({
        currentPassword,
        newPassword,
        revokeOtherSessions: true,
      });
      if (result.error) {
        setError(t("auth.invalidCredentials"));
        return;
      }
      setSuccess(t("settings.passwordUpdated"));
      toast.success(t("settings.passwordUpdated"));
      setCurrentPassword("");
      setNewPassword("");
      setConfirm("");
    } catch {
      setError(t("errors.generic"));
    } finally {
      setPending(false);
    }
  }

  async function revokeOthers() {
    setRevoking(true);
    try {
      await authClient.revokeOtherSessions();
      toast.success(t("settings.settingsSaved"));
    } catch {
      toast.error(t("errors.generic"));
    } finally {
      setRevoking(false);
    }
  }

  async function signOut() {
    await authClient.signOut();
    router.replace("/auth/sign-in");
    router.refresh();
  }

  return (
    <SettingsShell title={t("settings.security")}>
      <div className="mb-6 flex items-start gap-3 rounded-xl border border-line bg-surface px-4 py-4">
        <ShieldCheck className="mt-0.5 size-5 shrink-0 text-[#a8853f]" strokeWidth={1.6} />
        <div>
          <p className="text-[13px] font-semibold">{t("settings.security")}</p>
          <p className="text-[11px] leading-relaxed text-subtle">{t("settings.security")}</p>
        </div>
      </div>

      <SettingsGroup title={t("settings.changePassword")}>
        <form onSubmit={changePassword} className="space-y-3 px-4 py-4">
          <div className="space-y-1.5">
            <Label htmlFor="current-password" className="text-[11px] text-subtle">
              {t("settings.currentPassword")}
            </Label>
            <Input
              id="current-password"
              type="password"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              className="h-10 border-line bg-app text-[13px]"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-password" className="text-[11px] text-subtle">
              {t("settings.newPassword")}
            </Label>
            <Input
              id="new-password"
              type="password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              className="h-10 border-line bg-app text-[13px]"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="confirm-password" className="text-[11px] text-subtle">
              {t("common.confirm")}
            </Label>
            <Input
              id="confirm-password"
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(event) => setConfirm(event.target.value)}
              className="h-10 border-line bg-app text-[13px]"
              required
            />
          </div>
          {error ? <p className="text-[12px] text-destructive">{error}</p> : null}
          {success ? <p className="text-[12px] text-[#1a7f37]">{success}</p> : null}
          <Button
            type="submit"
            disabled={pending || !currentPassword || !newPassword || !confirm}
            className="h-9 w-full rounded-lg bg-brand text-[13px] font-semibold text-white hover:bg-brand-hover"
          >
            {pending ? <Loader2 className="size-4 animate-spin" /> : t("settings.updatePassword")}
          </Button>
        </form>
      </SettingsGroup>

      <SettingsGroup title={t("settings.security")}>
        <div className="space-y-3 px-4 py-4">
          <p className="text-[12px] leading-relaxed text-subtle">{t("settings.activityStatusDesc")}</p>
          <Button
            variant="outline"
            size="sm"
            onClick={revokeOthers}
            disabled={revoking}
            className="h-8 text-[12px]"
          >
            {revoking ? <Loader2 className="size-3.5 animate-spin" /> : t("common.logOut")}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={signOut}
            className="h-8 text-[12px] text-destructive"
          >
            {t("common.logOut")}
          </Button>
        </div>
      </SettingsGroup>
    </SettingsShell>
  );
}
