"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Trash2, UserCog } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { useApp } from "@/components/app/app-context";
import { authClient } from "@/lib/auth-client";
import { api, errorMessage } from "@/lib/api";
import { SettingsGroup, SettingsRow, SettingsShell } from "@/components/settings/settings-ui";
import { EditProfileDialog } from "@/components/profile/edit-profile-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AccountSettingsPage() {
  const { t } = useI18n();
  const { viewer } = useApp();
  const router = useRouter();
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [confirmName, setConfirmName] = useState("");
  const [password, setPassword] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function deleteAccount() {
    if (confirmName.replace(/^@/, "") !== (viewer.username ?? "")) {
      setError(t("settings.deleteAccountConfirm"));
      return;
    }
    setDeleting(true);
    setError(null);
    try {
      await api("/api/account", {
        method: "DELETE",
        body: JSON.stringify({ password }),
      });
      await authClient.signOut();
      toast.success(t("settings.deleted"));
      router.replace("/auth/sign-up");
      router.refresh();
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setDeleting(false);
    }
  }

  return (
    <SettingsShell title={t("settings.account")}>
      <SettingsGroup title={t("settings.accountInfo")}>
        <SettingsRow label={t("settings.emailLabel")} description={viewer.email} />
        <SettingsRow
          label={t("settings.usernameLabel")}
          description={viewer.username ? `@${viewer.username}` : "—"}
        />
        <SettingsRow label={t("common.fullName")} description={viewer.name} />
      </SettingsGroup>

      <SettingsGroup>
        <SettingsRow
          icon={<UserCog className="size-5" strokeWidth={1.6} />}
          label={t("settings.editProfile")}
          description={t("profile.bioPlaceholder")}
          onClick={() => setEditOpen(true)}
        />
      </SettingsGroup>

      <SettingsGroup title={t("settings.security")}>
        <SettingsRow
          icon={<Trash2 className="size-5" strokeWidth={1.6} />}
          label={t("settings.deleteAccount")}
          description={t("settings.deleteAccountDesc")}
          destructive
          onClick={() => {
            setDeleteOpen(true);
            setError(null);
            setConfirmName("");
            setPassword("");
          }}
        />
      </SettingsGroup>

      <EditProfileDialog open={editOpen} onOpenChange={setEditOpen} />

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("settings.deleteAccount")}</AlertDialogTitle>
            <AlertDialogDescription>{t("settings.deleteAccountConfirm")}</AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="confirm-username" className="text-[11px] text-subtle">
                {t("settings.usernameLabel")}
              </Label>
              <Input
                id="confirm-username"
                value={confirmName}
                onChange={(event) => setConfirmName(event.target.value)}
                placeholder={`@${viewer.username ?? ""}`}
                autoComplete="off"
                className="h-10 border-line bg-app text-[13px]"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="delete-password" className="text-[11px] text-subtle">
                {t("common.password")}
              </Label>
              <Input
                id="delete-password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                className="h-10 border-line bg-app text-[13px]"
              />
            </div>
            {error ? <p className="text-[12px] text-destructive">{error}</p> : null}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <Button
              variant="destructive"
              onClick={deleteAccount}
              disabled={deleting || !password || !confirmName}
            >
              {deleting ? <Loader2 className="size-4 animate-spin" /> : t("common.delete")}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SettingsShell>
  );
}
