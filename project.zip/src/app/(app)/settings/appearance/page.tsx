"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Check, Loader2, Monitor, Moon, Sun } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { SettingsShell } from "@/components/settings/settings-ui";
import { cn } from "@/lib/utils";

export default function AppearanceSettingsPage() {
  const { t } = useI18n();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [pending, setPending] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);

  const options = [
    { value: "light", label: t("common.light"), icon: Sun },
    { value: "dark", label: t("common.dark"), icon: Moon },
    { value: "system", label: t("common.system"), icon: Monitor },
  ];

  async function choose(value: string) {
    setTheme(value);
    setPending(value);
    try {
      await api("/api/settings", {
        method: "PATCH",
        body: JSON.stringify({ theme: value }),
      });
      toast.success(t("settings.settingsSaved"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPending(null);
    }
  }

  return (
    <SettingsShell title={t("settings.appearance")}>
      <p className="mb-4 px-1 text-[12px] leading-relaxed text-subtle">
        {t("settings.themeDesc")}
      </p>
      <div className="grid gap-3 sm:grid-cols-3">
        {options.map((option) => {
          const Icon = option.icon;
          const active = mounted && theme === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => choose(option.value)}
              disabled={pending === option.value}
              className={cn(
                "relative flex flex-col items-start gap-3 rounded-xl border p-4 text-start transition-colors",
                active ? "border-brand bg-brand/5" : "border-line bg-surface hover:bg-hover/40",
              )}
            >
              <span className="grid size-10 place-items-center rounded-full bg-hover">
                {pending === option.value ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Icon className="size-[18px]" strokeWidth={1.7} />
                )}
              </span>
              <span className="text-[13px] font-semibold">{option.label}</span>
              <span
                className={cn(
                  "absolute end-3 top-3 grid size-5 place-items-center rounded-full border",
                  active ? "border-brand bg-brand text-white" : "border-line",
                )}
              >
                {active ? <Check className="size-3" strokeWidth={3} /> : null}
              </span>
            </button>
          );
        })}
      </div>

      <div className="mt-6 rounded-xl border border-line bg-surface p-4">
        <p className="text-[12px] font-semibold">{t("common.theme")}</p>
        <p className="mt-1 text-[11px] leading-relaxed text-subtle">
          {t("settings.themeDesc")}
        </p>
      </div>
    </SettingsShell>
  );
}
