"use client";

import { useI18n } from "@/lib/i18n/provider";
import { SettingsShell } from "@/components/settings/settings-ui";
import { VerificationView } from "@/components/verification/verification-view";

export default function VerificationSettingsPage() {
  const { t } = useI18n();
  return (
    <SettingsShell title={t("settings.verification")}>
      <VerificationView />
    </SettingsShell>
  );
}
