"use client";

import Link from "next/link";
import {
  BadgeCheck,
  Bell,
  BookOpen,
  ChevronRight,
  CircleDot,
  Globe2,
  Info,
  Lock,
  LogOut,
  Moon,
  Shield,
  Sunset,
  User,
  UserCog,
} from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n/provider";
import { useApp } from "@/components/app/app-context";
import { authClient } from "@/lib/auth-client";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { SettingsGroup, SettingsRow } from "@/components/settings/settings-ui";

export default function SettingsPage() {
  const { t, locale } = useI18n();
  const { viewer } = useApp();
  const router = useRouter();
  const localeName = new Intl.DisplayNames([locale], { type: "language" }).of(locale) ?? locale;

  async function signOut() {
    await authClient.signOut();
    toast.success(t("common.logOut"));
    router.replace("/auth/sign-in");
    router.refresh();
  }

  return (
    <div className="mx-auto w-full max-w-[640px] px-4 pb-12 pt-4 md:pt-8">
      <h1 className="mb-4 px-1 text-[20px] font-semibold">{t("settings.title")}</h1>

      <Link
        href={viewer.username ? `/u/${viewer.username}` : "/settings/account"}
        className="mb-6 flex items-center gap-3 rounded-xl border border-line bg-surface px-4 py-4 transition-colors hover:bg-hover/40"
      >
        <UserAvatar name={viewer.name} image={viewer.image} size="lg" />
        <div className="min-w-0 flex-1 leading-tight">
          <p className="flex items-center gap-1 truncate text-[15px] font-semibold">
            {viewer.username ?? viewer.name}
            {viewer.verified ? <VerifiedBadge size={13} /> : null}
          </p>
          <p className="truncate text-[12px] text-subtle">{viewer.name}</p>
          <p className="truncate text-[11px] text-subtle">{viewer.email}</p>
        </div>
        <ChevronRight className="size-4 text-subtle rtl:rotate-180" />
      </Link>

      <SettingsGroup title={t("settings.account")}>
        <SettingsRow
          icon={<UserCog className="size-5" strokeWidth={1.6} />}
          label={t("settings.editProfile")}
          href="/settings/account"
        />
        <SettingsRow
          icon={<User className="size-5" strokeWidth={1.6} />}
          label={t("settings.accountInfo")}
          href="/settings/account"
        />
        <SettingsRow
          icon={<BadgeCheck className="size-5" strokeWidth={1.6} />}
          label={t("settings.verification")}
          description={viewer.verified ? t("verify.active") : t("verify.subtitle")}
          href="/settings/verification"
          trailing={
            viewer.verified ? (
              <VerifiedBadge size={16} />
            ) : (
              <ChevronRight className="size-4 text-subtle rtl:rotate-180" />
            )
          }
        />
      </SettingsGroup>

      <SettingsGroup title={t("nav.settings")}>
        <SettingsRow
          icon={<Lock className="size-5" strokeWidth={1.6} />}
          label={t("settings.privacy")}
          href="/settings/privacy"
        />
        <SettingsRow
          icon={<Shield className="size-5" strokeWidth={1.6} />}
          label={t("settings.security")}
          href="/settings/security"
        />
        <SettingsRow
          icon={<Bell className="size-5" strokeWidth={1.6} />}
          label={t("settings.notifications")}
          href="/settings/notifications"
        />
        <SettingsRow
          icon={<Moon className="size-5" strokeWidth={1.6} />}
          label={t("settings.appearance")}
          href="/settings/appearance"
        />
        <SettingsRow
          icon={<Globe2 className="size-5" strokeWidth={1.6} />}
          label={t("settings.languageTitle")}
          description={localeName}
          href="/settings/language"
        />
      </SettingsGroup>

      <SettingsGroup title={t("explore.tools")}>
        <SettingsRow
          icon={<Sunset className="size-5" strokeWidth={1.6} />}
          label={t("settings.prayerSettings")}
          href="/settings/prayer"
        />
        <SettingsRow
          icon={<BookOpen className="size-5" strokeWidth={1.6} />}
          label={t("quran.title")}
          href="/quran"
        />
        <SettingsRow
          icon={<CircleDot className="size-5" strokeWidth={1.6} />}
          label={t("tasbih.title")}
          href="/tasbih"
        />
      </SettingsGroup>

      <SettingsGroup title={t("settings.about")}>
        <SettingsRow
          icon={<Info className="size-5" strokeWidth={1.6} />}
          label={t("settings.about")}
          href="/settings/about"
        />
        <SettingsRow
          icon={<LogOut className="size-5" strokeWidth={1.6} />}
          label={t("common.logOut")}
          onClick={signOut}
          destructive
        />
      </SettingsGroup>

      <p className="px-1 text-[11px] text-subtle">
        ISLAMIC BESSAFI · {t("settings.version")} 1.0.0
      </p>
    </div>
  );
}
