"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { SettingsGroup, SettingsRow, SettingsShell } from "@/components/settings/settings-ui";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Settings = {
  remindersEnabled: boolean;
  reminderMinutes: number;
  prayerMethod: string;
};

type Prefs = {
  likesComments: boolean;
  newFollowers: boolean;
  directMessages: boolean;
};

const DEFAULT_PREFS: Prefs = {
  likesComments: true,
  newFollowers: true,
  directMessages: true,
};

export default function NotificationSettingsPage() {
  const { t } = useI18n();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">(
    "unsupported",
  );

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<{ settings: Settings | null }>("/api/settings");
      setSettings(data.settings);
      setError(null);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
    try {
      const stored = localStorage.getItem("ib-notif-prefs");
      if (stored) setPrefs({ ...DEFAULT_PREFS, ...(JSON.parse(stored) as Prefs) });
    } catch {
      /* ignore */
    }
    if (typeof Notification !== "undefined") setPermission(Notification.permission);
  }, [load]);

  function updatePrefs(next: Prefs) {
    setPrefs(next);
    try {
      localStorage.setItem("ib-notif-prefs", JSON.stringify(next));
    } catch {
      /* ignore */
    }
    toast.success(t("settings.settingsSaved"));
  }

  async function patch(key: string, body: Record<string, unknown>) {
    setPending(key);
    try {
      const data = await api<{ settings: Settings }>("/api/settings", {
        method: "PATCH",
        body: JSON.stringify(body),
      });
      setSettings((current) => ({ ...(current ?? data.settings), ...data.settings }));
      toast.success(t("settings.settingsSaved"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPending(null);
    }
  }

  async function enablePush() {
    if (typeof Notification === "undefined") {
      setPermission("unsupported");
      return;
    }
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      if (result === "granted") toast.success(t("settings.settingsSaved"));
      if (result === "denied") toast.error(t("prayer.notificationsBlocked"));
    } catch {
      toast.error(t("errors.generic"));
    }
  }

  return (
    <SettingsShell title={t("settings.notifications")}>
      {loading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-subtle">
          <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <p className="text-[13px] text-subtle">{error}</p>
          <Button size="sm" variant="outline" onClick={load}>
            {t("common.retry")}
          </Button>
        </div>
      ) : (
        <>
          <div className="mb-6 flex items-start gap-3 rounded-xl border border-line bg-surface px-4 py-4">
            <Bell className="mt-0.5 size-5 shrink-0 text-[#a8853f]" strokeWidth={1.6} />
            <div className="min-w-0">
              <p className="text-[13px] font-semibold">{t("settings.notificationsDesc")}</p>
              <p className="text-[11px] leading-relaxed text-subtle">
                {permission === "granted"
                  ? t("common.on")
                  : permission === "denied"
                    ? t("prayer.notificationsBlocked")
                    : t("settings.notifications")}
              </p>
              {permission !== "granted" ? (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 h-8 text-[12px]"
                  onClick={enablePush}
                >
                  {t("settings.notifications")}
                </Button>
              ) : null}
            </div>
          </div>

          <SettingsGroup title={t("settings.notifications")}>
            <SettingsRow
              label={t("settings.likesComments")}
              trailing={
                <Switch
                  checked={prefs.likesComments}
                  onCheckedChange={(value) => updatePrefs({ ...prefs, likesComments: value })}
                />
              }
            />
            <SettingsRow
              label={t("settings.newFollowers")}
              trailing={
                <Switch
                  checked={prefs.newFollowers}
                  onCheckedChange={(value) => updatePrefs({ ...prefs, newFollowers: value })}
                />
              }
            />
            <SettingsRow
              label={t("settings.directMessages")}
              trailing={
                <Switch
                  checked={prefs.directMessages}
                  onCheckedChange={(value) => updatePrefs({ ...prefs, directMessages: value })}
                />
              }
            />
          </SettingsGroup>

          <SettingsGroup title={t("settings.prayerReminders")}>
            <SettingsRow
              label={t("prayer.enableReminders")}
              description={t("prayer.remindersDesc")}
              trailing={
                <Switch
                  checked={settings?.remindersEnabled ?? false}
                  onCheckedChange={async (value) => {
                    if (value && typeof Notification !== "undefined") {
                      const result = await Notification.requestPermission();
                      if (result === "granted") setPermission(result);
                    }
                    await patch("reminders", { remindersEnabled: value });
                  }}
                  disabled={pending === "reminders"}
                />
              }
            />
            <div className="space-y-2 px-4 py-4">
              <p className="text-[13px] font-medium">{t("settings.reminderBefore")}</p>
              <Select
                value={String(settings?.reminderMinutes ?? 10)}
                onValueChange={(value) =>
                  patch("minutes", { reminderMinutes: Number(value) })
                }
                disabled={pending === "minutes"}
              >
                <SelectTrigger className="h-10 w-full border-line bg-app text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[0, 5, 10, 15, 20, 30].map((minutes) => (
                    <SelectItem key={minutes} value={String(minutes)}>
                      {minutes === 0 ? t("common.now") : `${minutes} ${t("common.minutes")}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </SettingsGroup>
        </>
      )}
    </SettingsShell>
  );
}
