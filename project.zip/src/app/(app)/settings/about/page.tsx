"use client";

import Link from "next/link";
import { BookOpen, Heart, ShieldCheck, MoonStar } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { SettingsShell, SettingsGroup, SettingsRow } from "@/components/settings/settings-ui";
import { Wordmark, GoldRule } from "@/components/brand/wordmark";

export default function AboutSettingsPage() {
  const { t } = useI18n();
  return (
    <SettingsShell title={t("settings.about")}>
      <div className="mb-6 flex flex-col items-center gap-3 rounded-xl border border-line bg-surface px-6 py-8 text-center">
        <Wordmark />
        <GoldRule />
        <p className="max-w-sm text-[12px] leading-relaxed text-subtle">
          {t("auth.tagline")} {t("settings.mediaFilterDesc")}
        </p>
      </div>

      <SettingsGroup title={t("explore.tools")}>
        <SettingsRow
          icon={<BookOpen className="size-5" strokeWidth={1.6} />}
          label={t("quran.title")}
          description={t("quran.subtitle")}
          href="/quran"
        />
        <SettingsRow
          icon={<MoonStar className="size-5" strokeWidth={1.6} />}
          label={t("messages.aiAssistant")}
          description={t("explore.aiAssistantDesc")}
          href="/messages/ai"
        />
        <SettingsRow
          icon={<ShieldCheck className="size-5" strokeWidth={1.6} />}
          label={t("settings.mediaFilter")}
          description={t("settings.mediaFilterDesc")}
        />
      </SettingsGroup>

      <SettingsGroup title={t("settings.about")}>
        <SettingsRow label={t("settings.version")} description="1.0.0" />
        <SettingsRow label={t("common.language")} description="English · العربية · Français · Türkçe · اردو" />
        <SettingsRow
          label={t("settings.privacyPolicy")}
          description={t("settings.privacy")}
          href="/settings/privacy"
        />
        <SettingsRow
          label={t("settings.help")}
          description={t("messages.aiDisclaimer")}
          href="/messages/ai"
        />
      </SettingsGroup>

      <div className="flex items-center justify-center gap-1.5 py-4 text-[11px] text-subtle">
        {t("settings.about")} <Heart className="size-3 fill-[#c8a45c] text-[#c8a45c]" />
        <Link href="/" className="font-semibold text-ink">
          ISLAMIC BESSAFI
        </Link>
      </div>
    </SettingsShell>
  );
}
