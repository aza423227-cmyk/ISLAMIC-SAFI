"use client";

import { Check, Globe2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { localeList } from "@/lib/i18n";
import { SettingsShell } from "@/components/settings/settings-ui";
import { cn } from "@/lib/utils";

export default function LanguageSettingsPage() {
  const { t, locale, setLocale } = useI18n();

  return (
    <SettingsShell title={t("settings.languageTitle")}>
      <div className="mb-5 flex items-start gap-3 rounded-xl border border-line bg-surface px-4 py-4">
        <Globe2 className="mt-0.5 size-5 shrink-0 text-[#a8853f]" strokeWidth={1.6} />
        <div>
          <p className="text-[13px] font-semibold">{t("settings.appLanguage")}</p>
          <p className="text-[11px] leading-relaxed text-subtle">{t("settings.chooseLanguage")}</p>
        </div>
      </div>

      <div className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
        {localeList.map((item) => {
          const active = locale === item.code;
          return (
            <button
              key={item.code}
              type="button"
              onClick={() => {
                setLocale(item.code);
                toast.success(t("settings.settingsSaved"));
              }}
              className="flex w-full items-center gap-3 px-4 py-4 text-start transition-colors hover:bg-hover/40"
            >
              <span className="grid size-9 shrink-0 place-items-center rounded-full bg-hover text-[11px] font-semibold">
                {item.flag}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[14px]" dir={item.dir}>
                  {item.native}
                </span>
                <span className="block text-[11px] text-subtle">{item.english}</span>
              </span>
              {active ? (
                <span className="grid size-6 place-items-center rounded-full bg-brand text-white">
                  <Check className="size-3.5" strokeWidth={3} />
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      <p className={cn("mt-4 px-1 text-[11px] leading-relaxed text-subtle")}>
        {t("settings.chooseLanguage")} — {t("settings.languageDesc")}
      </p>
    </SettingsShell>
  );
}
