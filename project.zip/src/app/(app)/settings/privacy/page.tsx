"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { useApp } from "@/components/app/app-context";
import { SettingsGroup, SettingsRow, SettingsShell } from "@/components/settings/settings-ui";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Settings = {
  latitude: string | null;
  longitude: string | null;
  city: string | null;
  country: string | null;
  prayerMethod: string;
  remindersEnabled: boolean;
  reminderMinutes: number;
  tasbihTotal: number;
  tasbihTarget: number;
  messagePrivacy: string;
  activityStatus: boolean;
  mediaFilterStrict: boolean;
  language: string | null;
  theme: string | null;
};

export default function PrivacySettingsPage() {
  const { t } = useI18n();
  const { viewer, setViewer } = useApp();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ settings: Settings | null }>("/api/settings");
      setSettings(data.settings);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  async function patch(key: string, body: Record<string, unknown>) {
    setPending(key);
    try {
      const data = await api<{ settings: Settings }>("/api/settings", {
        method: "PATCH",
        body: JSON.stringify(body),
      });
      setSettings((current) => ({ ...(current ?? data.settings), ...data.settings }));
      toast.success(t("settings.settingsSaved"));
      return data.settings;
    } catch (err) {
      toast.error(errorMessage(err, t));
      return null;
    } finally {
      setPending(null);
    }
  }

  async function togglePrivate(value: boolean) {
    setViewer({ ...viewer, isPrivate: value });
    setPending("private");
    try {
      await api("/api/profile", {
        method: "PATCH",
        body: JSON.stringify({ isPrivate: value }),
      });
      toast.success(t("settings.settingsSaved"));
    } catch (err) {
      setViewer({ ...viewer, isPrivate: !value });
      toast.error(errorMessage(err, t));
    } finally {
      setPending(null);
    }
  }

  return (
    <SettingsShell title={t("settings.privacy")}>
      {loading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-subtle">
          <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <p className="text-[13px] text-subtle">{error}</p>
          <Button size="sm" variant="outline" onClick={load}>
            {t("common.retry")}
          </Button>
        </div>
      ) : (
        <>
          <SettingsGroup title={t("settings.privacy")}>
            <SettingsRow
              label={t("settings.privateAccount")}
              description={t("settings.privateAccountDesc")}
              trailing={
                <Switch
                  checked={Boolean(viewer.isPrivate)}
                  onCheckedChange={togglePrivate}
                  disabled={pending === "private"}
                />
              }
            />
            <SettingsRow
              label={t("settings.activityStatus")}
              description={t("settings.activityStatusDesc")}
              trailing={
                <Switch
                  checked={settings?.activityStatus ?? true}
                  onCheckedChange={(value) => patch("activity", { activityStatus: value })}
                  disabled={pending === "activity"}
                />
              }
            />
            <SettingsRow
              label={t("settings.mediaFilter")}
              description={t("settings.mediaFilterDesc")}
              trailing={
                <Switch
                  checked={settings?.mediaFilterStrict ?? true}
                  onCheckedChange={(value) => patch("filter", { mediaFilterStrict: value })}
                  disabled={pending === "filter"}
                />
              }
            />
          </SettingsGroup>

          <SettingsGroup title={t("settings.messagePrivacy")}>
            <div className="space-y-2 px-4 py-4">
              <p className="text-[13px] font-medium">{t("settings.messagePrivacy")}</p>
              <p className="text-[11px] text-subtle">{t("settings.messagePrivacyDesc")}</p>
              <Select
                value={settings?.messagePrivacy ?? "everyone"}
                onValueChange={(value) => patch("privacy", { messagePrivacy: value })}
                disabled={pending === "privacy"}
              >
                <SelectTrigger className="h-10 w-full border-line bg-app text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="everyone">{t("settings.everyone")}</SelectItem>
                  <SelectItem value="followers">{t("settings.followersOnly")}</SelectItem>
                  <SelectItem value="noone">{t("settings.noOne")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </SettingsGroup>

          <SettingsGroup>
            <SettingsRow label={t("settings.blocked")} href="/settings/blocked" />
          </SettingsGroup>
        </>
      )}
    </SettingsShell>
  );
}
