"use client";

import { Bookmark } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { PostGrid } from "@/components/feed/post-grid";

export default function SavedPage() {
  const { t } = useI18n();
  return (
    <div className="mx-auto w-full max-w-[935px] px-4 pb-10 pt-4 md:pt-8">
      <div className="mb-5 flex items-center gap-2">
        <Bookmark className="size-5" strokeWidth={1.7} />
        <h1 className="text-[18px] font-semibold">{t("profile.saved")}</h1>
      </div>
      <PostGrid scope="saved" />
    </div>
  );
}
