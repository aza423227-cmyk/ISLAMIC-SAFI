"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, UserX } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { UserAvatar } from "@/components/user/avatar";
import { SettingsShell } from "@/components/settings/settings-ui";
import { Button } from "@/components/ui/button";

type BlockedUser = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
};

export default function BlockedSettingsPage() {
  const { t } = useI18n();
  const [users, setUsers] = useState<BlockedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<{ users: BlockedUser[] }>("/api/blocked");
      setUsers(data.users);
      setError(null);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  async function unblock(user: BlockedUser) {
    setPendingId(user.id);
    try {
      await api(`/api/blocked?userId=${user.id}`, { method: "DELETE" });
      setUsers((current) => current.filter((item) => item.id !== user.id));
      toast.success(t("settings.settingsSaved"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPendingId(null);
    }
  }

  return (
    <SettingsShell title={t("settings.blocked")}>
      {loading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-subtle">
          <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <p className="text-[13px] text-subtle">{error}</p>
          <Button size="sm" variant="outline" onClick={load}>
            {t("common.retry")}
          </Button>
        </div>
      ) : users.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-16 text-center">
          <div className="grid size-14 place-items-center rounded-full border border-line">
            <UserX className="size-6" strokeWidth={1.4} />
          </div>
          <p className="text-[14px] font-semibold">{t("settings.noBlocked")}</p>
        </div>
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
          {users.map((user) => (
            <li key={user.id} className="flex items-center gap-3 px-4 py-3">
              <UserAvatar name={user.name} image={user.image} size="md" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-semibold">
                  {user.username ? `@${user.username}` : user.name}
                </p>
                <p className="truncate text-[11px] text-subtle">{user.name}</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => unblock(user)}
                disabled={pendingId === user.id}
                className="h-8 text-[12px]"
              >
                {pendingId === user.id ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  t("common.remove")
                )}
              </Button>
            </li>
          ))}
        </ul>
      )}
    </SettingsShell>
  );
}
