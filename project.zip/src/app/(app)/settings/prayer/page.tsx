"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, MapPin, Sunset } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { SettingsGroup, SettingsShell } from "@/components/settings/settings-ui";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Settings = {
  prayerMethod: string;
  remindersEnabled: boolean;
  reminderMinutes: number;
  latitude: string | null;
  longitude: string | null;
  city: string | null;
  country: string | null;
};

const METHODS = [
  { id: "3", key: "prayer.methodMwl" },
  { id: "2", key: "prayer.methodIsna" },
  { id: "5", key: "prayer.methodEgypt" },
  { id: "4", key: "prayer.methodMakkah" },
  { id: "1", key: "prayer.methodKarachi" },
  { id: "13", key: "prayer.methodTurkey" },
  { id: "12", key: "prayer.methodFrance" },
  { id: "16", key: "prayer.methodDubai" },
];

export default function PrayerSettingsPage() {
  const { t } = useI18n();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [locating, setLocating] = useState(false);
  const [form, setForm] = useState<Settings>({
    prayerMethod: "3",
    remindersEnabled: false,
    reminderMinutes: 10,
    latitude: null,
    longitude: null,
    city: null,
    country: null,
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<{ settings: Settings | null }>("/api/settings");
      if (data.settings) {
        setSettings(data.settings);
        setForm(data.settings);
      }
      setError(null);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  async function detectLocation() {
    if (!("geolocation" in navigator)) {
      toast.error(t("prayer.locationDenied"));
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude.toFixed(6);
        const lng = position.coords.longitude.toFixed(6);
        setForm((current) => ({ ...current, latitude: lat, longitude: lng }));
        try {
          localStorage.setItem("ib-coords", JSON.stringify({ lat, lng }));
        } catch {
          /* ignore */
        }
        setLocating(false);
        toast.success(t("prayer.saved"));
      },
      () => {
        setLocating(false);
        toast.error(t("prayer.locationDenied"));
      },
      { timeout: 8000 },
    );
  }

  async function save() {
    setSaving(true);
    try {
      if (form.remindersEnabled && typeof Notification !== "undefined") {
        const permission = await Notification.requestPermission();
        if (permission === "denied") toast.error(t("prayer.notificationsBlocked"));
      }
      const data = await api<{ settings: Settings }>("/api/settings", {
        method: "PATCH",
        body: JSON.stringify({
          prayerMethod: form.prayerMethod,
          remindersEnabled: form.remindersEnabled,
          reminderMinutes: form.reminderMinutes,
          latitude: form.latitude ?? "",
          longitude: form.longitude ?? "",
        }),
      });
      setSettings(data.settings);
      toast.success(t("prayer.saved"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setSaving(false);
    }
  }

  return (
    <SettingsShell title={t("settings.prayerSettings")}>
      {loading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-subtle">
          <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <p className="text-[13px] text-subtle">{error}</p>
          <Button size="sm" variant="outline" onClick={load}>
            {t("common.retry")}
          </Button>
        </div>
      ) : (
        <>
          <SettingsGroup title={t("prayer.location")}>
            <div className="space-y-3 px-4 py-4">
              <div className="flex items-center gap-2 text-[12px] text-subtle">
                <MapPin className="size-4" />
                {form.latitude && form.longitude
                  ? `${Number(form.latitude).toFixed(3)}, ${Number(form.longitude).toFixed(3)}`
                  : t("prayer.enableLocation")}
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={detectLocation}
                disabled={locating}
                className="h-8 text-[12px]"
              >
                {locating ? <Loader2 className="size-3.5 animate-spin" /> : <Sunset className="size-3.5" />}
                {t("prayer.detect")}
              </Button>
            </div>
          </SettingsGroup>

          <SettingsGroup title={t("prayer.method")}>
            <div className="space-y-2 px-4 py-4">
              <Label className="text-[11px] text-subtle">{t("prayer.method")}</Label>
              <Select
                value={form.prayerMethod}
                onValueChange={(value) => setForm({ ...form, prayerMethod: value })}
              >
                <SelectTrigger className="h-10 w-full border-line bg-app text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {METHODS.map((method) => (
                    <SelectItem key={method.id} value={method.id}>
                      {t(method.key)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </SettingsGroup>

          <SettingsGroup title={t("prayer.enableReminders")}>
            <div className="flex items-center justify-between px-4 py-4">
              <div className="pe-3">
                <p className="text-[13px] font-medium">{t("prayer.enableReminders")}</p>
                <p className="text-[11px] text-subtle">{t("prayer.remindersDesc")}</p>
              </div>
              <Switch
                checked={form.remindersEnabled}
                onCheckedChange={(value) => setForm({ ...form, remindersEnabled: value })}
              />
            </div>
            <div className="space-y-2 px-4 py-4">
              <Label className="text-[11px] text-subtle">{t("settings.reminderBefore")}</Label>
              <Select
                value={String(form.reminderMinutes)}
                onValueChange={(value) => setForm({ ...form, reminderMinutes: Number(value) })}
              >
                <SelectTrigger className="h-10 w-full border-line bg-app text-[13px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[0, 5, 10, 15, 20, 30].map((minutes) => (
                    <SelectItem key={minutes} value={String(minutes)}>
                      {minutes === 0 ? t("common.now") : `${minutes} ${t("common.minutes")}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </SettingsGroup>

          <Button
            onClick={save}
            disabled={saving}
            className="h-10 w-full rounded-lg bg-brand text-[13px] font-semibold text-white hover:bg-brand-hover"
          >
            {saving ? <Loader2 className="size-4 animate-spin" /> : t("settings.saveSettings")}
          </Button>
        </>
      )}
    </SettingsShell>
  );
}
