"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  BadgeCheck,
  BookOpen,
  CircleDot,
  Loader2,
  Search,
  Sunset,
  MoonStar,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { PostGrid } from "@/components/feed/post-grid";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type SearchUser = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
  bio: string | null;
  is_following: boolean;
};

export default function ExplorePage() {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<SearchUser[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [following, setFollowing] = useState<Record<string, boolean>>({});

  const tools = useMemo(
    () => [
      { href: "/prayer", label: t("explore.prayerTimes"), icon: Sunset },
      { href: "/quran", label: t("explore.quranLibrary"), icon: BookOpen },
      { href: "/tasbih", label: t("explore.tasbih"), icon: CircleDot },
      { href: "/get-verified", label: t("explore.verifiedBadge"), icon: BadgeCheck },
    ],
    [t],
  );

  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setUsers([]);
      setSearchError(null);
      return;
    }
    let cancelled = false;
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const data = await api<{ users: SearchUser[] }>(
          `/api/users/search?q=${encodeURIComponent(trimmed)}`,
        );
        if (!cancelled) setUsers(data.users);
      } catch (err) {
        if (!cancelled) setSearchError(errorMessage(err, t));
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, t]);

  async function toggleFollow(user: SearchUser) {
    if (!user.username) return;
    setPendingId(user.id);
    try {
      const result = await api<{ following: boolean }>(`/api/users/${user.username}/follow`, {
        method: "POST",
      });
      setFollowing((current) => ({ ...current, [user.id]: result.following }));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPendingId(null);
    }
  }

  const isSearching = query.trim().length > 0;

  return (
    <div className="mx-auto w-full max-w-[935px] px-0 pb-6 md:px-4 lg:py-6">
      <div className="sticky top-12 z-20 bg-app/95 px-3 py-3 backdrop-blur md:top-0 md:px-0">
        <div className="relative">
          <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-subtle" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("explore.placeholder")}
            aria-label={t("common.search")}
            className="h-10 rounded-lg border-0 bg-hover ps-9 text-[14px] focus-visible:ring-1 focus-visible:ring-line"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label={t("common.close")}
              className="absolute inset-y-0 end-2 my-auto grid size-7 place-items-center rounded-full text-subtle hover:bg-active"
            >
              <X className="size-4" />
            </button>
          ) : null}
        </div>
      </div>

      {!isSearching ? (
        <div className="space-y-6 px-3 md:px-0">
          <div className="grid grid-cols-4 gap-2">
            {tools.map((tool) => {
              const Icon = tool.icon;
              return (
                <Link
                  key={tool.href}
                  href={tool.href}
                  className="flex flex-col items-center gap-2 rounded-xl border border-line bg-surface px-2 py-3.5 text-center transition-colors hover:bg-hover/50"
                >
                  <span className="grid size-10 place-items-center rounded-full bg-[#c8a45c]/10 text-[#a8853f]">
                    <Icon className="size-5" strokeWidth={1.6} />
                  </span>
                  <span className="text-[10px] font-medium leading-tight text-ink">
                    {tool.label}
                  </span>
                </Link>
              );
            })}
          </div>

          <Link
            href="/messages/ai"
            className="flex items-center gap-3 rounded-xl border border-line bg-gradient-to-br from-[#101f1a] to-[#0a1210] px-4 py-4 text-[#efe6d2]"
          >
            <span className="grid size-10 place-items-center rounded-full bg-white/10">
              <MoonStar className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-semibold">{t("explore.aiAssistant")}</p>
              <p className="truncate text-[11px] text-[#c9bda2]">{t("explore.aiAssistantDesc")}</p>
            </div>
            <span className="text-[11px] text-[#c9bda2]">{t("messages.startChat")}</span>
          </Link>

          <div>
            <div className="flex items-center justify-between pb-2">
              <h2 className="text-[13px] font-semibold text-subtle">{t("explore.trending")}</h2>
            </div>
            <PostGrid scope="explore" />
          </div>
        </div>
      ) : (
        <div className="px-3 pt-1 md:px-0">
          {searching ? (
            <div className="flex items-center justify-center gap-2 py-14 text-[13px] text-subtle">
              <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
            </div>
          ) : searchError ? (
            <div className="flex flex-col items-center gap-3 py-14 text-center">
              <p className="text-[13px] text-subtle">{searchError}</p>
              <Button variant="outline" size="sm" onClick={() => setQuery(query + " ")}>
                {t("common.retry")}
              </Button>
            </div>
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-16 text-center">
              <Search className="size-8 text-subtle" strokeWidth={1.3} />
              <p className="text-[14px] font-semibold">{t("explore.noUsers")}</p>
              <p className="text-[12px] text-subtle">{t("common.noResults")}</p>
            </div>
          ) : (
            <ul className="divide-y divide-line">
              {users.map((user) => {
                const isFollowing = following[user.id] ?? user.is_following;
                return (
                  <li key={user.id} className="flex items-center gap-3 py-3">
                    <Link href={user.username ? `/u/${user.username}` : "/explore"}>
                      <UserAvatar name={user.name} image={user.image} size="md" />
                    </Link>
                    <div className="min-w-0 flex-1 leading-tight">
                      <Link
                        href={user.username ? `/u/${user.username}` : "/explore"}
                        className="flex items-center gap-1 truncate text-[13px] font-semibold"
                      >
                        {user.username ?? user.name}
                        {user.verified ? <VerifiedBadge size={12} /> : null}
                      </Link>
                      <p className="truncate text-[12px] text-subtle">{user.name}</p>
                      {user.bio ? (
                        <p className="truncate text-[11px] text-subtle/80">{user.bio}</p>
                      ) : null}
                    </div>
                    <Button
                      size="sm"
                      onClick={() => toggleFollow(user)}
                      disabled={pendingId === user.id}
                      className={cn(
                        "h-8 min-w-[82px] rounded-lg text-[12px] font-semibold",
                        isFollowing
                          ? "bg-hover text-ink hover:bg-active"
                          : "bg-brand text-white hover:bg-brand-hover",
                      )}
                    >
                      {pendingId === user.id ? (
                        <Loader2 className="size-3.5 animate-spin" />
                      ) : isFollowing ? (
                        t("common.following")
                      ) : (
                        t("common.follow")
                      )}
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
