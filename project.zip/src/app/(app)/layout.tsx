import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { getSessionUser, isVerified } from "@/lib/session";
import { db } from "@/lib/db";
import { userSettings } from "@/lib/schema";
import { AppProvider, type Viewer } from "@/components/app/app-context";
import { AppShell } from "@/components/app/app-shell";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/auth/sign-in");

  const settings = await db.query.userSettings.findFirst({
    where: eq(userSettings.userId, user.id),
  });

  const viewer: Viewer = {
    id: user.id,
    name: user.name,
    email: user.email,
    image: user.image ?? null,
    username: user.username ?? null,
    displayUsername: user.displayUsername ?? null,
    bio: user.bio ?? "",
    website: user.website ?? "",
    isPrivate: Boolean(user.isPrivate),
    verified: isVerified(user),
    verifiedUntil: user.verifiedUntil ? new Date(user.verifiedUntil).toISOString() : null,
    language: settings?.language ?? user.language ?? null,
  };

  return (
    <AppProvider viewer={viewer}>
      <AppShell initialTheme={settings?.theme ?? null} initialLanguage={settings?.language ?? null}>
        {children}
      </AppShell>
    </AppProvider>
  );
}
