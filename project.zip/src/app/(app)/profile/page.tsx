import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/session";

export default async function ProfileRedirect() {
  const user = await getSessionUser();
  if (!user) redirect("/auth/sign-in");
  if (user.username) redirect(`/u/${user.username}`);
  redirect("/settings/account");
}
