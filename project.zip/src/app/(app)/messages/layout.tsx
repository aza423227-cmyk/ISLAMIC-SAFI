"use client";

import { usePathname } from "next/navigation";
import { ConversationList } from "@/components/messages/conversation-list";
import { cn } from "@/lib/utils";

export default function MessagesLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isChat = pathname !== "/messages";

  return (
    <div className="flex h-[calc(100dvh-104px-env(safe-area-inset-bottom))] overflow-hidden md:h-dvh">
      <div
        className={cn(
          "h-full w-full shrink-0 border-line bg-surface md:w-[380px] md:border-e",
          isChat && "hidden md:block",
        )}
      >
        <ConversationList />
      </div>
      <div className={cn("h-full min-w-0 flex-1 bg-surface", !isChat && "hidden md:flex")}>
        {children}
      </div>
    </div>
  );
}
