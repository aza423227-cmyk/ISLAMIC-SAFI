"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Loader2, Send, MoonStar, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type AiMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt?: string;
  pending?: boolean;
};

export default function AiAssistantPage() {
  const { t, locale } = useI18n();
  const [messages, setMessages] = useState<AiMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const quick = [t("ai.quick1"), t("ai.quick2"), t("ai.quick3"), t("ai.quick4")];

  const load = useCallback(async () => {
    try {
      const data = await api<{ messages: AiMessage[] }>("/api/ai");
      setMessages(data.messages);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTo({ top: node.scrollHeight, behavior: "smooth" });
  }, [messages.length, sending]);

  async function ask(question: string) {
    const trimmed = question.trim();
    if (!trimmed || sending) return;
    setSending(true);
    setText("");
    const tempId = `temp-${Date.now()}`;
    setMessages((current) => [
      ...current,
      { id: tempId, role: "user", content: trimmed },
      { id: `${tempId}-pending`, role: "assistant", content: "", pending: true },
    ]);
    try {
      const data = await api<{ messages: AiMessage[] }>("/api/ai", {
        method: "POST",
        body: JSON.stringify({ question: trimmed, locale }),
      });
      setMessages((current) => [
        ...current.filter((message) => message.id !== tempId && message.id !== `${tempId}-pending`),
        ...data.messages,
      ]);
    } catch (err) {
      setMessages((current) =>
        current.filter((message) => message.id !== tempId && message.id !== `${tempId}-pending`),
      );
      setText(trimmed);
      toast.error(errorMessage(err, t));
    } finally {
      setSending(false);
    }
  }

  async function clearChat() {
    try {
      await api("/api/ai", { method: "DELETE" });
      setMessages([]);
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  return (
    <div className="flex h-full flex-col bg-surface">
      <header className="flex h-[60px] items-center gap-3 border-b border-line px-3">
        <Link
          href="/messages"
          aria-label={t("common.back")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover md:hidden"
        >
          <ArrowLeft className="size-5 rtl:rotate-180" />
        </Link>
        <span className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-[#1c3b31] to-[#0a1210] text-[#e7d9b4]">
          <MoonStar className="size-4" />
        </span>
        <div className="min-w-0 flex-1 leading-tight">
          <p className="text-[13px] font-semibold">{t("messages.aiAssistant")}</p>
          <p className="truncate text-[11px] text-subtle">{t("explore.aiAssistantDesc")}</p>
        </div>
        {messages.length > 0 ? (
          <button
            type="button"
            onClick={clearChat}
            aria-label={t("common.delete")}
            className="grid size-9 place-items-center rounded-full text-subtle transition-colors hover:bg-hover hover:text-ink"
          >
            <Trash2 className="size-4" />
          </button>
        ) : null}
      </header>

      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-3 py-4">
        <div className="rounded-xl border border-line bg-app px-3.5 py-3">
          <p className="text-[11px] leading-relaxed text-subtle">{t("messages.aiDisclaimer")}</p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-10 text-[12px] text-subtle">
            <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
          </div>
        ) : error ? (
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <p className="text-[13px] text-subtle">{error}</p>
            <Button size="sm" variant="outline" onClick={load}>
              {t("common.retry")}
            </Button>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center gap-4 py-8 text-center">
            <span className="grid size-16 place-items-center rounded-full bg-gradient-to-br from-[#1c3b31] to-[#0a1210] text-[#e7d9b4]">
              <MoonStar className="size-7" />
            </span>
            <p className="max-w-[20rem] text-[14px] leading-relaxed">
              {t("messages.aiWelcome")}
            </p>
            <div className="grid w-full max-w-[380px] gap-2">
              {quick.map((question) => (
                <button
                  key={question}
                  type="button"
                  onClick={() => ask(question)}
                  className="rounded-lg border border-line bg-app px-3 py-2.5 text-start text-[12px] transition-colors hover:bg-hover"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={cn("flex", message.role === "user" ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[85%] whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed",
                  message.role === "user"
                    ? "rounded-br-md bg-brand text-white"
                    : "rounded-bl-md bg-hover text-ink",
                )}
              >
                {message.pending ? (
                  <span className="flex items-center gap-2 text-subtle">
                    <Loader2 className="size-3.5 animate-spin" /> {t("messages.aiThinking")}
                  </span>
                ) : (
                  message.content
                )}
              </div>
            </div>
          ))
        )}
      </div>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          ask(text);
        }}
        className="flex items-center gap-2 border-t border-line px-3 py-2 pb-[calc(8px+env(safe-area-inset-bottom))] md:pb-2"
      >
        <input
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder={t("messages.aiPlaceholder")}
          aria-label={t("messages.aiPlaceholder")}
          className="h-10 flex-1 rounded-full border border-line bg-app px-4 text-[13px] outline-none focus:ring-1 focus:ring-line"
        />
        <button
          type="submit"
          disabled={!text.trim() || sending}
          aria-label={t("common.send")}
          className="grid size-10 place-items-center rounded-full text-brand transition-transform active:scale-95 disabled:opacity-40"
        >
          {sending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-5" />}
        </button>
      </form>
    </div>
  );
}
