"use client";

import { MessageCircle } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";

export default function MessagesPage() {
  const { t } = useI18n();
  return (
    <div className="hidden h-full flex-col items-center justify-center gap-3 px-6 text-center md:flex">
      <div className="grid size-20 place-items-center rounded-full border border-line">
        <MessageCircle className="size-9 text-ink" strokeWidth={1.2} />
      </div>
      <p className="text-[18px] font-medium">{t("messages.emptyTitle")}</p>
      <p className="max-w-[18rem] text-[13px] leading-relaxed text-subtle">
        {t("messages.emptyBody")}
      </p>
    </div>
  );
}
