"use client";

import { ChatView } from "@/components/messages/chat-view";

export default function ConversationPage() {
  return <ChatView />;
}
