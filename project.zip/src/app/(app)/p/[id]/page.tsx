"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import type { FeedPost } from "@/lib/queries";
import { PostCard } from "@/components/feed/post-card";
import { Button } from "@/components/ui/button";

export default function PostDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { t } = useI18n();
  const [post, setPost] = useState<FeedPost | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api<{ post: FeedPost }>(`/api/posts/${params.id}`)
      .then((data) => {
        if (!cancelled) setPost(data.post);
      })
      .catch((err) => {
        if (!cancelled) setError(errorMessage(err, t));
      });
    return () => {
      cancelled = true;
    };
  }, [params.id, t]);

  return (
    <div className="mx-auto w-full max-w-[630px] py-0 md:px-4 md:py-6">
      <div className="flex items-center gap-2 px-3 py-2.5">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label={t("common.back")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
        >
          <ArrowLeft className="size-5 rtl:rotate-180" />
        </button>
        <p className="text-[15px] font-semibold">{t("common.post")}</p>
      </div>

      {error ? (
        <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
          <p className="text-[13px] text-subtle">{error}</p>
          <Button size="sm" variant="outline" onClick={() => router.push("/")}>
            {t("nav.home")}
          </Button>
        </div>
      ) : !post ? (
        <div className="grid place-items-center py-16">
          <Loader2 className="size-5 animate-spin text-subtle" />
        </div>
      ) : (
        <div className="md:mt-3">
          <PostCard post={post} />
          <p className="px-3 py-4 text-center text-[11px] text-subtle">
            <Link href={post.username ? `/u/${post.username}` : "/explore"} className="font-semibold">
              @{post.username ?? post.name}
            </Link>
          </p>
        </div>
      )}
    </div>
  );
}
