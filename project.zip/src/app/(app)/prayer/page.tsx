"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  BellRing,
  Loader2,
  MapPin,
  RefreshCw,
  Settings2,
  Sun,
  Sunrise,
  Sunset,
  Moon,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

type PrayerData = {
  timings: Record<string, string>;
  date: string;
  timezone: string;
  method: string;
};

type UserSettings = {
  prayerMethod: string;
  remindersEnabled: boolean;
  reminderMinutes: number;
  latitude: string | null;
  longitude: string | null;
};

const PRAYERS = [
  { key: "Fajr", label: "prayer.fajr", icon: Sunrise },
  { key: "Sunrise", label: "prayer.sunrise", icon: Sun },
  { key: "Dhuhr", label: "prayer.dhuhr", icon: Sun },
  { key: "Asr", label: "prayer.asr", icon: Sun },
  { key: "Maghrib", label: "prayer.maghrib", icon: Sunset },
  { key: "Isha", label: "prayer.isha", icon: Moon },
];

function toDate(time: string) {
  const [hour, minute] = time.split(":").map(Number);
  const date = new Date();
  date.setHours(hour || 0, minute || 0, 0, 0);
  return date;
}

function formatCountdown(ms: number, hoursLabel: string, minutesLabel: string) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return `${hours > 0 ? `${hours}${hoursLabel} ` : ""}${minutes}${minutesLabel} ${seconds.toString().padStart(2, "0")}s`;
}

export default function PrayerPage() {
  const { t, locale } = useI18n();
  const [data, setData] = useState<PrayerData | null>(null);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [now, setNow] = useState(new Date());
  const [locating, setLocating] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">(
    "unsupported",
  );

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (typeof Notification !== "undefined") setPermission(Notification.permission);
  }, []);

  const fetchTimes = useCallback(
    async (lat: number, lng: number, method: string) => {
      setLoading(true);
      setError(null);
      try {
        const result = await api<PrayerData>(
          `/api/prayer?lat=${lat}&lng=${lng}&method=${method}`,
        );
        setData(result);
        setCoords({ lat, lng });
      } catch (err) {
        setError(errorMessage(err, t));
      } finally {
        setLoading(false);
      }
    },
    [t],
  );

  useEffect(() => {
    let cancelled = false;
    async function init() {
      let method = "3";
      try {
        const result = await api<{ settings: UserSettings | null }>("/api/settings");
        if (result.settings) {
          setSettings(result.settings);
          method = result.settings.prayerMethod;
          if (result.settings.latitude && result.settings.longitude) {
            const lat = Number(result.settings.latitude);
            const lng = Number(result.settings.longitude);
            if (!cancelled) fetchTimes(lat, lng, method);
            return;
          }
        }
      } catch {
        /* ignore settings failure */
      }
      try {
        const stored = localStorage.getItem("ib-coords");
        if (stored) {
          const parsed = JSON.parse(stored) as { lat: number; lng: number };
          if (!cancelled) fetchTimes(parsed.lat, parsed.lng, method);
          return;
        }
      } catch {
        /* ignore */
      }
      detectLocation(method);
    }
    init();
    return () => {
      cancelled = true;
      // eslint-disable-next-line react-hooks/exhaustive-deps
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function detectLocation(method?: string) {
    if (!("geolocation" in navigator)) {
      setLoading(false);
      setError(t("prayer.locationDenied"));
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setLocating(false);
        try {
          localStorage.setItem("ib-coords", JSON.stringify({ lat, lng }));
        } catch {
          /* ignore */
        }
        fetchTimes(lat, lng, method ?? settings?.prayerMethod ?? "3");
        api("/api/settings", {
          method: "PATCH",
          body: JSON.stringify({
            latitude: lat.toFixed(6),
            longitude: lng.toFixed(6),
          }),
        }).catch(() => undefined);
      },
      () => {
        setLocating(false);
        setLoading(false);
        setError(t("prayer.locationDenied"));
      },
      { timeout: 9000, maximumAge: 60000 },
    );
  }

  const nextPrayer = (() => {
    if (!data) return null;
    for (const prayer of PRAYERS) {
      if (prayer.key === "Sunrise") continue;
      const time = toDate(data.timings[prayer.key] ?? "00:00");
      if (time.getTime() > now.getTime()) {
        return { ...prayer, time, diff: time.getTime() - now.getTime() };
      }
    }
    const fajr = toDate(data.timings.Fajr ?? "00:00");
    const tomorrow = new Date(fajr);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return {
      ...PRAYERS[0],
      time: tomorrow,
      diff: tomorrow.getTime() - now.getTime(),
    };
  })();

  async function toggleReminders(value: boolean) {
    setSettings((current) => (current ? { ...current, remindersEnabled: value } : current));
    if (value && typeof Notification !== "undefined") {
      const result = await Notification.requestPermission();
      setPermission(result);
      if (result === "denied") toast.error(t("prayer.notificationsBlocked"));
    }
    try {
      await api("/api/settings", {
        method: "PATCH",
        body: JSON.stringify({ remindersEnabled: value }),
      });
      toast.success(t("prayer.saved"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  async function refresh() {
    if (coords) await fetchTimes(coords.lat, coords.lng, settings?.prayerMethod ?? "3");
    else detectLocation();
  }

  return (
    <div className="mx-auto w-full max-w-[640px] px-4 pb-12 pt-4 md:pt-8">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-semibold">{t("prayer.title")}</h1>
          <p className="text-[12px] text-subtle">{t("prayer.subtitle")}</p>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={refresh}
            aria-label={t("prayer.refresh")}
            className="grid size-9 place-items-center rounded-full text-subtle transition-colors hover:bg-hover hover:text-ink"
          >
            <RefreshCw className={cn("size-4", (loading || locating) && "animate-spin")} />
          </button>
          <Link
            href="/settings/prayer"
            aria-label={t("settings.prayerSettings")}
            className="grid size-9 place-items-center rounded-full text-subtle transition-colors hover:bg-hover hover:text-ink"
          >
            <Settings2 className="size-4" />
          </Link>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          <div className="h-40 animate-pulse rounded-2xl bg-hover" />
          <div className="h-64 animate-pulse rounded-2xl bg-hover" />
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-line bg-surface px-6 py-14 text-center">
          <MapPin className="size-8 text-subtle" strokeWidth={1.4} />
          <p className="max-w-[22rem] text-[13px] leading-relaxed text-subtle">{error}</p>
          <Button size="sm" onClick={() => detectLocation()}>
            {t("prayer.enableLocation")}
          </Button>
        </div>
      ) : data ? (
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-2xl border border-line bg-gradient-to-br from-[#0f1f1a] via-[#142a22] to-[#0a1210] px-5 py-6 text-[#efe6d2]">
            <div className="absolute -end-8 -top-8 size-32 rounded-full bg-[#c8a45c]/10 blur-2xl" />
            <p className="flex items-center gap-1.5 text-[11px] text-[#c9bda2]">
              <MapPin className="size-3.5" />
              {coords
                ? `${coords.lat.toFixed(3)}, ${coords.lng.toFixed(3)}`
                : t("prayer.location")}
              <span className="text-[#c9bda2]/60">· {data.timezone}</span>
            </p>
            <p className="mt-1 text-[11px] uppercase tracking-[0.14em] text-[#c9bda2]/80">
              {data.date}
            </p>
            {nextPrayer ? (
              <div className="mt-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.18em] text-[#c9bda2]">
                    {t("prayer.nextPrayer")}
                  </p>
                  <p className="mt-1 font-wordmark text-[34px] leading-none text-[#f3e9d2]">
                    {t(nextPrayer.label)}
                  </p>
                  <p className="mt-2 text-[13px] text-[#e7d9b4]">
                    {data.timings[nextPrayer.key] ?? ""}
                  </p>
                </div>
                <p className="text-end text-[11px] text-[#c9bda2]">
                  {t("prayer.remaining")}
                  <br />
                  <span className="text-[16px] font-semibold text-[#efe6d2]">
                    {formatCountdown(nextPrayer.diff, t("common.hourShort"), t("common.minutes"))}
                  </span>
                </p>
              </div>
            ) : null}
          </div>

          <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
            {PRAYERS.map((prayer) => {
              const Icon = prayer.icon;
              const isNext = nextPrayer?.key === prayer.key;
              return (
                <div
                  key={prayer.key}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3.5",
                    isNext && "bg-[#c8a45c]/5",
                  )}
                >
                  <span
                    className={cn(
                      "grid size-9 place-items-center rounded-full",
                      isNext ? "bg-[#c8a45c]/15 text-[#a8853f]" : "bg-hover text-subtle",
                    )}
                  >
                    <Icon className="size-4" strokeWidth={1.7} />
                  </span>
                  <div className="flex-1">
                    <p className={cn("text-[13px]", isNext ? "font-semibold" : "font-medium")}>
                      {t(prayer.label)}
                    </p>
                    {isNext ? (
                      <p className="text-[10px] uppercase tracking-wider text-[#a8853f]">
                        {t("prayer.nextPrayer")}
                      </p>
                    ) : null}
                  </div>
                  <p className="text-[15px] font-semibold tabular-nums">
                    {data.timings[prayer.key] ?? "—"}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="rounded-2xl border border-line bg-surface">
            <div className="flex items-center gap-3 px-4 py-3.5">
              <span className="grid size-9 place-items-center rounded-full bg-hover text-subtle">
                <BellRing className="size-4" strokeWidth={1.7} />
              </span>
              <div className="flex-1 pe-2">
                <p className="text-[13px] font-medium">{t("prayer.enableReminders")}</p>
                <p className="text-[11px] text-subtle">
                  {settings?.remindersEnabled
                    ? `${t("settings.reminderBefore")} ${settings.reminderMinutes} ${t("common.minutes")}`
                    : t("prayer.remindersDesc")}
                </p>
              </div>
              <Switch
                checked={settings?.remindersEnabled ?? false}
                onCheckedChange={toggleReminders}
              />
            </div>
            {permission === "denied" ? (
              <p className="border-t border-line px-4 py-2.5 text-[11px] leading-relaxed text-destructive">
                {t("prayer.notificationsBlocked")}
              </p>
            ) : null}
          </div>

          <p className="px-1 text-[11px] text-subtle">
            {t("prayer.method")}: {data.method} ·{" "}
            <Link href="/settings/prayer" className="font-semibold text-brand">
              {t("common.edit")}
            </Link>
          </p>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-line bg-surface px-6 py-14 text-center">
          <Loader2 className="size-5 animate-spin text-subtle" />
          <Button size="sm" onClick={() => detectLocation()}>
            {t("prayer.enableLocation")}
          </Button>
        </div>
      )}
    </div>
  );
}
