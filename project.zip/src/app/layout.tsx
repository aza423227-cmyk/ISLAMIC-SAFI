import type { Metadata, Viewport } from "next";
import { Inter, Cormorant_Garamond, Amiri } from "next/font/google";
import Script from "next/script";
import { cookies, headers } from "next/headers";
import "./globals.css";
import { Providers } from "@/components/providers";
import { detectLocale, dirFor, isLocale, type Locale } from "@/lib/i18n";

const ui = Inter({
  variable: "--font-ui",
  subsets: ["latin", "latin-ext"],
  display: "swap",
});

const wordmark = Cormorant_Garamond({
  variable: "--font-wordmark",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  display: "swap",
});

const arabic = Amiri({
  variable: "--font-arabic",
  subsets: ["arabic"],
  weight: ["400", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "ISLAMIC BESSAFI",
    template: "%s · ISLAMIC BESSAFI",
  },
  description:
    "A refined Islamic social community: share halal content, follow the Ummah, pray on time and listen to the Quran.",
  applicationName: "ISLAMIC BESSAFI",
  appleWebApp: {
    capable: true,
    title: "ISLAMIC BESSAFI",
    statusBarStyle: "default",
  },
  formatDetection: { telephone: false },
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#000000" },
  ],
};

export default async function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const cookieStore = await cookies();
  const headerList = await headers();
  const stored = cookieStore.get("ib-locale")?.value;
  const initialLocale: Locale = isLocale(stored)
    ? stored
    : detectLocale(headerList.get("accept-language"));

  return (
    <html
      lang={initialLocale}
      dir={dirFor(initialLocale)}
      suppressHydrationWarning
      className={`${ui.variable} ${wordmark.variable} ${arabic.variable}`}
    >
      <body className="bg-app text-ink antialiased">
        <Providers initialLocale={initialLocale}>{children}</Providers>
        {/* WARNING FOR AGENT: DO NOT REMOVE THIS SCRIPT */}
        <Script src="https://cdn.jsdelivr.net/gh/IdeavoAI/ideavo-scripts@latest/scripts/ideavo.min.js" />
      </body>
    </html>
  );
}
