"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Loader2, MapPin, Sunset } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api } from "@/lib/api";

type PrayerResponse = {
  timings: Record<string, string>;
  date: string;
  timezone: string;
};

const ORDER = [
  { key: "Fajr", label: "prayer.fajr" },
  { key: "Dhuhr", label: "prayer.dhuhr" },
  { key: "Asr", label: "prayer.asr" },
  { key: "Maghrib", label: "prayer.maghrib" },
  { key: "Isha", label: "prayer.isha" },
];

function parseTime(value: string) {
  const [hour, minute] = value.split(":").map(Number);
  const date = new Date();
  date.setHours(hour || 0, minute || 0, 0, 0);
  return date;
}

export function PrayerMiniCard() {
  const { t } = useI18n();
  const [data, setData] = useState<PrayerResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let cancelled = false;
    function fetchTimes(lat: number, lng: number) {
      api<PrayerResponse>(`/api/prayer?lat=${lat}&lng=${lng}&method=3`)
        .then((result) => {
          if (!cancelled) setData(result);
        })
        .catch(() => {
          if (!cancelled) setError(true);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }
    try {
      const stored = localStorage.getItem("ib-coords");
      if (stored) {
        const coords = JSON.parse(stored) as { lat: number; lng: number };
        fetchTimes(coords.lat, coords.lng);
        return;
      }
    } catch {
      /* ignore */
    }
    if (!("geolocation" in navigator)) {
      setLoading(false);
      setError(true);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        try {
          localStorage.setItem("ib-coords", JSON.stringify(coords));
        } catch {
          /* ignore */
        }
        fetchTimes(coords.lat, coords.lng);
      },
      () => {
        setLoading(false);
        setError(true);
      },
      { timeout: 8000, maximumAge: 1000 * 60 * 60 * 6 },
    );
    return () => {
      cancelled = true;
    };
  }, []);

  let next: { label: string; time: string; countdown: string } | null = null;
  if (data) {
    for (const item of ORDER) {
      const time = parseTime(data.timings[item.key] ?? "00:00");
      if (time.getTime() > now.getTime()) {
        const diff = Math.max(0, time.getTime() - now.getTime());
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        next = {
          label: t(item.label),
          time: data.timings[item.key] ?? "",
          countdown: `${hours > 0 ? `${hours} ${t("common.hourShort")} ` : ""}${minutes} ${t("common.minutes")}`,
        };
        break;
      }
    }
    if (!next) {
      next = {
        label: t("prayer.fajr"),
        time: data.timings.Fajr ?? "",
        countdown: t("common.today"),
      };
    }
  }

  return (
    <Link
      href="/prayer"
      className="mt-4 block rounded-lg border border-line bg-surface p-3.5 transition-colors hover:bg-hover/40"
    >
      <div className="flex items-center gap-2.5">
        <span className="grid size-9 place-items-center rounded-full bg-[#c8a45c]/10 text-[#a8853f]">
          <Sunset className="size-[18px]" strokeWidth={1.6} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12px] font-semibold text-ink">{t("prayer.nextPrayer")}</p>
          {loading ? (
            <p className="flex items-center gap-1.5 text-[11px] text-subtle">
              <Loader2 className="size-3 animate-spin" /> {t("common.loading")}
            </p>
          ) : error ? (
            <p className="flex items-center gap-1 text-[11px] text-subtle">
              <MapPin className="size-3" /> {t("prayer.enableLocation")}
            </p>
          ) : next ? (
            <p className="truncate text-[11px] text-subtle">
              {next.label} · {next.time} · {next.countdown}
            </p>
          ) : null}
        </div>
      </div>
    </Link>
  );
}
