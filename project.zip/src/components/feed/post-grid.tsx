"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Heart, MessageCircle, Play, RefreshCw } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import type { FeedPost } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function PostGrid({
  scope,
  profileId,
  className,
}: {
  scope: "explore" | "profile" | "saved";
  profileId?: string;
  className?: string;
}) {
  const { t } = useI18n();
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ scope });
      if (profileId) params.set("profileId", profileId);
      const data = await api<{ posts: FeedPost[] }>(`/api/feed?${params.toString()}`);
      setPosts(data.posts);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [scope, profileId, t]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    function onDeleted(event: Event) {
      const id = (event as CustomEvent<string>).detail;
      setPosts((current) => current.filter((post) => post.id !== id));
    }
    window.addEventListener("ib:post-deleted", onDeleted);
    return () => window.removeEventListener("ib:post-deleted", onDeleted);
  }, []);

  if (loading) {
    return (
      <div className={cn("grid grid-cols-3 gap-0.5 sm:gap-1", className)}>
        {Array.from({ length: 9 }).map((_, index) => (
          <div key={index} className="aspect-square animate-pulse bg-hover" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center gap-3 py-14 text-center">
        <p className="text-[13px] text-subtle">{error}</p>
        <Button variant="outline" size="sm" onClick={load}>
          {t("common.retry")}
        </Button>
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 py-16 text-center">
        <div className="grid size-14 place-items-center rounded-full border border-line">
          <Heart className="size-6" strokeWidth={1.4} />
        </div>
        <p className="text-[14px] font-semibold">
          {scope === "saved" ? t("profile.noSavedTitle") : t("feed.noPostsTitle")}
        </p>
        <p className="max-w-[17rem] text-[12px] text-subtle">
          {scope === "saved" ? t("profile.noSavedBody") : t("profile.noPostsYet")}
        </p>
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="flex justify-end pb-1">
        <button
          type="button"
          onClick={() => {
            setRefreshing(true);
            load();
          }}
          aria-label={t("common.refresh")}
          className="grid size-8 place-items-center rounded-full text-subtle transition-colors hover:text-ink"
        >
          <RefreshCw className={cn("size-4", refreshing && "animate-spin")} />
        </button>
      </div>
      <div className="grid grid-cols-3 gap-0.5 sm:gap-1">
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/p/${post.id}`}
            className="group relative aspect-square overflow-hidden bg-hover"
          >
            {post.media_id ? (
              post.kind === "video" ? (
                <video
                  src={`/api/media/${post.media_id}`}
                  className="size-full object-cover"
                  muted
                  playsInline
                  preload="metadata"
                />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={`/api/media/${post.media_id}`}
                  alt={post.caption || t("common.post")}
                  className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  loading="lazy"
                />
              )
            ) : (
              <div className="grid size-full place-items-center text-subtle">
                <Heart className="size-6" />
              </div>
            )}
            {post.kind === "video" ? (
              <span className="absolute end-1.5 top-1.5 text-white drop-shadow">
                <Play className="size-4 fill-white" />
              </span>
            ) : null}
            <div className="absolute inset-0 hidden items-center justify-center gap-5 bg-black/40 text-white group-hover:flex">
              <span className="flex items-center gap-1 text-[13px] font-semibold">
                <Heart className="size-4 fill-white" /> {post.likes}
              </span>
              <span className="flex items-center gap-1 text-[13px] font-semibold">
                <MessageCircle className="size-4 fill-white" /> {post.comments}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
