"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { useApp } from "@/components/app/app-context";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type SuggestedUser = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
  bio: string | null;
  is_following: boolean;
};

export function SuggestionsCard() {
  const { t } = useI18n();
  const { viewer } = useApp();
  const [users, setUsers] = useState<SuggestedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [following, setFollowing] = useState<Record<string, boolean>>({});

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ users: SuggestedUser[] }>("/api/users/suggested");
      setUsers(data.users);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function toggle(user: SuggestedUser) {
    setPendingId(user.id);
    try {
      const result = await api<{ following: boolean }>(`/api/users/${user.username}/follow`, {
        method: "POST",
      });
      setFollowing((current) => ({ ...current, [user.id]: result.following }));
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPendingId(null);
    }
  }

  return (
    <section className="px-1">
      <div className="flex items-center gap-3 py-2">
        <Link href={viewer.username ? `/u/${viewer.username}` : "/settings/account"}>
          <UserAvatar name={viewer.name} image={viewer.image} size="md" />
        </Link>
        <div className="min-w-0 flex-1 leading-tight">
          <Link
            href={viewer.username ? `/u/${viewer.username}` : "/settings/account"}
            className="flex items-center gap-1 truncate text-[13px] font-semibold"
          >
            {viewer.username ?? viewer.name}
            {viewer.verified ? <VerifiedBadge size={12} /> : null}
          </Link>
          <p className="truncate text-[12px] text-subtle">{viewer.name}</p>
        </div>
        <Link href="/settings" className="text-[12px] font-semibold text-brand">
          {t("common.settings")}
        </Link>
      </div>

      <div className="flex items-center justify-between pt-3">
        <p className="text-[13px] font-semibold text-subtle">{t("feed.suggestions")}</p>
        <Link href="/explore" className="text-[12px] font-semibold text-ink">
          {t("common.seeAll")}
        </Link>
      </div>

      {loading ? (
        <div className="space-y-3 pt-3">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="size-8 animate-pulse rounded-full bg-hover" />
              <div className="flex-1 space-y-1.5">
                <div className="h-2 w-24 animate-pulse rounded-full bg-hover" />
                <div className="h-2 w-16 animate-pulse rounded-full bg-hover" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <button onClick={load} className="pt-3 text-[12px] text-brand">
          {t("common.retry")}
        </button>
      ) : users.length === 0 ? (
        <p className="pt-3 text-[12px] text-subtle">{t("explore.noUsers")}</p>
      ) : (
        <ul className="pt-2">
          {users.map((user) => {
            const isFollowing = following[user.id] ?? user.is_following;
            return (
              <li key={user.id} className="flex items-center gap-3 py-1.5">
                <Link href={user.username ? `/u/${user.username}` : "/explore"} className="shrink-0">
                  <UserAvatar name={user.name} image={user.image} size="sm" />
                </Link>
                <div className="min-w-0 flex-1 leading-tight">
                  <Link
                    href={user.username ? `/u/${user.username}` : "/explore"}
                    className="flex items-center gap-1 truncate text-[12px] font-semibold"
                  >
                    {user.username ?? user.name}
                    {user.verified ? <VerifiedBadge size={11} /> : null}
                  </Link>
                  <p className="truncate text-[11px] text-subtle">
                    {user.bio || t("profile.suggestedForYou")}
                  </p>
                </div>
                {user.username ? (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggle(user)}
                    disabled={pendingId === user.id}
                    className="h-7 px-0 text-[12px] font-semibold text-brand hover:bg-transparent"
                  >
                    {pendingId === user.id ? (
                      <Loader2 className="size-3.5 animate-spin" />
                    ) : isFollowing ? (
                      t("common.following")
                    ) : (
                      t("common.follow")
                    )}
                  </Button>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}

      <p className="pt-5 text-[11px] leading-relaxed text-subtle/80">
        ISLAMIC BESSAFI · {t("explore.tools")}
      </p>
    </section>
  );
}
