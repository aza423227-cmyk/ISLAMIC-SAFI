"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bookmark,
  Heart,
  MessageCircle,
  MoreHorizontal,
  Send,
  Trash2,
  Flag,
  Loader2,
  Link2,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatRelativeTime } from "@/lib/i18n";
import type { FeedPost } from "@/lib/queries";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { useApp } from "@/components/app/app-context";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type CommentRow = {
  id: string;
  body: string;
  created_at: string;
  user_id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
};

export function PostCard({ post: initialPost }: { post: FeedPost }) {
  const { t, locale } = useI18n();
  const { viewer } = useApp();
  const router = useRouter();
  const [post, setPost] = useState(initialPost);
  const [liking, setLiking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [doubleTapHeart, setDoubleTapHeart] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const lastTap = useRef(0);

  useEffect(() => setPost(initialPost), [initialPost]);

  const isOwner = viewer.id === post.user_id;
  const profileHref = post.username ? `/u/${post.username}` : "/explore";

  async function toggleLike() {
    if (liking) return;
    setLiking(true);
    setPost((current) => ({
      ...current,
      liked: !current.liked,
      likes: current.likes + (current.liked ? -1 : 1),
    }));
    try {
      const result = await api<{ liked: boolean; likes: number }>(
        `/api/posts/${post.id}/like`,
        { method: "POST" },
      );
      setPost((current) => ({ ...current, liked: result.liked, likes: result.likes }));
    } catch (err) {
      setPost((current) => ({
        ...current,
        liked: !current.liked,
        likes: current.likes + (current.liked ? -1 : 1),
      }));
      toast.error(errorMessage(err, t));
    } finally {
      setLiking(false);
    }
  }

  function onMediaTap() {
    const now = Date.now();
    if (now - lastTap.current < 300) {
      lastTap.current = 0;
      if (!post.liked) toggleLike();
      setDoubleTapHeart(true);
      setTimeout(() => setDoubleTapHeart(false), 700);
    } else {
      lastTap.current = now;
    }
  }

  async function toggleSave() {
    if (saving) return;
    setSaving(true);
    setPost((current) => ({ ...current, saved: !current.saved }));
    try {
      const result = await api<{ saved: boolean }>(`/api/posts/${post.id}/save`, {
        method: "POST",
      });
      setPost((current) => ({ ...current, saved: result.saved }));
      if (result.saved) toast.success(t("common.saved"));
    } catch (err) {
      setPost((current) => ({ ...current, saved: !current.saved }));
      toast.error(errorMessage(err, t));
    } finally {
      setSaving(false);
    }
  }

  async function copyLink() {
    const url = `${window.location.origin}/p/${post.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t("common.linkCopied"));
    } catch {
      toast.error(t("errors.generic"));
    }
  }

  async function reportPost() {
    try {
      await api("/api/reports", {
        method: "POST",
        body: JSON.stringify({
          targetType: "post",
          targetId: post.id,
          reason: "Reported from feed",
        }),
      });
      toast.success(t("feed.reportSent"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  async function deletePost() {
    setDeleting(true);
    try {
      await api(`/api/posts/${post.id}`, { method: "DELETE" });
      toast.success(t("feed.deletePost"));
      window.dispatchEvent(new CustomEvent("ib:post-deleted", { detail: post.id }));
      router.refresh();
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setDeleting(false);
      setDeleteOpen(false);
    }
  }

  return (
    <article className="border-b border-line bg-surface sm:rounded-lg sm:border">
      <header className="flex items-center gap-3 px-3 py-2.5 sm:px-4">
        <Link href={profileHref} className="shrink-0">
          <UserAvatar
            name={post.name}
            image={post.image}
            size="sm"
            ring={Boolean(post.verified)}
          />
        </Link>
        <div className="min-w-0 flex-1 leading-tight">
          <Link href={profileHref} className="flex items-center gap-1">
            <span className="truncate text-[13px] font-semibold">{post.username ?? post.name}</span>
            {post.verified ? <VerifiedBadge size={12} /> : null}
          </Link>
          {post.location ? (
            <p className="truncate text-[11px] text-subtle">{post.location}</p>
          ) : (
            <p className="text-[11px] text-subtle">
              {post.category === "quran"
                ? t("feed.categoryQuran")
                : post.category === "nasheed"
                  ? t("feed.categoryNasheed")
                  : post.category === "education"
                    ? t("feed.categoryEducation")
                    : t("feed.categoryIslamic")}
            </p>
          )}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              aria-label={t("common.more")}
              className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
            >
              <MoreHorizontal className="size-5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            {isOwner ? (
              <>
                <DropdownMenuItem variant="destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 className="size-4" /> {t("feed.deletePost")}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
              </>
            ) : (
              <>
                <DropdownMenuItem onClick={reportPost}>
                  <Flag className="size-4" /> {t("common.report")}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
              </>
            )}
            <DropdownMenuItem onClick={copyLink}>
              <Link2 className="size-4" /> {t("common.copyLink")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      <div
        className="relative select-none bg-black"
        onDoubleClick={() => {
          if (!post.liked) toggleLike();
          setDoubleTapHeart(true);
          setTimeout(() => setDoubleTapHeart(false), 700);
        }}
        onClick={onMediaTap}
      >
        {post.media_id ? (
          post.kind === "video" ? (
            <video
              src={`/api/media/${post.media_id}`}
              className="max-h-[70dvh] w-full object-contain"
              controls
              playsInline
              preload="metadata"
            />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={`/api/media/${post.media_id}`}
              alt={post.caption || t("common.post")}
              className="max-h-[70dvh] w-full object-cover"
              loading="lazy"
            />
          )
        ) : (
          <div className="flex aspect-square items-center justify-center text-subtle">
            {t("common.noResults")}
          </div>
        )}
        {doubleTapHeart ? (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <Heart className="size-24 animate-heart fill-white text-white drop-shadow-lg" />
          </div>
        ) : null}
      </div>

      <div className="px-3 pb-3 pt-1.5 sm:px-4">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={toggleLike}
            aria-label={t("common.like")}
            aria-pressed={post.liked}
            className="grid size-10 place-items-center rounded-full transition-transform active:scale-90"
          >
            <Heart
              className={`size-[26px] ${post.liked ? "fill-[#ff3040] text-[#ff3040]" : "text-ink"}`}
              strokeWidth={1.8}
            />
          </button>
          <button
            type="button"
            onClick={() => setCommentsOpen(true)}
            aria-label={t("common.comment")}
            className="grid size-10 place-items-center rounded-full transition-transform active:scale-90"
          >
            <MessageCircle className="size-[25px]" strokeWidth={1.8} />
          </button>
          <button
            type="button"
            onClick={copyLink}
            aria-label={t("common.share")}
            className="grid size-10 place-items-center rounded-full transition-transform active:scale-90"
          >
            <Send className="size-[24px]" strokeWidth={1.8} />
          </button>
          <div className="flex-1" />
          <button
            type="button"
            onClick={toggleSave}
            aria-label={t("common.saved")}
            aria-pressed={post.saved}
            className="grid size-10 place-items-center rounded-full transition-transform active:scale-90"
          >
            <Bookmark
              className={`size-[25px] ${post.saved ? "fill-ink" : ""}`}
              strokeWidth={1.8}
            />
          </button>
        </div>

        {post.likes > 0 ? (
          <p className="px-1 text-[13px] font-semibold">
            {post.likes.toLocaleString(locale)} {t("feed.likes")}
          </p>
        ) : null}

        {post.caption ? (
          <p className="mt-1 whitespace-pre-wrap px-1 text-[13px] leading-relaxed">
            <Link href={profileHref} className="font-semibold">
              {post.username ?? post.name}
            </Link>{" "}
            {post.caption}
          </p>
        ) : null}

        {post.comments > 0 ? (
          <button
            type="button"
            onClick={() => setCommentsOpen(true)}
            className="mt-1 px-1 text-[13px] text-subtle hover:text-ink"
          >
            {t("common.seeAll")} {post.comments} {t("common.comment")}
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setCommentsOpen(true)}
            className="mt-1 px-1 text-[13px] text-subtle hover:text-ink"
          >
            {t("feed.noComments")}
          </button>
        )}

        <p className="mt-1 px-1 text-[11px] uppercase tracking-wide text-subtle">
          {formatRelativeTime(post.created_at, locale)}
        </p>
      </div>

      <CommentsDialog
        open={commentsOpen}
        onOpenChange={setCommentsOpen}
        post={post}
        onCommented={() => setPost((current) => ({ ...current, comments: current.comments + 1 }))}
      />

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("feed.deletePost")}</AlertDialogTitle>
            <AlertDialogDescription>{t("feed.deletePostConfirm")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={deletePost} disabled={deleting}>
              {deleting ? <Loader2 className="size-4 animate-spin" /> : t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </article>
  );
}

function CommentsDialog({
  open,
  onOpenChange,
  post,
  onCommented,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  post: FeedPost;
  onCommented: () => void;
}) {
  const { t, locale } = useI18n();
  const { viewer } = useApp();
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ comments: CommentRow[] }>(`/api/posts/${post.id}/comments`);
      setComments(data.comments);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [post.id, t]);

  useEffect(() => {
    if (open) load();
  }, [open, load]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!text.trim() || sending) return;
    setSending(true);
    try {
      const data = await api<{ comment: CommentRow }>(`/api/posts/${post.id}/comments`, {
        method: "POST",
        body: JSON.stringify({ body: text }),
      });
      setComments((current) => [...current, data.comment]);
      onCommented();
      setText("");
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setSending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[85dvh] flex-col gap-0 overflow-hidden border-line bg-surface p-0 sm:max-w-[520px]">
        <DialogHeader className="border-b border-line px-4 py-3 text-center">
          <DialogTitle className="text-[15px] font-semibold">{t("feed.comments")}</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-4 py-3">
          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, index) => (
                <div key={index} className="flex gap-2.5">
                  <div className="size-8 animate-pulse rounded-full bg-hover" />
                  <div className="flex-1 space-y-2">
                    <div className="h-2.5 w-1/3 animate-pulse rounded-full bg-hover" />
                    <div className="h-2.5 w-2/3 animate-pulse rounded-full bg-hover" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="flex flex-col items-center gap-3 py-10 text-center">
              <p className="text-[13px] text-subtle">{error}</p>
              <Button size="sm" variant="outline" onClick={load}>
                {t("common.retry")}
              </Button>
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-12 text-center">
              <MessageCircle className="size-9 text-subtle" strokeWidth={1.3} />
              <p className="text-[13px] text-subtle">{t("feed.noComments")}</p>
            </div>
          ) : (
            <ul className="space-y-4">
              {comments.map((comment) => (
                <li key={comment.id} className="flex gap-2.5">
                  <Link
                    href={comment.username ? `/u/${comment.username}` : "/explore"}
                    className="shrink-0"
                  >
                    <UserAvatar name={comment.name} image={comment.image} size="sm" />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] leading-relaxed">
                      <Link
                        href={comment.username ? `/u/${comment.username}` : "/explore"}
                        className="inline-flex items-center gap-1 font-semibold"
                      >
                        {comment.username ?? comment.name}
                        {comment.verified ? <VerifiedBadge size={11} /> : null}
                      </Link>{" "}
                      {comment.body}
                    </p>
                    <p className="mt-0.5 text-[11px] text-subtle">
                      {formatRelativeTime(comment.created_at, locale)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <form
          onSubmit={submit}
          className="flex items-center gap-2 border-t border-line px-3 py-2.5"
        >
          <UserAvatar name={viewer.name} image={viewer.image} size="sm" />
          <Input
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder={t("feed.addComment")}
            aria-label={t("feed.addComment")}
            maxLength={1000}
            className="h-10 flex-1 border-0 bg-transparent px-0 text-[13px] shadow-none focus-visible:ring-0"
          />
          <Button
            type="submit"
            size="sm"
            variant="ghost"
            disabled={!text.trim() || sending}
            className="h-9 px-2 text-[13px] font-semibold text-brand hover:bg-transparent disabled:opacity-40"
          >
            {sending ? <Loader2 className="size-4 animate-spin" /> : t("feed.postComment")}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
