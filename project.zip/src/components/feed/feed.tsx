"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, RefreshCw, ImagePlus } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import type { FeedPost } from "@/lib/queries";
import { PostCard } from "@/components/feed/post-card";
import { Button } from "@/components/ui/button";
import { useApp } from "@/components/app/app-context";
import { cn } from "@/lib/utils";

export function Feed({
  scope = "home",
  profileId,
  className,
  emptyIcon,
  emptyTitle,
  emptyBody,
  showCreate = true,
}: {
  scope?: "home" | "explore" | "reels" | "profile" | "saved";
  profileId?: string;
  className?: string;
  emptyIcon?: React.ReactNode;
  emptyTitle?: string;
  emptyBody?: string;
  showCreate?: boolean;
}) {
  const { t } = useI18n();
  const { openCompose } = useApp();
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const load = useCallback(
    async (reset = true) => {
      if (reset) {
        setLoading(true);
        setError(null);
      } else {
        setLoadingMore(true);
      }
      try {
        const params = new URLSearchParams({ scope });
        if (profileId) params.set("profileId", profileId);
        if (!reset) params.set("offset", String(offset));
        const data = await api<{ posts: FeedPost[] }>(`/api/feed?${params.toString()}`);
        if (reset) {
          setPosts(data.posts);
          setOffset(data.posts.length);
        } else {
          setPosts((current) => [...current, ...data.posts]);
          setOffset((current) => current + data.posts.length);
        }
        setHasMore(data.posts.length >= 24);
      } catch (err) {
        setError(errorMessage(err, t));
      } finally {
        setLoading(false);
        setRefreshing(false);
        setLoadingMore(false);
      }
    },
    [scope, profileId, offset, t],
  );

  useEffect(() => {
    setPosts([]);
    setOffset(0);
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope, profileId]);

  useEffect(() => {
    function onCreated(event: Event) {
      const post = (event as CustomEvent<FeedPost>).detail;
      if (!post) return;
      if (scope === "home" || scope === "explore") {
        setPosts((current) => [post, ...current]);
      }
    }
    function onDeleted(event: Event) {
      const id = (event as CustomEvent<string>).detail;
      setPosts((current) => current.filter((item) => item.id !== id));
    }
    window.addEventListener("ib:post-created", onCreated);
    window.addEventListener("ib:post-deleted", onDeleted);
    return () => {
      window.removeEventListener("ib:post-created", onCreated);
      window.removeEventListener("ib:post-deleted", onDeleted);
    };
  }, [scope]);

  if (loading) {
    return (
      <div className={cn("space-y-4", className)}>
        {Array.from({ length: 2 }).map((_, index) => (
          <div key={index} className="border-b border-line bg-surface sm:rounded-lg sm:border">
            <div className="flex items-center gap-3 p-3">
              <div className="size-8 animate-pulse rounded-full bg-hover" />
              <div className="space-y-2">
                <div className="h-2.5 w-24 animate-pulse rounded-full bg-hover" />
                <div className="h-2 w-16 animate-pulse rounded-full bg-hover" />
              </div>
            </div>
            <div className="aspect-square w-full animate-pulse bg-hover" />
            <div className="space-y-2 p-4">
              <div className="h-2.5 w-20 animate-pulse rounded-full bg-hover" />
              <div className="h-2.5 w-2/3 animate-pulse rounded-full bg-hover" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className={cn("flex flex-col items-center gap-3 px-6 py-16 text-center", className)}>
        <p className="text-[13px] text-subtle">{error}</p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setRefreshing(true);
            load(true);
          }}
        >
          {refreshing ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <RefreshCw className="size-4" />
          )}
          {t("common.retry")}
        </Button>
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div
        className={cn(
          "flex flex-col items-center gap-3 border-b border-line px-6 py-16 text-center sm:rounded-lg sm:border",
          className,
        )}
      >
        <div className="grid size-16 place-items-center rounded-full border border-line text-ink">
          {emptyIcon ?? <ImagePlus className="size-7" strokeWidth={1.3} />}
        </div>
        <p className="text-[15px] font-semibold">{emptyTitle ?? t("feed.noPostsTitle")}</p>
        <p className="max-w-[19rem] text-[13px] leading-relaxed text-subtle">
          {emptyBody ?? t("feed.noPostsBody")}
        </p>
        {showCreate ? (
          <Button
            onClick={openCompose}
            size="sm"
            className="mt-1 h-9 rounded-lg bg-brand text-[13px] font-semibold text-white hover:bg-brand-hover"
          >
            {t("feed.createFirstPost")}
          </Button>
        ) : null}
      </div>
    );
  }

  return (
    <div className={cn("space-y-0 sm:space-y-4", className)}>
      <div className="hidden items-center justify-end px-1 sm:flex">
        <button
          type="button"
          onClick={() => {
            setRefreshing(true);
            load(true);
          }}
          className="flex items-center gap-1.5 rounded-full px-2 py-1 text-[11px] text-subtle transition-colors hover:text-ink"
        >
          <RefreshCw className={cn("size-3.5", refreshing && "animate-spin")} />
          {t("common.refresh")}
        </button>
      </div>
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
      {hasMore ? (
        <div className="flex justify-center py-5">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => load(false)}
            disabled={loadingMore}
            className="text-[13px] text-brand"
          >
            {loadingMore ? <Loader2 className="size-4 animate-spin" /> : t("common.seeAll")}
          </Button>
        </div>
      ) : posts.length > 2 ? (
        <p className="py-6 text-center text-[12px] text-subtle">{t("feed.feedEnd")}</p>
      ) : null}
    </div>
  );
}
