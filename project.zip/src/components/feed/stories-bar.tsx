"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Loader2, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatRelativeTime } from "@/lib/i18n";
import type { StoryGroup } from "@/lib/queries";
import { UserAvatar } from "@/components/user/avatar";
import { useApp } from "@/components/app/app-context";
import { compressImage } from "@/components/app/create-post-dialog";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export function StoriesBar() {
  const { t, locale } = useI18n();
  const { viewer } = useApp();
  const [groups, setGroups] = useState<StoryGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeGroup, setActiveGroup] = useState<number | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [seen, setSeen] = useState<Set<string>>(new Set());

  const load = useCallback(async () => {
    try {
      const data = await api<{ groups: StoryGroup[] }>("/api/stories");
      setGroups(data.groups);
    } catch {
      setGroups([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    try {
      const stored = localStorage.getItem("ib-seen-stories");
      if (stored) setSeen(new Set(JSON.parse(stored) as string[]));
    } catch {
      /* ignore */
    }
    function onCreated() {
      load();
    }
    window.addEventListener("ib:story-created", onCreated);
    return () => window.removeEventListener("ib:story-created", onCreated);
  }, [load]);

  const ownGroupIndex = groups.findIndex((group) => group.user_id === viewer.id);
  const otherGroups = groups.filter((group) => group.user_id !== viewer.id);
  const ownGroup = ownGroupIndex >= 0 ? groups[ownGroupIndex] : null;

  function markSeen(ids: string[]) {
    setSeen((current) => {
      const next = new Set(current);
      ids.forEach((id) => next.add(id));
      try {
        localStorage.setItem("ib-seen-stories", JSON.stringify(Array.from(next).slice(-400)));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  const ordered = [...(ownGroup ? [ownGroup] : []), ...otherGroups];
  const active = activeGroup !== null ? ordered[activeGroup] : null;

  return (
    <div className="border-b border-line bg-surface py-3 sm:rounded-lg sm:border">
      <div className="flex gap-4 overflow-x-auto px-3 pb-1 no-scrollbar sm:px-0">
        <div className="flex w-[68px] shrink-0 flex-col items-center gap-1.5">
          <div className="relative">
            <button
              type="button"
              aria-label={t("feed.yourStory")}
              onClick={() => {
                if (ownGroup) {
                  const index = ordered.findIndex((group) => group.user_id === viewer.id);
                  markSeen(ownGroup.stories.map((story) => story.id));
                  setActiveGroup(index);
                } else {
                  setAddOpen(true);
                }
              }}
              className="story-ring rounded-full p-[2px]"
            >
              <div className="rounded-full border-2 border-surface">
                <UserAvatar name={viewer.name} image={viewer.image} size="lg" />
              </div>
            </button>
            <button
              type="button"
              aria-label={t("feed.addStory")}
              onClick={() => setAddOpen(true)}
              className="absolute -bottom-0.5 -end-0.5 grid size-5 place-items-center rounded-full border-2 border-surface bg-brand text-white"
            >
              <Plus className="size-3" strokeWidth={3} />
            </button>
          </div>
          <span className="max-w-full truncate text-[11px] text-ink">{t("feed.yourStory")}</span>
        </div>

        {loading ? (
          <>
            {Array.from({ length: 5 }).map((_, index) => (
              <div key={index} className="flex w-[68px] shrink-0 flex-col items-center gap-1.5">
                <div className="size-14 animate-pulse rounded-full bg-hover" />
                <div className="h-2 w-12 animate-pulse rounded-full bg-hover" />
              </div>
            ))}
          </>
        ) : (
          otherGroups.map((group) => {
            const index = ordered.findIndex((item) => item.user_id === group.user_id);
            const allSeen = group.stories.every((story) => seen.has(story.id));
            return (
              <button
                key={group.user_id}
                type="button"
                onClick={() => {
                  markSeen(group.stories.map((story) => story.id));
                  setActiveGroup(index);
                }}
                className="flex w-[68px] shrink-0 flex-col items-center gap-1.5"
              >
                <div
                  className={
                    allSeen
                      ? "rounded-full border border-line p-[2px]"
                      : "story-ring rounded-full p-[2px]"
                  }
                >
                  <div className="rounded-full border-2 border-surface">
                    <UserAvatar
                      name={group.name}
                      image={group.image}
                      size="lg"
                      className="size-[58px]"
                    />
                  </div>
                </div>
                <span className="max-w-full truncate text-[11px] text-ink">
                  {group.username ?? group.name}
                </span>
              </button>
            );
          })
        )}

        {!loading && otherGroups.length === 0 ? (
          <button
            type="button"
            onClick={() => setAddOpen(true)}
            className="flex w-[68px] shrink-0 flex-col items-center gap-1.5 opacity-70"
          >
            <div className="grid size-14 place-items-center rounded-full border border-dashed border-line">
              <Plus className="size-5 text-subtle" />
            </div>
            <span className="text-[11px] text-subtle">{t("feed.addStory")}</span>
          </button>
        ) : null}
      </div>

      {active ? (
        <StoryViewer
          group={active}
          onClose={() => setActiveGroup(null)}
          onSeen={markSeen}
          onNextGroup={() => {
            if (activeGroup !== null && activeGroup + 1 < ordered.length) {
              const nextGroup = ordered[activeGroup + 1];
              markSeen(nextGroup.stories.map((story) => story.id));
              setActiveGroup(activeGroup + 1);
            } else {
              setActiveGroup(null);
            }
          }}
          onPrevGroup={() => {
            if (activeGroup !== null && activeGroup > 0) {
              setActiveGroup(activeGroup - 1);
            }
          }}
          locale={locale}
        />
      ) : null}

      <AddStoryDialog open={addOpen} onOpenChange={setAddOpen} onCreated={load} />
    </div>
  );
}

function StoryViewer({
  group,
  onClose,
  onSeen,
  onNextGroup,
  onPrevGroup,
  locale,
}: {
  group: StoryGroup;
  onClose: () => void;
  onSeen: (ids: string[]) => void;
  onNextGroup: () => void;
  onPrevGroup: () => void;
  locale: import("@/lib/i18n").Locale;
}) {
  const { t } = useI18n();
  const [index, setIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const story = group.stories[index];

  useEffect(() => {
    if (!story) return;
    onSeen([story.id]);
    api(`/api/stories/${story.id}/view`, { method: "POST" }).catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [story?.id]);

  useEffect(() => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((current) => {
        if (current >= 100) return 100;
        return current + 2;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [index, story?.id]);

  useEffect(() => {
    if (progress < 100) return;
    if (index + 1 < group.stories.length) {
      setIndex((value) => value + 1);
    } else {
      onNextGroup();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progress]);

  function next() {
    if (index + 1 < group.stories.length) setIndex(index + 1);
    else onNextGroup();
  }

  function prev() {
    if (index > 0) setIndex(index - 1);
    else onPrevGroup();
  }

  if (!story) return null;

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        showCloseButton={false}
        className="h-dvh max-h-dvh w-full max-w-none gap-0 overflow-hidden rounded-none border-0 bg-black p-0 sm:max-w-[440px] sm:rounded-xl"
      >
        <DialogTitle className="sr-only">{t("feed.stories")}</DialogTitle>
        <div className="relative flex h-full w-full flex-col">
          <div className="absolute inset-x-2 top-2 z-20 flex gap-1">
            {group.stories.map((item, itemIndex) => (
              <div key={item.id} className="h-[2px] flex-1 overflow-hidden rounded-full bg-white/30">
                <div
                  className="h-full bg-white transition-[width] duration-100 ease-linear"
                  style={{
                    width:
                      itemIndex < index ? "100%" : itemIndex === index ? `${progress}%` : "0%",
                  }}
                />
              </div>
            ))}
          </div>

          <div className="absolute inset-x-3 top-6 z-20 flex items-center gap-2.5 pt-2">
            <UserAvatar name={group.name} image={group.image} size="sm" />
            <div className="leading-tight">
              <p className="text-[13px] font-semibold text-white">
                {group.username ?? group.name}
              </p>
              <p className="text-[10px] text-white/70">
                {formatRelativeTime(story.created_at, locale)}
              </p>
            </div>
            <div className="flex-1" />
            <button
              type="button"
              onClick={onClose}
              aria-label={t("common.close")}
              className="grid size-9 place-items-center rounded-full bg-black/30 text-white"
            >
              <X className="size-5" />
            </button>
          </div>

          <div className="flex flex-1 items-center justify-center bg-black">
            {story.media_id ? (
              story.mime?.startsWith("video/") ? (
                <video
                  ref={videoRef}
                  src={`/api/media/${story.media_id}`}
                  className="max-h-full w-full object-contain"
                  autoPlay
                  playsInline
                  onEnded={next}
                />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={`/api/media/${story.media_id}`}
                  alt={story.caption || t("feed.storyHint")}
                  className="max-h-full w-full object-contain"
                />
              )
            ) : (
              <div className="p-10 text-center text-white/70">{t("feed.storyHint")}</div>
            )}
          </div>

          {story.caption ? (
            <p className="absolute inset-x-0 bottom-6 z-20 px-5 text-center text-[13px] text-white drop-shadow">
              {story.caption}
            </p>
          ) : null}

          <button
            type="button"
            aria-label={t("common.back")}
            onClick={prev}
            className="absolute inset-y-16 start-0 z-10 flex w-1/4 items-center justify-start ps-1 text-white/0 hover:text-white/80"
          >
            <ChevronLeft className="size-7" />
          </button>
          <button
            type="button"
            aria-label={t("common.next")}
            onClick={next}
            className="absolute inset-y-16 end-0 z-10 flex w-1/4 items-center justify-end pe-1 text-white/0 hover:text-white/80"
          >
            <ChevronRight className="size-7" />
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AddStoryDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}) {
  const { t } = useI18n();
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function pick(nextFile: File | undefined) {
    if (!nextFile) return;
    if (nextFile.size > 25 * 1024 * 1024) {
      setError(t("errors.tooLarge"));
      return;
    }
    if (preview) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(URL.createObjectURL(nextFile));
    setError(null);
  }

  async function publish() {
    if (!file) {
      setError(t("feed.addMedia"));
      return;
    }
    setPending(true);
    setError(null);
    try {
      const uploadFile = await compressImage(file);
      const form = new FormData();
      form.append("file", uploadFile);
      form.append("purpose", "story");
      const uploaded = await api<{ id: string }>("/api/upload", {
        method: "POST",
        body: form,
      });
      await api("/api/stories", {
        method: "POST",
        body: JSON.stringify({ mediaId: uploaded.id, caption }),
      });
      toast.success(t("feed.storyPosted"));
      window.dispatchEvent(new CustomEvent("ib:story-created"));
      onCreated();
      if (preview) URL.revokeObjectURL(preview);
      setFile(null);
      setPreview(null);
      setCaption("");
      onOpenChange(false);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-line bg-surface p-0 sm:max-w-[480px]">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="text-[13px] text-ink"
          >
            {t("common.cancel")}
          </button>
          <p className="text-[15px] font-semibold">{t("feed.addStory")}</p>
          <Button
            size="sm"
            variant="ghost"
            onClick={publish}
            disabled={!file || pending}
            className="h-8 px-2 text-[13px] font-semibold text-brand"
          >
            {pending ? <Loader2 className="size-4 animate-spin" /> : t("common.share")}
          </Button>
        </div>
        <div className="p-4">
          {preview ? (
            <div className="relative overflow-hidden rounded-lg bg-black">
              {file?.type.startsWith("video/") ? (
                <video src={preview} className="max-h-[50dvh] w-full" controls playsInline />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={preview} alt="" className="max-h-[50dvh] w-full object-contain" />
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="grid min-h-[220px] w-full place-items-center rounded-lg border border-dashed border-line"
            >
              <div className="flex flex-col items-center gap-2 text-center">
                <Plus className="size-8 text-subtle" strokeWidth={1.3} />
                <span className="text-[13px] font-medium">{t("feed.addMedia")}</span>
                <span className="max-w-[15rem] text-[11px] text-subtle">
                  {t("feed.storyHint")}
                </span>
              </div>
            </button>
          )}
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/mp4,video/webm"
            className="sr-only"
            onChange={(event) => pick(event.target.files?.[0])}
          />
          <div className="mt-4 space-y-1.5">
            <Label htmlFor="story-caption" className="text-[11px] text-subtle">
              {t("feed.captionPlaceholder")}
            </Label>
            <input
              id="story-caption"
              value={caption}
              onChange={(event) => setCaption(event.target.value)}
              maxLength={300}
              placeholder={t("feed.captionPlaceholder")}
              className="h-11 w-full rounded-md border border-line bg-app px-3 text-[14px] outline-none focus:ring-1 focus:ring-line"
            />
          </div>
          {error ? (
            <p className="mt-2 text-[12px] text-destructive">{error}</p>
          ) : (
            <p className="mt-2 text-[11px] text-subtle">{t("feed.mediaFilterNotice")}</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
