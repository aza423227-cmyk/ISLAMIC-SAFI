import { cn } from "@/lib/utils";
import { BadgeCheck } from "lucide-react";

const sizes = {
  xs: "size-6 text-[10px]",
  sm: "size-8 text-[11px]",
  md: "size-10 text-[13px]",
  lg: "size-14 text-[18px]",
  xl: "size-20 text-[26px] sm:size-24 sm:text-[30px]",
};

export function UserAvatar({
  name,
  image,
  size = "md",
  className,
  ring = false,
}: {
  name: string;
  image?: string | null;
  size?: keyof typeof sizes;
  className?: string;
  ring?: boolean;
}) {
  const initial = (name || "?").trim().charAt(0).toUpperCase();
  return (
    <div
      className={cn(
        "relative shrink-0 overflow-hidden rounded-full bg-hover",
        ring && "story-ring p-[2px]",
        sizes[size],
        className,
      )}
    >
      <div className={cn("size-full overflow-hidden rounded-full", ring && "border-2 border-app")}>
        {image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={image}
            alt={name}
            className="size-full object-cover"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex size-full items-center justify-center bg-gradient-to-br from-[#2b4b40] via-[#1d352d] to-[#0e1b17] font-wordmark font-semibold text-[#e7d9b4]">
            {initial}
          </div>
        )}
      </div>
    </div>
  );
}

export function VerifiedBadge({
  className,
  size = 14,
}: {
  className?: string;
  size?: number;
}) {
  return (
    <span
      className={cn("inline-flex shrink-0 items-center justify-center", className)}
      title="Verified"
      aria-label="Verified"
    >
      <BadgeCheck
        style={{ width: size, height: size, fill: "#0095f6", color: "#ffffff" }}
        strokeWidth={2.2}
      />
    </span>
  );
}
