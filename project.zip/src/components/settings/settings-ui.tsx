"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { cn } from "@/lib/utils";

export function SettingsShell({
  title,
  children,
  backHref = "/settings",
}: {
  title: string;
  children: React.ReactNode;
  backHref?: string;
}) {
  const { t } = useI18n();
  const router = useRouter();
  return (
    <div className="mx-auto w-full max-w-[640px] px-4 pb-12 pt-3 md:pt-6">
      <div className="mb-5 flex items-center gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label={t("common.back")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
        >
          <ArrowLeft className="size-5 rtl:rotate-180" />
        </button>
        <h1 className="text-[17px] font-semibold">{title}</h1>
        <Link href={backHref} className="ms-auto text-[12px] font-semibold text-brand">
          {t("settings.title")}
        </Link>
      </div>
      {children}
    </div>
  );
}

export function SettingsGroup({
  title,
  children,
  className,
}: {
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("mb-6", className)}>
      {title ? (
        <h2 className="mb-2 px-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-subtle">
          {title}
        </h2>
      ) : null}
      <div className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
        {children}
      </div>
    </section>
  );
}

export function SettingsRow({
  icon,
  label,
  description,
  href,
  onClick,
  trailing,
  destructive = false,
}: {
  icon?: React.ReactNode;
  label: string;
  description?: string;
  href?: string;
  onClick?: () => void;
  trailing?: React.ReactNode;
  destructive?: boolean;
}) {
  const content = (
    <>
      {icon ? <span className="shrink-0 text-ink">{icon}</span> : null}
      <span className="min-w-0 flex-1">
        <span
          className={cn(
            "block text-[14px] leading-snug",
            destructive ? "text-destructive" : "text-ink",
          )}
        >
          {label}
        </span>
        {description ? (
          <span className="mt-0.5 block text-[11px] leading-relaxed text-subtle">
            {description}
          </span>
        ) : null}
      </span>
      {trailing ?? (href ? <ChevronRight className="size-4 shrink-0 text-subtle rtl:rotate-180" /> : null)}
    </>
  );

  if (href) {
    return (
      <Link href={href} className="flex items-center gap-3 px-4 py-3.5 transition-colors hover:bg-hover/50">
        {content}
      </Link>
    );
  }
  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        className="flex w-full items-center gap-3 px-4 py-3.5 text-start transition-colors hover:bg-hover/50"
      >
        {content}
      </button>
    );
  }
  return <div className="flex items-center gap-3 px-4 py-3.5">{content}</div>;
}
