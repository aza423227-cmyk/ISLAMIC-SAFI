"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Heart, Loader2, MessageCircle, UserPlus, ImageIcon } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatRelativeTime } from "@/lib/i18n";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { Button } from "@/components/ui/button";
import { useApp } from "@/components/app/app-context";

type NotificationItem = {
  id: string;
  type: string;
  read: boolean;
  created_at: string;
  post_id: string | null;
  conversation_id: string | null;
  actor_name: string | null;
  actor_username: string | null;
  actor_image: string | null;
  actor_verified: boolean | null;
  media_id: string | null;
};

const icons = {
  like: Heart,
  comment: MessageCircle,
  follow: UserPlus,
  message: MessageCircle,
  post: ImageIcon,
} as const;

export function NotificationSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, locale } = useI18n();
  const router = useRouter();
  const { refreshUnread } = useApp();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ notifications: NotificationItem[] }>("/api/notifications");
      setItems(data.notifications);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    if (open) load();
  }, [open, load]);

  async function markAll() {
    setItems((current) => current.map((item) => ({ ...item, read: true })));
    await api("/api/notifications", { method: "PATCH", body: JSON.stringify({}) }).catch(
      () => undefined,
    );
    refreshUnread();
    router.refresh();
  }

  function hrefFor(item: NotificationItem) {
    if (item.type === "follow" && item.actor_username) return `/u/${item.actor_username}`;
    if (item.type === "message" && item.conversation_id)
      return `/messages/${item.conversation_id}`;
    if (item.post_id) return `/p/${item.post_id}`;
    if (item.actor_username) return `/u/${item.actor_username}`;
    return "/";
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full border-line bg-surface p-0 sm:max-w-[400px]">
        <SheetHeader className="flex flex-row items-center justify-between border-b border-line px-4 py-4 text-start">
          <SheetTitle className="text-[16px] font-semibold">{t("notif.title")}</SheetTitle>
          {items.some((item) => !item.read) ? (
            <button
              onClick={markAll}
              className="text-[12px] font-semibold text-brand hover:opacity-80"
            >
              {t("notif.markAll")}
            </button>
          ) : null}
        </SheetHeader>

        <div className="h-[calc(100dvh-64px)] overflow-y-auto overscroll-contain">
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 5 }).map((_, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="size-11 animate-pulse rounded-full bg-hover" />
                  <div className="flex-1 space-y-2">
                    <div className="h-2.5 w-2/3 animate-pulse rounded-full bg-hover" />
                    <div className="h-2 w-1/3 animate-pulse rounded-full bg-hover" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
              <p className="text-[13px] text-subtle">{error}</p>
              <Button variant="outline" size="sm" onClick={load}>
                {t("common.retry")}
              </Button>
            </div>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center gap-2 px-6 py-20 text-center">
              <div className="grid size-14 place-items-center rounded-full border border-line">
                <Heart className="size-6" strokeWidth={1.5} />
              </div>
              <p className="text-[14px] font-medium">{t("notif.empty")}</p>
            </div>
          ) : (
            <ul>
              {items.map((item) => {
                const Icon = icons[item.type as keyof typeof icons] ?? Heart;
                const label =
                  item.type === "like"
                    ? t("notif.liked")
                    : item.type === "comment"
                      ? t("notif.commented")
                      : item.type === "follow"
                        ? t("notif.followed")
                        : item.type === "message"
                          ? t("notif.messaged")
                          : t("notif.posted");
                return (
                  <li key={item.id}>
                    <Link
                      href={hrefFor(item)}
                      onClick={() => {
                        if (!item.read) {
                          api("/api/notifications", {
                            method: "PATCH",
                            body: JSON.stringify({ id: item.id }),
                          }).catch(() => undefined);
                          refreshUnread();
                        }
                        onOpenChange(false);
                      }}
                      className={`flex items-center gap-3 px-4 py-3 transition-colors hover:bg-hover/60 ${
                        item.read ? "" : "bg-brand/[0.04]"
                      }`}
                    >
                      <div className="relative">
                        <UserAvatar
                          name={item.actor_name ?? "?"}
                          image={item.actor_image}
                          size="md"
                        />
                        <span className="absolute -bottom-0.5 -end-0.5 grid size-4 place-items-center rounded-full bg-brand text-white ring-2 ring-surface">
                          <Icon className="size-2.5" fill="currentColor" />
                        </span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-[13px] leading-snug text-ink">
                          <span className="inline-flex items-center gap-1 font-semibold">
                            {item.actor_username ? `@${item.actor_username}` : item.actor_name}
                            {item.actor_verified ? <VerifiedBadge size={12} /> : null}
                          </span>{" "}
                          <span className="text-subtle">{label}</span>
                        </p>
                        <p className="mt-0.5 text-[11px] text-subtle">
                          {formatRelativeTime(item.created_at, locale)}
                        </p>
                      </div>
                      {item.media_id ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={`/api/media/${item.media_id}`}
                          alt=""
                          className="size-11 shrink-0 rounded-md object-cover"
                        />
                      ) : null}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function NotificationLoading() {
  return <Loader2 className="size-4 animate-spin" />;
}
