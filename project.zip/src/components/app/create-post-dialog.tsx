"use client";

import { useCallback, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const CATEGORIES = ["islamic", "quran", "nasheed", "education"] as const;

export async function compressImage(file: File) {
  if (!file.type.startsWith("image/")) return file;
  if (file.size < 350 * 1024) return file;
  const bitmap = await createImageBitmap(file).catch(() => null);
  if (!bitmap) return file;
  const max = 1440;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return file;
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", 0.88),
  );
  if (!blob) return file;
  return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", {
    type: "image/jpeg",
  });
}

export function CreatePostDialog({
  open,
  onOpenChange,
  defaultReel = false,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultReel?: boolean;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("islamic");
  const [isReel, setIsReel] = useState(defaultReel);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reset = useCallback(() => {
    setFile(null);
    setPreview(null);
    setCaption("");
    setCategory("islamic");
    setIsReel(false);
    setError(null);
    setPending(false);
    if (preview) URL.revokeObjectURL(preview);
  }, [preview]);

  function handleFile(nextFile: File | undefined) {
    if (!nextFile) return;
    if (nextFile.size > 25 * 1024 * 1024) {
      setError(t("errors.tooLarge"));
      return;
    }
    const allowed = nextFile.type.startsWith("image/") || nextFile.type.startsWith("video/");
    if (!allowed) {
      setError(t("errors.moderation"));
      return;
    }
    if (preview) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(URL.createObjectURL(nextFile));
    setError(null);
    setIsReel(nextFile.type.startsWith("video/") ? isReel : false);
  }

  async function publish() {
    if (!file) {
      setError(t("feed.addMedia"));
      return;
    }
    setPending(true);
    setError(null);
    try {
      const uploadFile = await compressImage(file);
      const form = new FormData();
      form.append("file", uploadFile);
      form.append("purpose", "post");
      const uploaded = await api<{ id: string; kind: string }>("/api/upload", {
        method: "POST",
        body: form,
      });
      const result = await api<{ post: unknown }>("/api/posts", {
        method: "POST",
        body: JSON.stringify({
          mediaId: uploaded.id,
          caption,
          category,
          isReel: isReel && uploaded.kind === "video",
        }),
      });
      toast.success(t("feed.published"));
      window.dispatchEvent(new CustomEvent("ib:post-created", { detail: result.post }));
      onOpenChange(false);
      reset();
      router.refresh();
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) reset();
        onOpenChange(next);
      }}
    >
      <DialogContent className="max-h-[92dvh] gap-0 overflow-hidden border-line bg-surface p-0 sm:max-w-[560px]">
        <DialogHeader className="flex flex-row items-center justify-between border-b border-line px-4 py-3">
          <span className="w-10" />
          <DialogTitle className="text-[15px] font-semibold">{t("feed.newPost")}</DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-10 text-[13px] font-semibold text-brand hover:bg-transparent hover:text-brand/80"
            onClick={publish}
            disabled={pending || !file}
          >
            {pending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              t("feed.publish")
            )}
          </Button>
        </DialogHeader>

        <div className="max-h-[76dvh] overflow-y-auto">
          {preview ? (
            <div className="relative bg-black">
              {file?.type.startsWith("video/") ? (
                <video
                  src={preview}
                  className="max-h-[46dvh] w-full object-contain"
                  controls
                  playsInline
                  muted
                />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={preview}
                  alt={t("feed.addMedia")}
                  className="max-h-[46dvh] w-full object-contain"
                />
              )}
              <button
                type="button"
                aria-label={t("common.remove")}
                onClick={() => {
                  if (preview) URL.revokeObjectURL(preview);
                  setPreview(null);
                  setFile(null);
                }}
                className="absolute end-2 top-2 grid size-8 place-items-center rounded-full bg-black/60 text-white"
              >
                <X className="size-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="flex min-h-[240px] w-full flex-col items-center justify-center gap-3 px-6 py-12 text-center transition-colors hover:bg-hover/60"
            >
              <span className="grid size-16 place-items-center rounded-full border border-line">
                <ImagePlus className="size-7 text-ink" strokeWidth={1.4} />
              </span>
              <span className="text-[15px] font-medium">{t("feed.addMedia")}</span>
              <span className="max-w-[16rem] text-[12px] leading-relaxed text-subtle">
                {t("feed.mediaFilterNotice")}
              </span>
            </button>
          )}
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/mp4,video/webm,video/quicktime"
            className="sr-only"
            onChange={(event) => handleFile(event.target.files?.[0])}
          />

          <div className="space-y-4 border-t border-line px-4 py-3">
            <Textarea
              value={caption}
              onChange={(event) => setCaption(event.target.value)}
              placeholder={t("feed.captionPlaceholder")}
              maxLength={2200}
              rows={3}
              className="resize-none border-0 bg-transparent p-0 text-[14px] shadow-none focus-visible:ring-0"
            />
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1.5">
                <Label className="text-[11px] text-subtle">{t("feed.selectCategory")}</Label>
                <Select
                  value={category}
                  onValueChange={(value) => setCategory(value as typeof category)}
                >
                  <SelectTrigger className="h-9 w-[180px] border-line bg-app text-[13px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="islamic">{t("feed.categoryIslamic")}</SelectItem>
                    <SelectItem value="quran">{t("feed.categoryQuran")}</SelectItem>
                    <SelectItem value="nasheed">{t("feed.categoryNasheed")}</SelectItem>
                    <SelectItem value="education">{t("feed.categoryEducation")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {file?.type.startsWith("video/") ? (
                <div className="flex items-center gap-2 pt-4">
                  <Switch id="reel-switch" checked={isReel} onCheckedChange={setIsReel} />
                  <Label htmlFor="reel-switch" className="text-[13px]">
                    {t("nav.reels")}
                  </Label>
                </div>
              ) : null}
            </div>
            {error ? (
              <p role="alert" className="text-[12px] leading-relaxed text-destructive">
                {error}
              </p>
            ) : (
              <p className="text-[11px] leading-relaxed text-subtle">
                {t("feed.mediaFilterNotice")}
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
