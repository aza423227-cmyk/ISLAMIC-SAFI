"use client";

import { useEffect } from "react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api } from "@/lib/api";

type PrayerData = { timings: Record<string, string>; date: string };
type Settings = {
  remindersEnabled: boolean;
  reminderMinutes: number;
  prayerMethod: string;
  latitude: string | null;
  longitude: string | null;
};

const ORDER = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;
const LABELS: Record<string, string> = {
  Fajr: "prayer.fajr",
  Dhuhr: "prayer.dhuhr",
  Asr: "prayer.asr",
  Maghrib: "prayer.maghrib",
  Isha: "prayer.isha",
};

function toDate(value: string) {
  const [hour, minute] = value.split(":").map(Number);
  const date = new Date();
  date.setHours(hour || 0, minute || 0, 0, 0);
  return date;
}

export function PrayerReminderWatcher() {
  const { t } = useI18n();

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;
    const notified = new Set<string>();

    async function init() {
      if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
      let settings: Settings | null = null;
      try {
        const data = await api<{ settings: Settings | null }>("/api/settings");
        settings = data.settings;
      } catch {
        return;
      }
      if (!settings?.remindersEnabled || cancelled) return;

      let coords: { lat: number; lng: number } | null = null;
      if (settings.latitude && settings.longitude) {
        coords = { lat: Number(settings.latitude), lng: Number(settings.longitude) };
      } else {
        try {
          const stored = localStorage.getItem("ib-coords");
          if (stored) coords = JSON.parse(stored) as { lat: number; lng: number };
        } catch {
          /* ignore */
        }
      }
      if (!coords) return;

      try {
        const data = await api<PrayerData>(
          `/api/prayer?lat=${coords.lat}&lng=${coords.lng}&method=${settings.prayerMethod}`,
        );
        if (cancelled) return;
        const check = () => {
          const now = Date.now();
          for (const prayer of ORDER) {
            const time = toDate(data.timings[prayer] ?? "00:00");
            const reminder = time.getTime() - settings!.reminderMinutes * 60000;
            const key = `${data.date}-${prayer}-${settings!.reminderMinutes}`;
            const diff = now - reminder;
            if (diff >= 0 && diff < 30000 && !notified.has(key)) {
              notified.add(key);
              const label = t(LABELS[prayer]);
              try {
                new Notification(t("prayer.adhanTitle"), {
                  body: t("prayer.adhanBody", { prayer: label }),
                  icon: "/favicon.ico",
                  tag: key,
                });
              } catch {
                /* ignore */
              }
              toast.message(t("prayer.adhanTitle"), {
                description: t("prayer.adhanBody", { prayer: label }),
              });
            }
          }
        };
        check();
        timer = setInterval(check, 30000);
      } catch {
        /* ignore */
      }
    }

    init();
    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
}
