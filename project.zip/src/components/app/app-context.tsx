"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type Viewer = {
  id: string;
  name: string;
  email: string;
  image: string | null;
  username: string | null;
  displayUsername: string | null;
  bio: string | null;
  website: string | null;
  isPrivate: boolean;
  verified: boolean;
  verifiedUntil: string | null;
  language: string | null;
};

type AppContextValue = {
  viewer: Viewer;
  setViewer: (viewer: Viewer) => void;
  unread: number;
  refreshUnread: () => Promise<void>;
  composeOpen: boolean;
  openCompose: () => void;
  setComposeOpen: (open: boolean) => void;
  notificationsOpen: boolean;
  setNotificationsOpen: (open: boolean) => void;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({
  viewer: initialViewer,
  children,
}: {
  viewer: Viewer;
  children: React.ReactNode;
}) {
  const [viewer, setViewer] = useState(initialViewer);
  const [unread, setUnread] = useState(0);
  const [composeOpen, setComposeOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const refreshUnread = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications", { cache: "no-store" });
      if (!response.ok) return;
      const data = (await response.json()) as { unread?: number };
      setUnread(data.unread ?? 0);
    } catch {
      /* offline */
    }
  }, []);

  useEffect(() => {
    setViewer(initialViewer);
  }, [initialViewer]);

  useEffect(() => {
    refreshUnread();
    const interval = setInterval(refreshUnread, 30000);
    return () => clearInterval(interval);
  }, [refreshUnread]);

  const openCompose = useCallback(() => setComposeOpen(true), []);

  const value = useMemo(
    () => ({
      viewer,
      setViewer,
      unread,
      refreshUnread,
      composeOpen,
      openCompose,
      setComposeOpen,
      notificationsOpen,
      setNotificationsOpen,
    }),
    [viewer, unread, refreshUnread, composeOpen, openCompose, notificationsOpen],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
