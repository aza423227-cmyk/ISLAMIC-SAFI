"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import {
  BadgeCheck,
  BookOpen,
  CircleDot,
  Film,
  Heart,
  Home,
  Languages,
  LogOut,
  Menu,
  MessageCircle,
  Moon,
  PlusSquare,
  Search,
  Settings,
  MoonStar,
  Sun,
  Sunset,
  Monitor,
} from "lucide-react";
import { authClient } from "@/lib/auth-client";
import { useI18n } from "@/lib/i18n/provider";
import { localeList, type Locale } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { useApp } from "@/components/app/app-context";
import { CreatePostDialog } from "@/components/app/create-post-dialog";
import { NotificationSheet } from "@/components/app/notification-sheet";
import { PrayerReminderWatcher } from "@/components/app/prayer-reminder-watcher";
import { UserAvatar } from "@/components/user/avatar";
import { Wordmark } from "@/components/brand/wordmark";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

function NavIcon({
  active,
  children,
}: {
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "grid place-items-center transition-transform duration-150",
        active && "scale-[1.04]",
      )}
    >
      {children}
    </span>
  );
}

export function AppShell({
  children,
  initialTheme,
  initialLanguage,
}: {
  children: React.ReactNode;
  initialTheme?: string | null;
  initialLanguage?: string | null;
}) {
  const { viewer, unread, composeOpen, setComposeOpen, notificationsOpen, setNotificationsOpen } =
    useApp();
  const { t, locale, setLocale } = useI18n();
  const { theme, setTheme } = useTheme();
  const pathname = usePathname();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (initialTheme && (initialTheme === "light" || initialTheme === "dark" || initialTheme === "system")) {
      setTheme(initialTheme);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (initialLanguage && initialLanguage !== locale) {
      setLocale(initialLanguage as Locale);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const profileHref = viewer.username ? `/u/${viewer.username}` : "/settings/account";

  const main = [
    { href: "/", label: t("nav.home"), icon: Home, exact: true },
    { href: "/explore", label: t("nav.search"), icon: Search },
    { href: "/reels", label: t("nav.reels"), icon: Film },
    { href: "/messages", label: t("nav.messages"), icon: MessageCircle },
  ];

  const tools = [
    { href: "/prayer", label: t("nav.prayer"), icon: Sunset },
    { href: "/quran", label: t("nav.quran"), icon: BookOpen },
    { href: "/tasbih", label: t("nav.tasbih"), icon: CircleDot },
    { href: "/get-verified", label: t("settings.verification"), icon: BadgeCheck },
  ];

  const isActive = (href: string, exact = false) =>
    exact ? pathname === href : pathname === href || pathname.startsWith(`${href}/`);

  async function signOutNow() {
    await authClient.signOut();
    toast.success(t("common.logOut"));
    router.replace("/auth/sign-in");
    router.refresh();
  }

  function cycleTheme() {
    setTheme(theme === "dark" ? "light" : theme === "light" ? "system" : "dark");
  }

  return (
    <div className="min-h-dvh bg-app">
      <aside className="fixed inset-y-0 start-0 z-40 hidden w-[72px] flex-col border-e border-line bg-app md:flex xl:w-[244px]">
        <div className="flex h-[92px] items-center justify-center px-3 xl:justify-start xl:px-6">
          <Link href="/" aria-label="ISLAMIC BESSAFI" className="hidden xl:block">
            <Wordmark className="text-[20px]" />
          </Link>
          <Link href="/" aria-label="ISLAMIC BESSAFI" className="xl:hidden">
            <span className="font-wordmark text-[22px] font-semibold tracking-[0.08em]">IB</span>
          </Link>
        </div>

        <nav className="flex flex-1 flex-col gap-1 px-3 xl:px-4">
          {main.map((item) => {
            const active = isActive(item.href, item.exact);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group flex h-12 items-center gap-4 rounded-lg px-3 transition-colors hover:bg-hover",
                  active ? "font-semibold" : "font-normal",
                )}
              >
                <NavIcon active={active}>
                  <Icon
                    className="size-[25px]"
                    strokeWidth={active ? 2.4 : 1.8}
                    fill={active && item.href === "/" ? "currentColor" : "none"}
                  />
                </NavIcon>
                <span className="hidden text-[15px] xl:inline">{item.label}</span>
              </Link>
            );
          })}

          <button
            type="button"
            onClick={() => setNotificationsOpen(true)}
            className="group flex h-12 items-center gap-4 rounded-lg px-3 text-start transition-colors hover:bg-hover"
          >
            <span className="relative">
              <Heart className="size-[25px]" strokeWidth={1.8} />
              {unread > 0 ? (
                <span className="absolute -end-1 -top-1 grid min-w-[16px] place-items-center rounded-full bg-[#ff3040] px-1 text-[9px] font-semibold leading-4 text-white">
                  {unread > 9 ? "9+" : unread}
                </span>
              ) : null}
            </span>
            <span className="hidden text-[15px] xl:inline">{t("notif.title")}</span>
          </button>

          <button
            type="button"
            onClick={() => setComposeOpen(true)}
            className="group flex h-12 items-center gap-4 rounded-lg px-3 text-start transition-colors hover:bg-hover"
          >
            <PlusSquare className="size-[25px]" strokeWidth={1.8} />
            <span className="hidden text-[15px] xl:inline">{t("nav.create")}</span>
          </button>

          <Link
            href={profileHref}
            className={cn(
              "group flex h-12 items-center gap-4 rounded-lg px-3 transition-colors hover:bg-hover",
              isActive("/u") && "font-semibold",
            )}
          >
            <UserAvatar
              name={viewer.name}
              image={viewer.image}
              size="xs"
              className={cn(
                "size-[26px]",
                isActive("/u") && "ring-2 ring-ink ring-offset-2 ring-offset-app",
              )}
            />
            <span className="hidden text-[15px] xl:inline">{t("nav.profile")}</span>
          </Link>

          <div className="my-2 hidden h-px bg-line xl:block" />

          <div className="hidden xl:block">
            <p className="px-3 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-subtle">
              {t("explore.tools")}
            </p>
          </div>
          {tools.map((item) => {
            const active = isActive(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex h-11 items-center gap-4 rounded-lg px-3 text-[14px] transition-colors hover:bg-hover",
                  active ? "font-semibold" : "text-ink",
                )}
              >
                <Icon className="size-[22px]" strokeWidth={active ? 2.3 : 1.7} />
                <span className="hidden xl:inline">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="px-3 pb-4 xl:px-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="flex h-12 w-full items-center gap-4 rounded-lg px-3 text-start transition-colors hover:bg-hover"
                aria-label={t("nav.more")}
              >
                <Menu className="size-[25px]" strokeWidth={1.8} />
                <span className="hidden text-[15px] xl:inline">{t("nav.more")}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" side="top" className="w-60">
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <Settings className="size-4" /> {t("common.settings")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings/saved">
                  <BookOpen className="size-4" /> {t("profile.saved")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={cycleTheme}>
                {mounted && theme === "dark" ? (
                  <Moon className="size-4" />
                ) : mounted && theme === "light" ? (
                  <Sun className="size-4" />
                ) : (
                  <Monitor className="size-4" />
                )}
                {t("common.theme")}:{" "}
                {mounted
                  ? theme === "dark"
                    ? t("common.dark")
                    : theme === "light"
                      ? t("common.light")
                      : t("common.system")
                  : t("common.system")}
              </DropdownMenuItem>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                  <Languages className="size-4" /> {t("common.language")}
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  {localeList.map((item) => (
                    <DropdownMenuItem
                      key={item.code}
                      onClick={() => setLocale(item.code as Locale)}
                      className={cn(locale === item.code && "font-semibold")}
                    >
                      {item.native}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={signOutNow} variant="destructive">
                <LogOut className="size-4" /> {t("common.logOut")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      <header className="fixed inset-x-0 top-0 z-30 flex h-12 items-center justify-between border-b border-line bg-app/95 px-4 backdrop-blur md:hidden">
        <Link href="/" aria-label="ISLAMIC BESSAFI">
          <Wordmark compact className="text-[17px]" />
        </Link>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setNotificationsOpen(true)}
            className="relative grid size-10 place-items-center rounded-full transition-colors active:bg-hover"
            aria-label={t("notif.title")}
          >
            <Heart className="size-[23px]" strokeWidth={1.8} />
            {unread > 0 ? (
              <span className="absolute end-1.5 top-1.5 size-2 rounded-full bg-[#ff3040]" />
            ) : null}
          </button>
          <button
            type="button"
            onClick={() => setComposeOpen(true)}
            className="grid size-10 place-items-center rounded-full transition-colors active:bg-hover"
            aria-label={t("nav.create")}
          >
            <PlusSquare className="size-[23px]" strokeWidth={1.8} />
          </button>
        </div>
      </header>

      <main className="min-h-dvh pb-[calc(56px+env(safe-area-inset-bottom))] pt-12 md:ms-[72px] md:pb-0 md:pt-0 xl:ms-[244px]">
        {children}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex h-[calc(56px+env(safe-area-inset-bottom))] items-start border-t border-line bg-app/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
        {main.map((item) => {
          const active = isActive(item.href, item.exact);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-label={item.label}
              className="flex h-14 flex-1 items-center justify-center transition-transform active:scale-95"
            >
              <Icon
                className={cn("size-[25px]", active ? "text-ink" : "text-ink/85")}
                strokeWidth={active ? 2.4 : 1.9}
                fill={active && item.href === "/" ? "currentColor" : "none"}
              />
            </Link>
          );
        })}
        <Link
          href={profileHref}
          aria-label={t("nav.profile")}
          className="flex h-14 flex-1 items-center justify-center transition-transform active:scale-95"
        >
          <UserAvatar
            name={viewer.name}
            image={viewer.image}
            size="sm"
            className={cn(
              "size-[26px]",
              isActive("/u") && "ring-2 ring-ink ring-offset-2 ring-offset-app",
            )}
          />
        </Link>
      </nav>

      <CreatePostDialog open={composeOpen} onOpenChange={setComposeOpen} />
      <NotificationSheet open={notificationsOpen} onOpenChange={setNotificationsOpen} />
      <PrayerReminderWatcher />
    </div>
  );
}
