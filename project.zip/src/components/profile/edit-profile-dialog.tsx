"use client";

import { useEffect, useRef, useState } from "react";
import { Camera, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { useApp, type Viewer } from "@/components/app/app-context";
import { UserAvatar } from "@/components/user/avatar";
import { compressImage } from "@/components/app/create-post-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

export function EditProfileDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useI18n();
  const { viewer, setViewer } = useApp();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [name, setName] = useState(viewer.name);
  const [bio, setBio] = useState(viewer.bio ?? "");
  const [website, setWebsite] = useState(viewer.website ?? "");
  const [isPrivate, setIsPrivate] = useState(viewer.isPrivate);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(viewer.name);
      setBio(viewer.bio ?? "");
      setWebsite(viewer.website ?? "");
      setIsPrivate(viewer.isPrivate);
      setAvatarFile(null);
      setAvatarPreview(null);
      setError(null);
    }
  }, [open, viewer]);

  async function save() {
    if (!name.trim()) {
      setError(t("profile.nameEmpty"));
      return;
    }
    setSaving(true);
    setError(null);
    try {
      let imageId: string | undefined;
      if (avatarFile) {
        const compressed = await compressImage(avatarFile);
        const form = new FormData();
        form.append("file", compressed);
        form.append("purpose", "avatar");
        const uploaded = await api<{ id: string }>("/api/upload", {
          method: "POST",
          body: form,
        });
        imageId = uploaded.id;
      }
      const data = await api<{ user: Viewer }>("/api/profile", {
        method: "PATCH",
        body: JSON.stringify({
          name,
          bio,
          website,
          isPrivate,
          ...(imageId ? { imageId } : {}),
        }),
      });
      setViewer({
        ...viewer,
        ...data.user,
        verified: Boolean(data.user.verified),
        verifiedUntil: data.user.verifiedUntil ?? viewer.verifiedUntil,
      });
      toast.success(t("profile.updated"));
      onOpenChange(false);
      router.refresh();
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-line bg-surface p-0 sm:max-w-[500px]">
        <DialogHeader className="border-b border-line px-4 py-3">
          <DialogTitle className="text-center text-[15px] font-semibold">
            {t("profile.editProfile")}
          </DialogTitle>
        </DialogHeader>
        <div className="max-h-[70dvh] space-y-4 overflow-y-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="relative"
              aria-label={t("profile.changePhoto")}
            >
              <UserAvatar
                name={name || viewer.name}
                image={avatarPreview ?? viewer.image}
                size="xl"
                className="size-16 sm:size-20"
              />
              <span className="absolute inset-0 grid place-items-center rounded-full bg-black/40 text-white">
                <Camera className="size-5" />
              </span>
            </button>
            <div>
              <p className="text-[14px] font-semibold">{viewer.username ?? viewer.name}</p>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="text-[12px] font-semibold text-brand"
              >
                {t("profile.changePhoto")}
              </button>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                const next = event.target.files?.[0];
                if (!next) return;
                if (avatarPreview) URL.revokeObjectURL(avatarPreview);
                setAvatarFile(next);
                setAvatarPreview(URL.createObjectURL(next));
              }}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="edit-name" className="text-[11px] text-subtle">
              {t("common.fullName")}
            </Label>
            <Input
              id="edit-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={60}
              className="h-10 border-line bg-app text-[13px]"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-bio" className="text-[11px] text-subtle">
              {t("common.profile")}
            </Label>
            <Textarea
              id="edit-bio"
              value={bio}
              onChange={(event) => setBio(event.target.value)}
              maxLength={160}
              rows={3}
              placeholder={t("profile.bioPlaceholder")}
              className="resize-none border-line bg-app text-[13px]"
            />
            <p className="text-end text-[10px] text-subtle">{bio.length}/160</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-website" className="text-[11px] text-subtle">
              {t("profile.websitePlaceholder")}
            </Label>
            <Input
              id="edit-website"
              value={website}
              onChange={(event) => setWebsite(event.target.value)}
              placeholder="https://"
              inputMode="url"
              className="h-10 border-line bg-app text-[13px]"
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-line px-3 py-3">
            <div className="pe-3">
              <p className="text-[13px] font-medium">{t("settings.privateAccount")}</p>
              <p className="text-[11px] leading-relaxed text-subtle">
                {t("settings.privateAccountDesc")}
              </p>
            </div>
            <Switch checked={isPrivate} onCheckedChange={setIsPrivate} />
          </div>
          {error ? <p className="text-[12px] text-destructive">{error}</p> : null}
        </div>
        <div className="flex justify-end gap-2 border-t border-line px-4 py-3">
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
            {t("common.cancel")}
          </Button>
          <Button
            size="sm"
            onClick={save}
            disabled={saving}
            className="bg-brand text-white hover:bg-brand-hover"
          >
            {saving ? <Loader2 className="size-4 animate-spin" /> : t("common.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
