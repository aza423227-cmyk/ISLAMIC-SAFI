"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  Grid3X3,
  Bookmark,
  Lock,
  Loader2,
  Settings,
  Share2,
  BadgeCheck,
  MoreHorizontal,
  Flag,
  UserX,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import type { FeedPost, ProfileRow } from "@/lib/queries";
import { useApp } from "@/components/app/app-context";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { PostGrid } from "@/components/feed/post-grid";
import { EditProfileDialog } from "@/components/profile/edit-profile-dialog";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

type ProfileResponse = {
  profile: ProfileRow;
  posts: FeedPost[];
  isSelf: boolean;
  canView: boolean;
};

export function ProfileView() {
  const params = useParams<{ username: string }>();
  const username = decodeURIComponent(params.username ?? "");
  const router = useRouter();
  const { t } = useI18n();
  const { viewer } = useApp();
  const [data, setData] = useState<ProfileResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [following, setFollowing] = useState(false);
  const [followers, setFollowers] = useState(0);
  const [followPending, setFollowPending] = useState(false);
  const [messagePending, setMessagePending] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [tab, setTab] = useState<"posts" | "saved">("posts");
  const [blockOpen, setBlockOpen] = useState(false);
  const [blocking, setBlocking] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api<ProfileResponse>(`/api/users/${encodeURIComponent(username)}`);
      setData(result);
      setFollowing(result.profile.is_following);
      setFollowers(result.profile.followers);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [username, t]);

  useEffect(() => {
    load();
  }, [load]);

  async function toggleFollow() {
    if (!data) return;
    setFollowPending(true);
    try {
      const result = await api<{ following: boolean; followers: number }>(
        `/api/users/${data.profile.username}/follow`,
        { method: "POST" },
      );
      setFollowing(result.following);
      setFollowers(result.followers);
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setFollowPending(false);
    }
  }

  async function openMessage() {
    if (!data) return;
    setMessagePending(true);
    try {
      const result = await api<{ conversationId: string }>("/api/conversations", {
        method: "POST",
        body: JSON.stringify({ userId: data.profile.id }),
      });
      router.push(`/messages/${result.conversationId}`);
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setMessagePending(false);
    }
  }

  async function shareProfile() {
    const url = `${window.location.origin}/u/${username}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t("common.linkCopied"));
    } catch {
      toast.error(t("errors.generic"));
    }
  }

  async function blockUser() {
    if (!data) return;
    setBlocking(true);
    try {
      await api("/api/blocked", {
        method: "POST",
        body: JSON.stringify({ userId: data.profile.id }),
      });
      toast.success(t("common.block"));
      setBlockOpen(false);
      router.push("/");
      router.refresh();
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setBlocking(false);
    }
  }

  async function reportUser() {
    if (!data) return;
    try {
      await api("/api/reports", {
        method: "POST",
        body: JSON.stringify({
          targetType: "user",
          targetId: data.profile.id,
          reason: "Reported from profile",
        }),
      });
      toast.success(t("feed.reportSent"));
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-[935px] px-4 py-6">
        <div className="flex items-center gap-6 sm:gap-12">
          <div className="size-20 animate-pulse rounded-full bg-hover sm:size-36" />
          <div className="flex-1 space-y-3">
            <div className="h-4 w-40 animate-pulse rounded-full bg-hover" />
            <div className="h-3 w-56 animate-pulse rounded-full bg-hover" />
            <div className="h-8 w-full max-w-xs animate-pulse rounded-lg bg-hover" />
          </div>
        </div>
        <div className="mt-8 grid grid-cols-3 gap-1">
          {Array.from({ length: 9 }).map((_, index) => (
            <div key={index} className="aspect-square animate-pulse bg-hover" />
          ))}
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex min-h-[60dvh] flex-col items-center justify-center gap-3 px-6 text-center">
        <Lock className="size-9 text-subtle" strokeWidth={1.3} />
        <p className="text-[15px] font-semibold">{t("errors.notFound")}</p>
        <p className="text-[12px] text-subtle">{error}</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}>
            {t("common.retry")}
          </Button>
          <Button size="sm" onClick={() => router.push("/explore")}>
            {t("explore.title")}
          </Button>
        </div>
      </div>
    );
  }

  const { profile, isSelf, canView } = data;
  const displayName = profile.display_username || profile.username || profile.name;

  return (
    <div className="mx-auto w-full max-w-[935px] px-4 pb-10 pt-4 md:pt-8">
      <header className="flex flex-col gap-5 sm:flex-row sm:items-start sm:gap-12">
        <div className="flex items-center gap-6 sm:block">
          <div className="story-ring shrink-0 rounded-full p-[3px]">
            <div className="rounded-full border-[3px] border-app">
              <UserAvatar
                name={profile.name}
                image={profile.image}
                size="xl"
                className="size-[86px] sm:size-[150px]"
              />
            </div>
          </div>
          <div className="flex flex-1 items-center justify-around gap-6 sm:hidden">
            <Stat label={t("common.posts")} value={profile.posts} />
            <Stat label={t("profile.followersLabel")} value={followers} />
            <Stat label={t("profile.followingLabel")} value={profile.following} />
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-[19px] font-normal leading-tight">{displayName}</h1>
            {profile.verified ? <VerifiedBadge size={17} /> : null}
            {isSelf ? (
              <>
                <Link
                  href="/settings"
                  aria-label={t("common.settings")}
                  className="ms-1 grid size-8 place-items-center rounded-full transition-colors hover:bg-hover"
                >
                  <Settings className="size-5" />
                </Link>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setEditOpen(true)}
                  className="ms-auto h-8 rounded-lg bg-hover px-4 text-[13px] font-semibold text-ink hover:bg-active sm:ms-0"
                >
                  {t("profile.editProfile")}
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={shareProfile}
                  className="h-8 rounded-lg bg-hover px-4 text-[13px] font-semibold text-ink hover:bg-active"
                >
                  {t("profile.shareProfile")}
                </Button>
              </>
            ) : (
              <>
                <Button
                  size="sm"
                  onClick={toggleFollow}
                  disabled={followPending}
                  className={cn(
                    "h-8 rounded-lg px-5 text-[13px] font-semibold",
                    following
                      ? "bg-hover text-ink hover:bg-active"
                      : "bg-brand text-white hover:bg-brand-hover",
                  )}
                >
                  {followPending ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : following ? (
                    t("common.following")
                  ) : profile.follows_you ? (
                    t("profile.followBack")
                  ) : (
                    t("common.follow")
                  )}
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={openMessage}
                  disabled={messagePending}
                  className="h-8 rounded-lg bg-hover px-5 text-[13px] font-semibold text-ink hover:bg-active"
                >
                  {messagePending ? <Loader2 className="size-4 animate-spin" /> : t("common.message")}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={shareProfile}
                  aria-label={t("profile.shareProfile")}
                  className="h-8 rounded-lg px-3 text-[13px] font-semibold"
                >
                  <Share2 className="size-4" />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      aria-label={t("common.more")}
                      className="h-8 rounded-lg px-2 text-[13px]"
                    >
                      <MoreHorizontal className="size-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-52">
                    <DropdownMenuItem onClick={reportUser}>
                      <Flag className="size-4" /> {t("common.report")}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem variant="destructive" onClick={() => setBlockOpen(true)}>
                      <UserX className="size-4" /> {t("common.block")}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
          </div>

          <div className="mt-4 hidden items-center gap-8 sm:flex">
            <Stat label={t("common.posts")} value={profile.posts} />
            <Stat label={t("profile.followersLabel")} value={followers} />
            <Stat label={t("profile.followingLabel")} value={profile.following} />
          </div>

          <div className="mt-3 space-y-1 text-[13px] leading-relaxed">
            <p className="font-semibold">{profile.name}</p>
            {profile.bio ? (
              <p className="whitespace-pre-wrap text-ink">{profile.bio}</p>
            ) : isSelf ? (
              <p className="text-subtle">{t("profile.bioPlaceholder")}</p>
            ) : null}
            {profile.website ? (
              <a
                href={profile.website}
                target="_blank"
                rel="noopener noreferrer"
                className="block truncate font-semibold text-[#00376b] dark:text-[#4db5ff]"
              >
                {profile.website.replace(/^https?:\/\//, "")}
              </a>
            ) : null}
            {profile.follows_you && !isSelf ? (
              <p className="text-[11px] text-subtle">{t("profile.followedYou")}</p>
            ) : null}
            {isSelf && !profile.verified ? (
              <Link
                href="/get-verified"
                className="inline-flex items-center gap-1.5 rounded-full bg-[#c8a45c]/10 px-2.5 py-1 text-[11px] font-semibold text-[#a8853f]"
              >
                <BadgeCheck className="size-3.5" /> {t("common.getVerified")}
              </Link>
            ) : null}
            {isSelf && profile.verified ? (
              <Link
                href="/settings/verification"
                className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-brand"
              >
                <VerifiedBadge size={12} /> {t("verify.active")}
              </Link>
            ) : null}
          </div>
        </div>
      </header>

      <div className="mt-6 border-t border-line">
        <div className="flex justify-center gap-14">
          <button
            type="button"
            onClick={() => setTab("posts")}
            className={cn(
              "flex items-center gap-1.5 border-t py-3 text-[12px] font-semibold uppercase tracking-[0.1em]",
              tab === "posts" ? "border-ink text-ink" : "border-transparent text-subtle",
            )}
          >
            <Grid3X3 className="size-3.5" /> {t("common.posts")}
          </button>
          {isSelf ? (
            <button
              type="button"
              onClick={() => setTab("saved")}
              className={cn(
                "flex items-center gap-1.5 border-t py-3 text-[12px] font-semibold uppercase tracking-[0.1em]",
                tab === "saved" ? "border-ink text-ink" : "border-transparent text-subtle",
              )}
            >
              <Bookmark className="size-3.5" /> {t("profile.saved")}
            </button>
          ) : null}
        </div>

        {!canView ? (
          <div className="flex flex-col items-center gap-3 py-14 text-center">
            <div className="grid size-16 place-items-center rounded-full border border-line">
              <Lock className="size-7" strokeWidth={1.3} />
            </div>
            <p className="text-[15px] font-semibold">{t("profile.privateAccount")}</p>
            <p className="max-w-[18rem] text-[13px] leading-relaxed text-subtle">
              {t("profile.privateBody")}
            </p>
            {!following ? (
              <Button
                size="sm"
                onClick={toggleFollow}
                disabled={followPending}
                className="h-8 rounded-lg bg-brand px-5 text-[13px] font-semibold text-white hover:bg-brand-hover"
              >
                {t("common.follow")}
              </Button>
            ) : (
              <p className="text-[12px] text-subtle">{t("profile.followBack")}</p>
            )}
          </div>
        ) : tab === "saved" ? (
          <PostGrid scope="saved" className="pt-2" />
        ) : (
          <PostGrid scope="profile" profileId={profile.id} className="pt-2" />
        )}
      </div>

      {isSelf ? <EditProfileDialog open={editOpen} onOpenChange={setEditOpen} /> : null}

      <AlertDialog open={blockOpen} onOpenChange={setBlockOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("common.block")}</AlertDialogTitle>
            <AlertDialogDescription>{t("profile.blockConfirm")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <Button variant="destructive" onClick={blockUser} disabled={blocking}>
              {blocking ? <Loader2 className="size-4 animate-spin" /> : t("common.block")}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="text-center sm:text-start">
      <span className="text-[15px] font-semibold sm:me-1">{value.toLocaleString()}</span>
      <span className="text-[13px] text-subtle">{label}</span>
    </div>
  );
}
