"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Loader2, MoreHorizontal, PenSquare, Search, MoonStar, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatRelativeTime } from "@/lib/i18n";
import type { ConversationRow } from "@/lib/queries";
import { UserAvatar } from "@/components/user/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { NewMessageDialog } from "@/components/messages/new-message-dialog";
import { cn } from "@/lib/utils";

export function ConversationList() {
  const { t, locale } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [rows, setRows] = useState<ConversationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const data = await api<{ conversations: ConversationRow[] }>("/api/conversations");
      setRows(data.conversations);
      setError(null);
    } catch (err) {
      if (!silent) setError(errorMessage(err, t));
    } finally {
      if (!silent) setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
    const interval = setInterval(() => load(true), 10000);
    return () => clearInterval(interval);
  }, [load]);

  async function removeConversation(id: string) {
    try {
      await api(`/api/conversations/${id}`, { method: "DELETE" });
      setRows((current) => current.filter((row) => row.id !== id));
      toast.success(t("messages.deleteChat"));
      if (pathname === `/messages/${id}`) router.replace("/messages");
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  const filtered = rows.filter((row) => {
    if (!query.trim()) return true;
    const value = query.toLowerCase();
    return (
      row.other_name.toLowerCase().includes(value) ||
      (row.other_username ?? "").toLowerCase().includes(value)
    );
  });

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-[60px] items-center justify-between px-4">
        <button
          type="button"
          aria-label={t("common.back")}
          onClick={() => router.back()}
          className="text-[13px] text-ink md:hidden"
        >
          {t("common.back")}
        </button>
        <h1 className="text-[15px] font-semibold md:mx-0">{t("messages.title")}</h1>
        <button
          type="button"
          onClick={() => setDialogOpen(true)}
          aria-label={t("messages.newMessage")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
        >
          <PenSquare className="size-5" strokeWidth={1.7} />
        </button>
      </div>

      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-subtle" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("common.search")}
            aria-label={t("common.search")}
            className="h-9 rounded-lg border-0 bg-hover ps-9 text-[13px] focus-visible:ring-1 focus-visible:ring-line"
          />
        </div>
      </div>

      <Link
        href="/messages/ai"
        className="mx-3 mb-2 flex items-center gap-3 rounded-lg border border-line bg-gradient-to-br from-[#101f1a] to-[#0a1210] px-3 py-2.5 text-[#efe6d2]"
      >
        <span className="grid size-9 place-items-center rounded-full bg-white/10">
          <MoonStar className="size-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold">{t("messages.aiAssistant")}</p>
          <p className="truncate text-[11px] text-[#c9bda2]">{t("explore.aiAssistantDesc")}</p>
        </div>
      </Link>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="space-y-3 px-4 py-3">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="size-11 animate-pulse rounded-full bg-hover" />
                <div className="flex-1 space-y-1.5">
                  <div className="h-2.5 w-28 animate-pulse rounded-full bg-hover" />
                  <div className="h-2 w-40 animate-pulse rounded-full bg-hover" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="flex flex-col items-center gap-3 px-6 py-12 text-center">
            <p className="text-[13px] text-subtle">{error}</p>
            <Button size="sm" variant="outline" onClick={() => load()}>
              {t("common.retry")}
            </Button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-6 py-14 text-center">
            <p className="text-[14px] font-semibold">{t("messages.emptyTitle")}</p>
            <p className="text-[12px] text-subtle">{t("messages.emptyBody")}</p>
            <Button
              size="sm"
              onClick={() => setDialogOpen(true)}
              className="mt-1 h-8 rounded-lg bg-brand text-[12px] font-semibold text-white hover:bg-brand-hover"
            >
              {t("messages.startChat")}
            </Button>
          </div>
        ) : (
          <ul>
            {filtered.map((row) => {
              const active = pathname === `/messages/${row.id}`;
              return (
                <li key={row.id} className="group relative">
                  <Link
                    href={`/messages/${row.id}`}
                    className={cn(
                      "flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-hover/60",
                      active && "bg-hover",
                    )}
                  >
                    <UserAvatar
                      name={row.other_name}
                      image={row.other_image}
                      size="md"
                      className={row.unread > 0 ? "story-ring p-[2px]" : ""}
                    />
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="truncate text-[13px] font-semibold">
                        {row.other_username ?? row.other_name}
                      </p>
                      <p
                        className={cn(
                          "truncate text-[12px]",
                          row.unread > 0 ? "font-semibold text-ink" : "text-subtle",
                        )}
                      >
                        {row.last_kind === "voice"
                          ? t("messages.voiceNote")
                          : row.last_kind === "image" || row.last_kind === "video"
                            ? t("messages.attach")
                            : row.last_body || t("messages.noMessages")}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-[10px] text-subtle">
                        {formatRelativeTime(row.last_at, locale)}
                      </span>
                      {row.unread > 0 ? (
                        <span className="grid min-w-[18px] place-items-center rounded-full bg-brand px-1 text-[10px] font-semibold leading-[18px] text-white">
                          {row.unread}
                        </span>
                      ) : null}
                    </div>
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        aria-label={t("common.more")}
                        className="absolute end-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-full bg-surface text-subtle opacity-0 shadow-sm transition-opacity group-hover:opacity-100 focus-visible:opacity-100"
                      >
                        <MoreHorizontal className="size-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        variant="destructive"
                        onClick={() => removeConversation(row.id)}
                      >
                        <Trash2 className="size-4" /> {t("messages.deleteChat")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <NewMessageDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </div>
  );
}
