"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Search } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

type SearchUser = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
  bio: string | null;
};

export function NewMessageDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t } = useI18n();
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<SearchUser[]>([]);
  const [searching, setSearching] = useState(false);
  const [pendingId, setPendingId] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setQuery("");
      setUsers([]);
    }
  }, [open]);

  useEffect(() => {
    if (!query.trim()) {
      setUsers([]);
      return;
    }
    let cancelled = false;
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const data = await api<{ users: SearchUser[] }>(
          `/api/users/search?q=${encodeURIComponent(query.trim())}`,
        );
        if (!cancelled) setUsers(data.users);
      } catch {
        if (!cancelled) setUsers([]);
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  async function start(user: SearchUser) {
    setPendingId(user.id);
    try {
      const data = await api<{ conversationId: string }>("/api/conversations", {
        method: "POST",
        body: JSON.stringify({ userId: user.id }),
      });
      onOpenChange(false);
      router.push(`/messages/${data.conversationId}`);
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPendingId(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-line bg-surface p-0 sm:max-w-[420px]">
        <DialogHeader className="border-b border-line px-4 py-3">
          <DialogTitle className="text-center text-[15px] font-semibold">
            {t("messages.newMessage")}
          </DialogTitle>
        </DialogHeader>
        <div className="px-3 py-2">
          <div className="relative">
            <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-subtle" />
            <Input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t("messages.searchPeople")}
              aria-label={t("messages.searchPeople")}
              className="h-9 border-0 bg-hover ps-9 text-[13px] focus-visible:ring-1 focus-visible:ring-line"
            />
          </div>
        </div>
        <div className="max-h-[50dvh] overflow-y-auto px-1 pb-2">
          {searching ? (
            <div className="flex items-center justify-center gap-2 py-8 text-[12px] text-subtle">
              <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
            </div>
          ) : users.length === 0 ? (
            <p className="py-8 text-center text-[12px] text-subtle">
              {query ? t("explore.noUsers") : t("messages.searchPeople")}
            </p>
          ) : (
            <ul>
              {users.map((user) => (
                <li key={user.id}>
                  <button
                    type="button"
                    onClick={() => start(user)}
                    disabled={pendingId === user.id}
                    className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-start transition-colors hover:bg-hover"
                  >
                    <UserAvatar name={user.name} image={user.image} size="md" />
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="flex items-center gap-1 truncate text-[13px] font-semibold">
                        {user.username ?? user.name}
                        {user.verified ? <VerifiedBadge size={12} /> : null}
                      </p>
                      <p className="truncate text-[12px] text-subtle">{user.name}</p>
                    </div>
                    {pendingId === user.id ? <Loader2 className="size-4 animate-spin" /> : null}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
