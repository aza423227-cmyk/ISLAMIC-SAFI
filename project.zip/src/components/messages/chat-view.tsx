"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  ImagePlus,
  Loader2,
  Mic,
  Send,
  Square,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatTime } from "@/lib/i18n";
import type { MessageRow } from "@/lib/queries";
import { UserAvatar, VerifiedBadge } from "@/components/user/avatar";
import { useApp } from "@/components/app/app-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

type OtherUser = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
};

type ChatMessage = MessageRow & { pending?: boolean };

export function ChatView() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { t, locale } = useI18n();
  const { viewer } = useApp();
  const conversationId = params.id;

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [other, setOther] = useState<OtherUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedAtRef = useRef<number>(0);

  const scrollToBottom = useCallback((smooth = false) => {
    const node = scrollRef.current;
    if (!node) return;
    node.scrollTo({ top: node.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }, []);

  const load = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      try {
        const data = await api<{ messages: MessageRow[]; other: OtherUser | null }>(
          `/api/conversations/${conversationId}/messages`,
        );
        setOther(data.other);
        setMessages((current) => {
          const pending = current.filter((message) => message.pending);
          const seen = new Set(data.messages.map((message) => message.id));
          return [...data.messages, ...pending.filter((message) => !seen.has(message.id))];
        });
        setError(null);
      } catch (err) {
        if (!silent) setError(errorMessage(err, t));
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [conversationId, t],
  );

  useEffect(() => {
    load();
    const interval = setInterval(() => load(true), 4000);
    return () => clearInterval(interval);
  }, [load]);

  useEffect(() => {
    scrollToBottom();
  }, [messages.length, scrollToBottom]);

  useEffect(() => {
    if (!recording) return;
    const interval = setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => clearInterval(interval);
  }, [recording]);

  async function sendText(event: React.FormEvent) {
    event.preventDefault();
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    const temp: ChatMessage = {
      id: `temp-${Date.now()}`,
      conversation_id: conversationId,
      sender_id: viewer.id,
      body,
      media_id: null,
      mime: null,
      kind: "text",
      duration_sec: null,
      created_at: new Date().toISOString(),
      sender_name: viewer.name,
      sender_image: viewer.image,
      pending: true,
    };
    setMessages((current) => [...current, temp]);
    setText("");
    try {
      const data = await api<{ message: MessageRow }>(
        `/api/conversations/${conversationId}/messages`,
        { method: "POST", body: JSON.stringify({ body, kind: "text" }) },
      );
      setMessages((current) =>
        current.map((message) => (message.id === temp.id ? data.message : message)),
      );
    } catch (err) {
      setMessages((current) => current.filter((message) => message.id !== temp.id));
      setText(body);
      toast.error(errorMessage(err, t));
    } finally {
      setSending(false);
    }
  }

  async function sendMedia(file: File, kind: "image" | "video" | "voice", durationSec?: number) {
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("purpose", kind === "voice" ? "voice" : "message");
      const uploaded = await api<{ id: string }>("/api/upload", {
        method: "POST",
        body: form,
      });
      const data = await api<{ message: MessageRow }>(
        `/api/conversations/${conversationId}/messages`,
        {
          method: "POST",
          body: JSON.stringify({
            mediaId: uploaded.id,
            kind,
            durationSec,
            body: "",
          }),
        },
      );
      setMessages((current) => [...current, data.message]);
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setUploading(false);
      setRecording(false);
      setSeconds(0);
    }
  }

  async function onPickFile(file: File | undefined) {
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) {
      toast.error(t("errors.tooLarge"));
      return;
    }
    const kind = file.type.startsWith("video/") ? "video" : "image";
    if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
      toast.error(t("errors.moderation"));
      return;
    }
    await sendMedia(file, kind);
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      startedAtRef.current = Date.now();
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const duration = Math.round((Date.now() - startedAtRef.current) / 1000);
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        if (blob.size < 500) {
          setRecording(false);
          setSeconds(0);
          return;
        }
        const file = new File([blob], `voice-${Date.now()}.webm`, { type: "audio/webm" });
        await sendMedia(file, "voice", Math.max(1, duration));
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
      setSeconds(0);
    } catch {
      toast.error(t("messages.recordingFailed"));
    }
  }

  function stopRecording() {
    recorderRef.current?.stop();
    recorderRef.current = null;
  }

  async function deleteConversation() {
    try {
      await api(`/api/conversations/${conversationId}/messages`, { method: "DELETE" });
      router.replace("/messages");
    } catch (err) {
      toast.error(errorMessage(err, t));
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="size-5 animate-spin text-subtle" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="text-[13px] text-subtle">{error}</p>
        <Button variant="outline" size="sm" onClick={() => load()}>
          {t("common.retry")}
        </Button>
        <Link href="/messages" className="text-[13px] font-semibold text-brand">
          {t("messages.title")}
        </Link>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-surface">
      <header className="flex h-[60px] items-center gap-3 border-b border-line px-3">
        <Link
          href="/messages"
          aria-label={t("common.back")}
          className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover md:hidden"
        >
          <ArrowLeft className="size-5 rtl:rotate-180" />
        </Link>
        {other ? (
          <>
            <Link href={other.username ? `/u/${other.username}` : "/explore"}>
              <UserAvatar name={other.name} image={other.image} size="sm" />
            </Link>
            <div className="min-w-0 flex-1 leading-tight">
              <Link
                href={other.username ? `/u/${other.username}` : "/explore"}
                className="flex items-center gap-1 truncate text-[13px] font-semibold"
              >
                {other.name}
                {other.verified ? <VerifiedBadge size={12} /> : null}
              </Link>
              <p className="truncate text-[11px] text-subtle">
                {other.username ? `@${other.username}` : ""}
              </p>
            </div>
          </>
        ) : (
          <div className="flex-1" />
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              aria-label={t("common.more")}
              className="grid size-9 place-items-center rounded-full transition-colors hover:bg-hover"
            >
              <span className="text-[18px] leading-none">···</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem variant="destructive" onClick={deleteConversation}>
              <Trash2 className="size-4" /> {t("messages.deleteChat")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      <div ref={scrollRef} className="flex-1 space-y-1.5 overflow-y-auto px-3 py-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-14 text-center">
            {other ? (
              <UserAvatar name={other.name} image={other.image} size="xl" />
            ) : null}
            <p className="text-[14px] font-semibold">
              {other?.name ?? t("messages.title")}
            </p>
            <p className="max-w-[18rem] text-[12px] text-subtle">{t("messages.noMessages")}</p>
          </div>
        ) : (
          messages.map((message, index) => {
            const mine = message.sender_id === viewer.id;
            const previous = messages[index - 1];
            const showAvatar = !mine && previous?.sender_id !== message.sender_id;
            return (
              <div
                key={message.id}
                className={cn("flex items-end gap-2", mine ? "justify-end" : "justify-start")}
              >
                {!mine ? (
                  <div className="w-7 shrink-0">
                    {showAvatar && other ? (
                      <UserAvatar name={other.name} image={other.image} size="xs" />
                    ) : null}
                  </div>
                ) : null}
                <div
                  className={cn(
                    "max-w-[78%] space-y-1 rounded-[18px] px-3.5 py-2",
                    mine
                      ? "bg-brand text-white"
                      : "bg-hover text-ink",
                    message.pending && "opacity-70",
                  )}
                >
                  {message.kind === "text" ? (
                    <p className="whitespace-pre-wrap break-words text-[13px] leading-relaxed">
                      {message.body}
                    </p>
                  ) : null}
                  {message.kind === "image" && message.media_id ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={`/api/media/${message.media_id}`}
                      alt=""
                      className="max-h-[280px] w-auto max-w-[230px] rounded-xl object-cover"
                    />
                  ) : null}
                  {message.kind === "video" && message.media_id ? (
                    <video
                      src={`/api/media/${message.media_id}`}
                      controls
                      playsInline
                      className="max-h-[280px] w-auto max-w-[230px] rounded-xl"
                    />
                  ) : null}
                  {message.kind === "voice" && message.media_id ? (
                    <div className="w-[220px]">
                      <audio controls src={`/api/media/${message.media_id}`} className="h-9 w-full" />
                      <p className={cn("mt-1 text-[10px]", mine ? "text-white/70" : "text-subtle")}>
                        {message.duration_sec ?? 0}s
                      </p>
                    </div>
                  ) : null}
                  <p
                    className={cn(
                      "text-end text-[9px]",
                      mine ? "text-white/70" : "text-subtle",
                    )}
                  >
                    {formatTime(message.created_at, locale, false)}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      <form
        onSubmit={sendText}
        className="flex items-center gap-1.5 border-t border-line px-2 py-2 pb-[calc(8px+env(safe-area-inset-bottom))] md:pb-2"
      >
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/mp4,video/webm"
          className="sr-only"
          onChange={(event) => onPickFile(event.target.files?.[0])}
        />
        {!recording ? (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            aria-label={t("messages.attach")}
            className="grid size-10 place-items-center rounded-full text-ink transition-colors hover:bg-hover"
          >
            {uploading ? (
              <Loader2 className="size-5 animate-spin" />
            ) : (
              <ImagePlus className="size-5" strokeWidth={1.7} />
            )}
          </button>
        ) : null}

        {recording ? (
          <div className="flex h-10 flex-1 items-center gap-2 rounded-full bg-[#ff3040]/10 px-4 text-[13px] text-[#ff3040]">
            <span className="size-2 animate-pulse rounded-full bg-[#ff3040]" />
            {t("messages.recording")} {seconds}s
          </div>
        ) : (
          <input
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder={t("messages.typeMessage")}
            aria-label={t("messages.typeMessage")}
            className="h-10 flex-1 rounded-full border border-line bg-app px-4 text-[13px] outline-none focus:ring-1 focus:ring-line"
          />
        )}

        {text.trim() && !recording ? (
          <button
            type="submit"
            disabled={sending}
            aria-label={t("common.send")}
            className="grid size-10 place-items-center rounded-full text-brand transition-transform active:scale-95 disabled:opacity-50"
          >
            {sending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-5" />}
          </button>
        ) : recording ? (
          <button
            type="button"
            onClick={stopRecording}
            aria-label={t("messages.recording")}
            className="grid size-10 place-items-center rounded-full bg-[#ff3040] text-white"
          >
            <Square className="size-4 fill-white" />
          </button>
        ) : (
          <button
            type="button"
            onClick={startRecording}
            aria-label={t("messages.voiceNote")}
            className="grid size-10 place-items-center rounded-full text-ink transition-colors hover:bg-hover"
          >
            <Mic className="size-5" strokeWidth={1.7} />
          </button>
        )}
      </form>
    </div>
  );
}
