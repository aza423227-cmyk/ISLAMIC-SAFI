"use client";

import { useCallback, useEffect, useState } from "react";
import { BadgeCheck, Check, Crown, Loader2, ShieldCheck, MoonStar } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n/provider";
import { api, errorMessage } from "@/lib/api";
import { formatDate } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { VerifiedBadge } from "@/components/user/avatar";
import { Wordmark, GoldRule } from "@/components/brand/wordmark";
import { cn } from "@/lib/utils";

type Plan = {
  id: string;
  amount: number;
  currency: "INR";
  interval: "monthly" | "yearly";
  label: string;
};

type VerificationData = {
  plans: Plan[];
  configured: boolean;
  active: boolean;
  verifiedUntil: string | null;
  payment: { id: string; planId: string; status: string; endedAt: string | null } | null;
};

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => { open: () => void };
  }
}

function loadCheckout(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(Boolean(window.Razorpay));
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export function VerificationView() {
  const { t, locale } = useI18n();
  const router = useRouter();
  const [data, setData] = useState<VerificationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingPlan, setPendingPlan] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await api<VerificationData>("/api/verification");
      setData(result);
      setError(null);
    } catch (err) {
      setError(errorMessage(err, t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    load();
  }, [load]);

  const benefits = [
    t("verify.benefit1"),
    t("verify.benefit2"),
    t("verify.benefit3"),
    t("verify.benefit4"),
  ];

  async function subscribe(plan: Plan) {
    setPendingPlan(plan.id);
    try {
      const result = await api<{
        mode: "sandbox" | "razorpay";
        orderId?: string;
        keyId?: string;
        amount?: number;
      }>("/api/verification", {
        method: "POST",
        body: JSON.stringify({ planId: plan.id }),
      });

      if (result.mode === "sandbox") {
        toast.success(t("verify.paymentSuccess"));
        await load();
        router.refresh();
        return;
      }

      if (!result.orderId || !result.keyId || !window.Razorpay) {
        const ready = await loadCheckout();
        if (!ready) {
          toast.error(t("errors.paymentUnavailable"));
          return;
        }
      }

      const checkout = new window.Razorpay!({
        key: result.keyId,
        amount: (result.amount ?? plan.amount * 100),
        currency: plan.currency,
        name: "ISLAMIC BESSAFI",
        description: `${t("verify.title")} · ${plan.label}`,
        order_id: result.orderId,
        theme: { color: "#0095f6" },
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
          razorpay_signature: string;
        }) => {
          try {
            await api("/api/verification/confirm", {
              method: "POST",
              body: JSON.stringify(response),
            });
            toast.success(t("verify.paymentSuccess"));
            await load();
            router.refresh();
          } catch (err) {
            toast.error(errorMessage(err, t));
          }
        },
        modal: {
          ondismiss: () => setPendingPlan(null),
        },
      });
      checkout.open();
    } catch (err) {
      toast.error(errorMessage(err, t));
    } finally {
      setPendingPlan(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-20 text-[13px] text-subtle">
        <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex flex-col items-center gap-3 py-16 text-center">
        <p className="text-[13px] text-subtle">{error}</p>
        <Button size="sm" variant="outline" onClick={load}>
          {t("common.retry")}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-2xl border border-line bg-gradient-to-br from-[#0f1f1a] via-[#142a22] to-[#0a1210] px-5 py-7 text-[#efe6d2]">
        <div className="absolute -end-10 -top-10 size-40 rounded-full bg-[#c8a45c]/10 blur-2xl" />
        <div className="relative flex flex-col items-start gap-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em]">
            <Crown className="size-3" /> Meta Verified
          </span>
          <h2 className="font-wordmark text-[26px] leading-tight">{t("verify.title")}</h2>
          <GoldRule />
          <p className="max-w-sm text-[12px] leading-relaxed text-[#c9bda2]">
            {t("verify.subtitle")}
          </p>
          <div className="mt-1 flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
            <VerifiedBadge size={18} />
            <span className="text-[12px]">
              {data.active ? t("verify.active") : t("verify.badgeTitle")}
            </span>
          </div>
          {data.active && data.verifiedUntil ? (
            <p className="text-[11px] text-[#c9bda2]">
              {t("verify.activeUntil")} {formatDate(data.verifiedUntil, locale)}
            </p>
          ) : null}
        </div>
      </div>

      {!data.active ? (
        <div className="rounded-xl border border-line bg-surface p-4">
          <p className="mb-2 text-[12px] font-semibold">{t("verify.badgeTitle")}</p>
          <ul className="space-y-2">
            {benefits.map((benefit) => (
              <li key={benefit} className="flex items-start gap-2 text-[12px] text-ink">
                <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-[#0095f6] text-white">
                  <Check className="size-2.5" strokeWidth={3} />
                </span>
                {benefit}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {!data.configured ? (
        <div className="rounded-xl border border-[#c8a45c]/40 bg-[#c8a45c]/5 px-4 py-3">
          <p className="flex items-center gap-1.5 text-[12px] font-semibold text-[#8a6d2f] dark:text-[#d9b86f]">
            <ShieldCheck className="size-4" /> {t("verify.sandboxTitle")}
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-subtle">{t("verify.sandboxDesc")}</p>
        </div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        {data.plans.map((plan) => {
          const yearly = plan.interval === "yearly";
          const active = pendingPlan === plan.id;
          return (
            <div
              key={plan.id}
              className={cn(
                "relative flex flex-col gap-3 rounded-xl border bg-surface p-4",
                yearly ? "border-[#c8a45c]/60" : "border-line",
              )}
            >
              {yearly ? (
                <span className="absolute end-3 top-3 rounded-full bg-[#c8a45c]/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-[#8a6d2f] dark:text-[#d9b86f]">
                  {t("verify.popular")}
                </span>
              ) : null}
              <div>
                <p className="text-[12px] font-semibold uppercase tracking-wider text-subtle">
                  {yearly ? t("verify.yearly") : t("verify.monthly")}
                </p>
                <p className="mt-1 text-[26px] font-semibold leading-none">
                  {new Intl.NumberFormat(locale, {
                    style: "currency",
                    currency: plan.currency,
                    maximumFractionDigits: 0,
                  }).format(plan.amount)}
                </p>
                <p className="mt-1 text-[11px] text-subtle">
                  {yearly ? t("verify.perYear") : t("verify.perMonth")}
                </p>
              </div>
              <Button
                onClick={() => subscribe(plan)}
                disabled={pendingPlan !== null}
                className={cn(
                  "h-9 w-full rounded-lg text-[12px] font-semibold",
                  yearly
                    ? "bg-[#c8a45c] text-[#1b1405] hover:bg-[#d4b371]"
                    : "bg-brand text-white hover:bg-brand-hover",
                )}
              >
                {active ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : data.active ? (
                  t("common.refresh")
                ) : (
                  t("verify.subscribe")
                )}
              </Button>
            </div>
          );
        })}
      </div>

      <p className="px-1 text-[11px] leading-relaxed text-subtle">{t("verify.priceNote")}</p>

      {data.active ? (
        <div className="rounded-xl border border-line bg-surface p-4">
          <p className="flex items-center gap-1.5 text-[12px] font-semibold">
            <BadgeCheck className="size-4 text-[#0095f6]" /> {t("verify.badgeDesc")}
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-subtle">
            {t("verify.active")}
            {data.verifiedUntil ? ` · ${formatDate(data.verifiedUntil, locale)}` : ""}
          </p>
        </div>
      ) : null}

      <div className="flex items-center justify-center gap-2 py-2 opacity-80">
        <Wordmark compact />
        <MoonStar className="size-3 text-[#c8a45c]" />
      </div>
    </div>
  );
}
