import { cn } from "@/lib/utils";

export function Wordmark({
  className,
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "font-wordmark select-none leading-none text-ink",
        compact ? "text-[20px]" : "text-[26px] sm:text-[30px]",
        className,
      )}
      aria-label="ISLAMIC BESSAFI"
    >
      <span className="font-semibold tracking-[0.06em]">ISLAMIC</span>
      <span className="mx-[0.35em] inline-block size-[3px] translate-y-[-0.28em] rounded-full bg-[#c8a45c]" />
      <span className="font-medium tracking-[0.16em]">BESSAFI</span>
    </div>
  );
}

export function GoldRule({ className }: { className?: string }) {
  return <div className={cn("h-px w-10 bg-[#c8a45c]/70", className)} />;
}
