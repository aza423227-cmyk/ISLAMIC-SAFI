"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/provider";
import { localeList } from "@/lib/i18n";
import { authClient } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Wordmark, GoldRule } from "@/components/brand/wordmark";
import { cn } from "@/lib/utils";

type Mode = "sign-in" | "sign-up";

function mapAuthError(code: string | undefined, message: string | undefined) {
  const raw = `${code ?? ""} ${message ?? ""}`.toLowerCase();
  if (raw.includes("username")) return "auth.usernameTaken";
  if (raw.includes("already") && raw.includes("email")) return "auth.emailTaken";
  if (raw.includes("user") && raw.includes("exist")) return "auth.emailTaken";
  if (raw.includes("password") && raw.includes("length")) return "auth.passwordShort";
  if (raw.includes("invalid") || raw.includes("credential")) return "auth.invalidCredentials";
  return "errors.generic";
}

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const { t, locale, setLocale } = useI18n();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isSignUp = mode === "sign-up";

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);

    if (isSignUp) {
      const cleaned = username.replace(/^@/, "").trim();
      if (!/^[a-zA-Z0-9_]{3,30}$/.test(cleaned)) {
        setError(t("auth.usernameInvalid"));
        return;
      }
      if (password.length < 8) {
        setError(t("auth.passwordShort"));
        return;
      }
      if (!name.trim()) {
        setError(t("errors.required"));
        return;
      }
    } else if (!email.trim() || !password) {
      setError(t("errors.required"));
      return;
    }

    setPending(true);
    try {
      const result = isSignUp
        ? await authClient.signUp.email({
            email: email.trim(),
            password,
            name: name.trim(),
            username: username.replace(/^@/, "").trim(),
            displayUsername: username.replace(/^@/, "").trim(),
          })
        : await authClient.signIn.email({
            email: email.trim(),
            password,
          });

      if (result.error) {
        setError(t(mapAuthError(result.error.code, result.error.message)));
        setPending(false);
        return;
      }

      toast.success(isSignUp ? t("auth.accountCreated") : t("auth.welcome"));
      router.replace("/");
      router.refresh();
    } catch {
      setError(t("errors.generic"));
      setPending(false);
    }
  }

  return (
    <div className="flex min-h-dvh flex-col bg-app">
      <div className="flex flex-1 items-center justify-center px-4 py-8 sm:py-12">
        <div className="grid w-full max-w-4xl items-center gap-10 lg:grid-cols-[1.05fr_1fr]">
          <div className="hidden flex-col items-start gap-6 lg:flex">
            <Wordmark className="text-[34px]" />
            <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-line bg-surface p-6">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(200,164,92,0.16),transparent_45%),radial-gradient(circle_at_90%_90%,rgba(0,149,246,0.10),transparent_50%)]" />
              <div className="relative space-y-5">
                <div className="flex items-center gap-3">
                  <div className="story-ring rounded-full p-[2px]">
                    <div className="size-11 rounded-full bg-surface" />
                  </div>
                  <div className="space-y-1.5">
                    <div className="h-2.5 w-28 rounded-full bg-ink/80" />
                    <div className="h-2 w-16 rounded-full bg-subtle/50" />
                  </div>
                </div>
                <div className="aspect-[4/3] w-full rounded-xl bg-gradient-to-br from-[#0f1f1a] via-[#1c3b31] to-[#0a0f12] p-5">
                  <div className="flex h-full flex-col justify-between text-[#e8dcc0]">
                    <p className="font-arabic text-2xl leading-relaxed">
                      بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                    </p>
                    <div className="space-y-2">
                      <GoldRule className="w-14" />
                      <p className="max-w-[15rem] text-xs leading-relaxed text-[#cdbd97]">
                        A calm, halal space for the Ummah to share light.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-subtle">
                  <div className="h-2 w-2 rounded-full bg-[#c8a45c]" />
                  <div className="h-2 w-24 rounded-full bg-subtle/30" />
                  <div className="h-2 w-10 rounded-full bg-subtle/30" />
                </div>
              </div>
            </div>
            <p className="max-w-sm text-sm leading-relaxed text-subtle">{t("auth.tagline")}</p>
          </div>

          <div className="mx-auto w-full max-w-[400px]">
            <div className="rounded-xl border border-line bg-surface px-6 pb-7 pt-8 sm:px-9">
              <div className="flex flex-col items-center gap-3 text-center lg:hidden">
                <Wordmark compact />
                <GoldRule />
              </div>

              <h1 className="mt-6 text-center text-[17px] font-semibold text-ink lg:mt-0">
                {isSignUp ? t("auth.signUpTitle") : t("auth.signInTitle")}
              </h1>
              {isSignUp ? (
                <p className="mt-2 text-center text-xs leading-relaxed text-subtle">
                  {t("auth.signUpSubtitle")}
                </p>
              ) : null}

              <form onSubmit={onSubmit} className="mt-6 space-y-3.5" noValidate>
                {isSignUp ? (
                  <>
                    <div className="space-y-1.5">
                      <Label htmlFor="email" className="text-[11px] font-medium text-subtle">
                        {t("common.email")}
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        autoComplete="email"
                        inputMode="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder={t("auth.emailPlaceholder")}
                        className="h-11 border-line bg-[#fafafa] text-[14px] text-ink placeholder:text-subtle/70 focus-visible:ring-1 focus-visible:ring-line dark:bg-[#121212]"
                        required
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="name" className="text-[11px] font-medium text-subtle">
                        {t("common.fullName")}
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        autoComplete="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={t("auth.namePlaceholder")}
                        className="h-11 border-line bg-[#fafafa] text-[14px] text-ink placeholder:text-subtle/70 focus-visible:ring-1 focus-visible:ring-line dark:bg-[#121212]"
                        required
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="username" className="text-[11px] font-medium text-subtle">
                        {t("common.username")}
                      </Label>
                      <div className="relative">
                        <span className="pointer-events-none absolute inset-y-0 start-3 flex items-center text-[14px] text-subtle">
                          @
                        </span>
                        <Input
                          id="username"
                          type="text"
                          autoComplete="username"
                          value={username.replace(/^@/, "")}
                          onChange={(e) => setUsername(e.target.value.replace(/^@/, ""))}
                          placeholder={t("auth.usernamePlaceholder")}
                          className="h-11 border-line bg-[#fafafa] ps-7 text-[14px] text-ink placeholder:text-subtle/70 focus-visible:ring-1 focus-visible:ring-line dark:bg-[#121212]"
                          required
                        />
                      </div>
                      <p className="text-[11px] text-subtle">{t("auth.usernameInvalid")}</p>
                    </div>
                  </>
                ) : (
                  <div className="space-y-1.5">
                    <Label htmlFor="email" className="text-[11px] font-medium text-subtle">
                      {t("common.email")}
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      autoComplete="email"
                      inputMode="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={t("auth.emailPlaceholder")}
                      className="h-11 border-line bg-[#fafafa] text-[14px] text-ink placeholder:text-subtle/70 focus-visible:ring-1 focus-visible:ring-line dark:bg-[#121212]"
                      required
                    />
                  </div>
                )}

                <div className="space-y-1.5">
                  <Label htmlFor="password" className="text-[11px] font-medium text-subtle">
                    {t("common.password")}
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      autoComplete={isSignUp ? "new-password" : "current-password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={t("auth.passwordPlaceholder")}
                      className="h-11 border-line bg-[#fafafa] pe-10 text-[14px] text-ink placeholder:text-subtle/70 focus-visible:ring-1 focus-visible:ring-line dark:bg-[#121212]"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((value) => !value)}
                      aria-label={showPassword ? t("auth.hidePassword") : t("auth.showPassword")}
                      className="absolute inset-y-0 end-0 flex w-10 items-center justify-center text-subtle transition-colors hover:text-ink"
                    >
                      {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                    </button>
                  </div>
                </div>

                {error ? (
                  <p
                    role="alert"
                    className="rounded-md bg-destructive/10 px-3 py-2 text-[12px] leading-relaxed text-destructive"
                  >
                    {error}
                  </p>
                ) : null}

                <Button
                  type="submit"
                  disabled={pending}
                  className={cn(
                    "mt-1 h-11 w-full rounded-lg bg-brand text-[14px] font-semibold text-white transition-colors hover:bg-brand-hover",
                    "disabled:opacity-70",
                  )}
                >
                  {pending ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      {isSignUp ? t("auth.signingUp") : t("auth.signingIn")}
                    </>
                  ) : isSignUp ? (
                    t("auth.signUpCta")
                  ) : (
                    t("auth.signInCta")
                  )}
                </Button>
              </form>

              <div className="my-5 flex items-center gap-3">
                <div className="h-px flex-1 bg-line" />
                <span className="text-[11px] font-medium uppercase tracking-wider text-subtle">
                  {t("common.or")}
                </span>
                <div className="h-px flex-1 bg-line" />
              </div>

              {isSignUp ? (
                <p className="text-center text-[11px] leading-relaxed text-subtle">
                  {t("auth.terms")}
                </p>
              ) : (
                <Link
                  href="/auth/sign-up"
                  className="block text-center text-[13px] font-semibold text-brand transition-opacity hover:opacity-80"
                >
                  {t("auth.signUpCta")}
                </Link>
              )}

              <div className="mt-6 flex items-center justify-center">
                <Select value={locale} onValueChange={(value) => setLocale(value as never)}>
                  <SelectTrigger
                    aria-label={t("common.language")}
                    className="h-8 w-auto gap-1 border-none bg-transparent px-2 text-[12px] text-subtle shadow-none focus:ring-0"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent align="center">
                    {localeList.map((item) => (
                      <SelectItem key={item.code} value={item.code}>
                        {item.native}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-line bg-surface px-6 py-5 text-center">
              <p className="text-[13px] text-ink">
                {isSignUp ? t("auth.haveAccount") : t("auth.noAccount")}{" "}
                <Link
                  href={isSignUp ? "/auth/sign-in" : "/auth/sign-up"}
                  className="font-semibold text-brand hover:opacity-80"
                >
                  {isSignUp ? t("auth.signInCta") : t("auth.signUpCta")}
                </Link>
              </p>
            </div>

            <div className="mt-8 text-center text-[11px] text-subtle">
              <span className="font-wordmark text-[13px] tracking-[0.14em] text-ink/60">
                ISLAMIC BESSAFI
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
