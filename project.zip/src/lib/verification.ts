import crypto from "crypto";
import { eq, and, desc } from "drizzle-orm";
import { db } from "./db";
import { verificationPayments, user } from "./schema";

export type VerificationPlan = {
  id: string;
  days: number;
  amount: number;
  currency: "INR";
  interval: "monthly" | "yearly";
  active: boolean;
  label: string;
  badge: string;
};

export const verificationPlans: VerificationPlan[] = [
  {
    id: "verified_monthly",
    days: 30,
    amount: 299,
    currency: "INR",
    interval: "monthly",
    active: true,
    label: "Monthly",
    badge: "M",
  },
  {
    id: "verified_yearly",
    days: 365,
    amount: 1999,
    currency: "INR",
    interval: "yearly",
    active: true,
    label: "Yearly",
    badge: "Y",
  },
];

export function getPlan(id: string) {
  return verificationPlans.find((plan) => plan.id === id && plan.active) ?? null;
}

export function razorpayConfigured() {
  return Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
}

export async function createRazorpayOrder(plan: VerificationPlan, userId: string) {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) throw new Error("PAYMENT_UNAVAILABLE");
  const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${auth}`,
    },
    body: JSON.stringify({
      amount: plan.amount * 100,
      currency: plan.currency,
      receipt: `${plan.id}-${userId.slice(0, 18)}-${Date.now()}`,
      notes: { planId: plan.id, userId },
    }),
  });
  const json = (await response.json()) as { id?: string; error?: { description?: string } };
  if (!response.ok || !json.id) {
    throw new Error(json.error?.description ?? "PAYMENT_FAILED");
  }
  return json.id;
}

export function verifyRazorpaySignature(orderId: string, paymentId: string, signature: string) {
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret) return false;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(`${orderId}|${paymentId}`)
    .digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  } catch {
    return false;
  }
}

export function verifyWebhookSignature(rawBody: string, signature: string) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return false;
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  } catch {
    return false;
  }
}

export async function grantVerification(userId: string, plan: VerificationPlan) {
  const current = await db.query.user.findFirst({ where: eq(user.id, userId) });
  if (!current) throw new Error("NOT_FOUND");
  const now = Date.now();
  const existingEnd = current.verifiedUntil ? new Date(current.verifiedUntil).getTime() : 0;
  const startsAt = new Date(Math.max(now, existingEnd));
  const endsAt = new Date(startsAt.getTime() + plan.days * 24 * 60 * 60 * 1000);
  await db
    .update(user)
    .set({ verified: true, verifiedUntil: endsAt, updatedAt: new Date() })
    .where(eq(user.id, userId));
  return { startsAt, endsAt };
}

export async function recordPayment(params: {
  userId: string;
  plan: VerificationPlan;
  status: string;
  provider: string;
  providerOrderId?: string | null;
  providerPaymentId?: string | null;
}) {
  const existing = params.providerPaymentId
    ? await db.query.verificationPayments.findFirst({
        where: eq(verificationPayments.providerPaymentId, params.providerPaymentId),
      })
    : null;
  if (existing && existing.status === "captured") return existing;

  const { startsAt, endsAt } =
    params.status === "captured"
      ? await grantVerification(params.userId, params.plan)
      : { startsAt: null, endsAt: null };

  if (existing) {
    const [updated] = await db
      .update(verificationPayments)
      .set({
        status: params.status,
        providerPaymentId: params.providerPaymentId ?? existing.providerPaymentId,
        startsAt,
        endsAt,
      })
      .where(eq(verificationPayments.id, existing.id))
      .returning();
    return updated;
  }

  const [row] = await db
    .insert(verificationPayments)
    .values({
      userId: params.userId,
      planId: params.plan.id,
      amountMicros: params.plan.amount * 1_000_000,
      currency: params.plan.currency,
      provider: params.provider,
      providerOrderId: params.providerOrderId ?? null,
      providerPaymentId: params.providerPaymentId ?? null,
      status: params.status,
      startsAt,
      endsAt,
    })
    .returning();
  return row;
}

export async function currentVerification(userId: string) {
  const rows = await db
    .select()
    .from(verificationPayments)
    .where(and(eq(verificationPayments.userId, userId), eq(verificationPayments.status, "captured")))
    .orderBy(desc(verificationPayments.createdAt))
    .limit(1);
  return rows[0] ?? null;
}

export function formatPrice(amount: number, currency: "INR" = "INR", locale = "en") {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}
