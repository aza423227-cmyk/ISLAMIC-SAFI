import { sql } from "drizzle-orm";
import { db } from "./db";

export type FeedPost = {
  id: string;
  caption: string;
  location: string | null;
  kind: string;
  category: string;
  is_reel: boolean;
  created_at: string;
  media_id: string | null;
  mime: string | null;
  user_id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
  verified_until: string | null;
  likes: number;
  comments: number;
  liked: boolean;
  saved: boolean;
};

type Scope = "home" | "explore" | "reels" | "profile" | "saved";

export async function getPosts(options: {
  viewerId: string;
  scope: Scope;
  profileId?: string;
  limit?: number;
  offset?: number;
}): Promise<FeedPost[]> {
  const { viewerId, scope, profileId } = options;
  const limit = Math.min(options.limit ?? 24, 48);
  const offset = options.offset ?? 0;

  let where = sql`true`;
  if (scope === "home") {
    where = sql`(p.user_id = ${viewerId} or exists (select 1 from follows f where f.follower_id = ${viewerId} and f.following_id = p.user_id))`;
  } else if (scope === "reels") {
    where = sql`p.is_reel = true`;
  } else if (scope === "profile") {
    where = sql`p.user_id = ${profileId ?? viewerId}`;
  } else if (scope === "saved") {
    where = sql`exists (select 1 from saves s where s.post_id = p.id and s.user_id = ${viewerId})`;
  }

  const result = await db.execute(sql`
    select
      p.id, p.caption, p.location, p.kind, p.category, p.is_reel, p.created_at,
      m.id as media_id, m.mime,
      u.id as user_id, u.name, u.username, u.display_username, u.image, u.verified, u.verified_until,
      (select count(*)::int from post_likes l where l.post_id = p.id) as likes,
      (select count(*)::int from comments c where c.post_id = p.id) as comments,
      exists (select 1 from post_likes l where l.post_id = p.id and l.user_id = ${viewerId}) as liked,
      exists (select 1 from saves s where s.post_id = p.id and s.user_id = ${viewerId}) as saved
    from posts p
    join "user" u on u.id = p.user_id
    left join media m on m.id = p.media_id
    where ${where}
    order by p.created_at desc
    limit ${limit} offset ${offset}
  `);
  return result.rows as unknown as FeedPost[];
}

export async function getPostById(postId: string, viewerId: string) {
  const result = await db.execute(sql`
    select
      p.id, p.caption, p.location, p.kind, p.category, p.is_reel, p.created_at,
      m.id as media_id, m.mime,
      u.id as user_id, u.name, u.username, u.display_username, u.image, u.verified, u.verified_until,
      (select count(*)::int from post_likes l where l.post_id = p.id) as likes,
      (select count(*)::int from comments c where c.post_id = p.id) as comments,
      exists (select 1 from post_likes l where l.post_id = p.id and l.user_id = ${viewerId}) as liked,
      exists (select 1 from saves s where s.post_id = p.id and s.user_id = ${viewerId}) as saved
    from posts p
    join "user" u on u.id = p.user_id
    left join media m on m.id = p.media_id
    where p.id = ${postId}
    limit 1
  `);
  return (result.rows[0] as unknown as FeedPost | undefined) ?? null;
}

export type ProfileRow = {
  id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  bio: string | null;
  website: string | null;
  verified: boolean;
  verified_until: string | null;
  is_private: boolean;
  followers: number;
  following: number;
  posts: number;
  is_following: boolean;
  follows_you: boolean;
  blocked: boolean;
};

export async function getProfile(username: string, viewerId: string) {
  const result = await db.execute(sql`
    select
      u.id, u.name, u.username, u.display_username, u.image, u.bio, u.website,
      u.verified, u.verified_until, u.is_private,
      (select count(*)::int from follows f where f.following_id = u.id) as followers,
      (select count(*)::int from follows f where f.follower_id = u.id) as following,
      (select count(*)::int from posts p where p.user_id = u.id) as posts,
      exists (select 1 from follows f where f.follower_id = ${viewerId} and f.following_id = u.id) as is_following,
      exists (select 1 from follows f where f.follower_id = u.id and f.following_id = ${viewerId}) as follows_you,
      exists (select 1 from blocked_users b where b.user_id = u.id and b.blocked_id = ${viewerId}) as blocked
    from "user" u
    where lower(u.username) = lower(${username})
    limit 1
  `);
  return (result.rows[0] as unknown as ProfileRow | undefined) ?? null;
}

export type StoryGroup = {
  user_id: string;
  name: string;
  username: string | null;
  display_username: string | null;
  image: string | null;
  verified: boolean;
  stories: {
    id: string;
    media_id: string | null;
    mime: string | null;
    caption: string;
    created_at: string;
    expires_at: string;
  }[];
};

export async function getStoryGroups(viewerId: string): Promise<StoryGroup[]> {
  const result = await db.execute(sql`
    select
      s.id, s.media_id, md.mime, s.caption, s.created_at, s.expires_at,
      u.id as user_id, u.name, u.username, u.display_username, u.image, u.verified
    from stories s
    join "user" u on u.id = s.user_id
    left join media md on md.id = s.media_id
    where s.expires_at > now()
      and (
        s.user_id = ${viewerId}
        or exists (select 1 from follows f where f.follower_id = ${viewerId} and f.following_id = s.user_id)
      )
    order by s.created_at asc
  `);

  const groups = new Map<string, StoryGroup>();
  for (const row of result.rows as unknown as (StoryGroup & {
    id: string;
    media_id: string | null;
    mime: string | null;
    caption: string;
    created_at: string;
    expires_at: string;
  })[]) {
    const existing = groups.get(row.user_id);
    const story = {
      id: row.id,
      media_id: row.media_id,
      mime: row.mime,
      caption: row.caption,
      created_at: row.created_at,
      expires_at: row.expires_at,
    };
    if (existing) {
      existing.stories.push(story);
    } else {
      groups.set(row.user_id, {
        user_id: row.user_id,
        name: row.name,
        username: row.username,
        display_username: row.display_username,
        image: row.image,
        verified: row.verified,
        stories: [story],
      });
    }
  }
  const list = Array.from(groups.values());
  return list.sort((a, b) => {
    if (a.user_id === viewerId) return -1;
    if (b.user_id === viewerId) return 1;
    return 0;
  });
}

export type ConversationRow = {
  id: string;
  other_id: string;
  other_name: string;
  other_username: string | null;
  other_image: string | null;
  other_verified: boolean;
  last_body: string | null;
  last_kind: string | null;
  last_at: string;
  unread: number;
};

export async function getConversations(viewerId: string): Promise<ConversationRow[]> {
  const result = await db.execute(sql`
    select
      c.id,
      other.id as other_id,
      other.name as other_name,
      other.username as other_username,
      other.image as other_image,
      other.verified as other_verified,
      lm.body as last_body,
      lm.kind as last_kind,
      coalesce(lm.created_at, c.last_message_at) as last_at,
      (
        select count(*)::int from messages m
        where m.conversation_id = c.id
          and m.sender_id <> ${viewerId}
          and m.created_at > cp.last_read_at
      ) as unread
    from conversations c
    join conversation_participants cp on cp.conversation_id = c.id and cp.user_id = ${viewerId}
    join conversation_participants op on op.conversation_id = c.id and op.user_id <> ${viewerId}
    join "user" other on other.id = op.user_id
    left join lateral (
      select m.body, m.kind, m.created_at from messages m
      where m.conversation_id = c.id order by m.created_at desc limit 1
    ) lm on true
    order by last_at desc
    limit 50
  `);
  return result.rows as unknown as ConversationRow[];
}

export type MessageRow = {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  media_id: string | null;
  mime: string | null;
  kind: string;
  duration_sec: number | null;
  created_at: string;
  sender_name: string;
  sender_image: string | null;
};

export async function getMessages(conversationId: string, limit = 100): Promise<MessageRow[]> {
  const result = await db.execute(sql`
    select m.id, m.conversation_id, m.sender_id, m.body, m.media_id, md.mime, m.kind,
           m.duration_sec, m.created_at, u.name as sender_name, u.image as sender_image
    from messages m
    join "user" u on u.id = m.sender_id
    left join media md on md.id = m.media_id
    where m.conversation_id = ${conversationId}
    order by m.created_at asc
    limit ${limit}
  `);
  return result.rows as unknown as MessageRow[];
}

export async function findDirectConversation(userA: string, userB: string) {
  const result = await db.execute(sql`
    select c.id from conversations c
    join conversation_participants a on a.conversation_id = c.id and a.user_id = ${userA}
    join conversation_participants b on b.conversation_id = c.id and b.user_id = ${userB}
    limit 1
  `);
  return (result.rows[0]?.id as string | undefined) ?? null;
}

export async function searchUsers(query: string, viewerId: string, limit = 20) {
  const q = `%${query.replace(/[%_]/g, "").toLowerCase()}%`;
  const result = await db.execute(sql`
    select u.id, u.name, u.username, u.display_username, u.image, u.verified, u.bio,
      exists (select 1 from follows f where f.follower_id = ${viewerId} and f.following_id = u.id) as is_following,
      (select count(*)::int from follows f where f.following_id = u.id) as followers
    from "user" u
    where u.id <> ${viewerId}
      and not exists (select 1 from blocked_users b where b.user_id = ${viewerId} and b.blocked_id = u.id)
      and (lower(u.username) like ${q} or lower(u.name) like ${q})
    order by followers desc, u.created_at asc
    limit ${limit}
  `);
  return result.rows as unknown as {
    id: string;
    name: string;
    username: string | null;
    display_username: string | null;
    image: string | null;
    verified: boolean;
    bio: string | null;
    is_following: boolean;
    followers: number;
  }[];
}

export async function suggestedUsers(viewerId: string, limit = 5) {
  const result = await db.execute(sql`
    select u.id, u.name, u.username, u.display_username, u.image, u.verified, u.bio,
      false as is_following,
      (select count(*)::int from follows f where f.following_id = u.id) as followers
    from "user" u
    where u.id <> ${viewerId}
      and not exists (select 1 from follows f where f.follower_id = ${viewerId} and f.following_id = u.id)
      and not exists (select 1 from blocked_users b where b.user_id = ${viewerId} and b.blocked_id = u.id)
    order by followers desc, u.created_at asc
    limit ${limit}
  `);
  return result.rows as unknown as {
    id: string;
    name: string;
    username: string | null;
    display_username: string | null;
    image: string | null;
    verified: boolean;
    bio: string | null;
    is_following: boolean;
    followers: number;
  }[];
}

export async function getComments(postId: string) {
  const result = await db.execute(sql`
    select c.id, c.body, c.created_at, u.id as user_id, u.name, u.username, u.display_username,
           u.image, u.verified
    from comments c
    join "user" u on u.id = c.user_id
    where c.post_id = ${postId}
    order by c.created_at asc
    limit 100
  `);
  return result.rows as unknown as {
    id: string;
    body: string;
    created_at: string;
    user_id: string;
    name: string;
    username: string | null;
    display_username: string | null;
    image: string | null;
    verified: boolean;
  }[];
}

export async function getNotifications(viewerId: string) {
  const result = await db.execute(sql`
    select n.id, n.type, n.read, n.created_at, n.post_id, n.conversation_id,
           a.id as actor_id, a.name as actor_name, a.username as actor_username, a.image as actor_image, a.verified as actor_verified,
           m.id as media_id
    from notifications n
    left join "user" a on a.id = n.actor_id
    left join posts p on p.id = n.post_id
    left join media m on m.id = p.media_id
    where n.user_id = ${viewerId}
    order by n.created_at desc
    limit 60
  `);
  return result.rows as unknown as {
    id: string;
    type: string;
    read: boolean;
    created_at: string;
    post_id: string | null;
    conversation_id: string | null;
    actor_id: string | null;
    actor_name: string | null;
    actor_username: string | null;
    actor_image: string | null;
    actor_verified: boolean | null;
    media_id: string | null;
  }[];
}
