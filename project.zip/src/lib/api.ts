"use client";

export class ApiError extends Error {
  code: string;
  status: number;
  constructor(code: string, status: number) {
    super(code);
    this.code = code;
    this.status = status;
  }
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...init?.headers,
    },
    cache: "no-store",
  });
  const contentType = response.headers.get("content-type") ?? "";
  const data = contentType.includes("application/json") ? await response.json() : null;
  if (!response.ok) {
    const code = (data as { error?: string } | null)?.error ?? "errors.generic";
    throw new ApiError(code, response.status);
  }
  return data as T;
}

export function errorMessage(error: unknown, t: (key: string) => string) {
  if (error instanceof ApiError) {
    const known = t(error.code);
    return known === error.code ? t("errors.generic") : known;
  }
  return t("errors.generic");
}
