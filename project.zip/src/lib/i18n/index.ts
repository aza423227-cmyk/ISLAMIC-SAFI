import en from "./locales/en";
import ar from "./locales/ar";
import fr from "./locales/fr";
import tr from "./locales/tr";
import ur from "./locales/ur";

export const locales = ["en", "ar", "fr", "tr", "ur"] as const;
export type Locale = (typeof locales)[number];

export const dictionaries: Record<Locale, Record<string, string>> = {
  en,
  ar,
  fr,
  tr,
  ur,
};

export const localeMeta: Record<
  Locale,
  { native: string; english: string; dir: "ltr" | "rtl"; flag: string }
> = {
  en: { native: "English", english: "English", dir: "ltr", flag: "EN" },
  ar: { native: "العربية", english: "Arabic", dir: "rtl", flag: "AR" },
  fr: { native: "Français", english: "French", dir: "ltr", flag: "FR" },
  tr: { native: "Türkçe", english: "Turkish", dir: "ltr", flag: "TR" },
  ur: { native: "اردو", english: "Urdu", dir: "rtl", flag: "UR" },
};

export const localeList = locales.map((code) => ({ code, ...localeMeta[code] }));

export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (locales as readonly string[]).includes(value);
}

export function detectLocale(acceptLanguage: string | null | undefined): Locale {
  if (!acceptLanguage) return "en";
  const tags = acceptLanguage
    .split(",")
    .map((part) => {
      const [tag, q] = part.trim().split(";q=");
      return { tag: tag.toLowerCase(), q: q ? Number(q) : 1 };
    })
    .sort((a, b) => b.q - a.q);
  for (const { tag } of tags) {
    const base = tag.split("-")[0];
    if (isLocale(base)) return base;
  }
  return "en";
}

export function translate(locale: Locale, key: string, vars?: Record<string, string>) {
  const value = dictionaries[locale]?.[key] ?? dictionaries.en[key] ?? key;
  if (!vars) return value;
  return Object.entries(vars).reduce(
    (acc, [name, replacement]) => acc.replaceAll(`{${name}}`, replacement),
    value,
  );
}

export function dirFor(locale: Locale): "ltr" | "rtl" {
  return localeMeta[locale].dir;
}

export function formatNumber(value: number, locale: Locale) {
  return new Intl.NumberFormat(locale === "ur" ? "ur-PK" : locale).format(value);
}

export function formatRelativeTime(
  date: Date | string | number,
  locale: Locale,
  now = Date.now(),
) {
  const value = new Date(date).getTime();
  const seconds = Math.max(1, Math.round((now - value) / 1000));
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (seconds < 60) return rtf.format(-seconds, "second");
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return rtf.format(-minutes, "minute");
  const hours = Math.round(minutes / 60);
  if (hours < 24) return rtf.format(-hours, "hour");
  const days = Math.round(hours / 24);
  if (days < 7) return rtf.format(-days, "day");
  const weeks = Math.round(days / 7);
  if (weeks < 5) return rtf.format(-weeks, "week");
  return new Intl.DateTimeFormat(locale, { month: "short", day: "numeric" }).format(
    new Date(value),
  );
}

export function formatTime(date: string | Date, locale: Locale, hour12 = true) {
  return new Intl.DateTimeFormat(locale === "ur" ? "ur-PK" : locale, {
    hour: "numeric",
    minute: "2-digit",
    hour12,
  }).format(new Date(date));
}

export function formatDate(date: string | Date, locale: Locale) {
  return new Intl.DateTimeFormat(locale === "ur" ? "ur-PK" : locale, {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(date));
}
