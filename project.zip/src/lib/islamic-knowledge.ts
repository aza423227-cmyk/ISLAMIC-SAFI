export type KnowledgeEntry = {
  id: string;
  keywords: string[];
  answers: Record<string, string>;
};

const disclaimer: Record<string, string> = {
  en: "This is general guidance from the Quran and authentic Sunnah, not a personal fatwa. For a ruling on your specific situation, please consult a qualified scholar.",
  ar: "هذه إرشادات عامة من القرآن والسنة الصحيحة، وليست فتوى شخصية. للحكم في حالتك الخاصة، يرجى استشارة عالم مؤهل.",
  fr: "Ceci est une guidance générale tirée du Coran et de la Sunna authentique, et non une fatwa personnelle. Pour une décision concernant votre situation, consultez un savant qualifié.",
  tr: "Bu, Kur'an ve sahih sünnetten genel bir rehberliktir; kişisel bir fetva değildir. Durumunuza özel bir hüküm için yetkin bir âlime danışın.",
  ur: "یہ قرآن اور صحیح سنت سے عام رہنمائی ہے، ذاتی فتویٰ نہیں۔ اپنی مخصوص صورتِ حال کے لیے کسی مستند عالم سے رجوع کریں۔",
};

export function disclaimerFor(locale: string) {
  return disclaimer[locale] ?? disclaimer.en;
}

export const knowledgeBase: KnowledgeEntry[] = [
  {
    id: "salam",
    keywords: ["salam", "salaam", "hello", "hi", "السلام", "سلام", "bonjour", "merhaba", "selam", "ہیلو"],
    answers: {
      en: "Wa alaikum assalam wa rahmatullahi wa barakatuh. Ask me about prayer, fasting, zakat, wudu, dua, or a hadith and I will answer with its source.",
      ar: "وعليكم السلام ورحمة الله وبركاته. اسألني عن الصلاة أو الصيام أو الزكاة أو الوضوء أو الدعاء أو حديث، وسأجيبك مع ذكر المصدر.",
      fr: "Wa alaikum assalam wa rahmatullahi wa barakatuh. Interrogez-moi sur la prière, le jeûne, la zakat, les ablutions, les invocations ou un hadith, et je répondrai avec sa source.",
      tr: "Ve aleykümselam ve rahmetullahi ve berekatüh. Bana namaz, oruç, zekât, abdest, dua veya bir hadis hakkında sorun; kaynağıyla yanıtlayayım.",
      ur: "وعلیکم السلام ورحمۃ اللہ وبرکاتہ۔ مجھ سے نماز، روزہ، زکوٰۃ، وضو، دعا یا حدیث کے بارے میں پوچھیں، میں ماخذ کے ساتھ جواب دوں گا۔",
    },
  },
  {
    id: "pillars",
    keywords: ["pillar", "pillars of islam", "five pillars", "arkaan", "أركان", "اركان الإسلام", "piliers", "islamın şartları", "ارکان اسلام"],
    answers: {
      en: "The Prophet ﷺ said: “Islam is built upon five: the testimony that there is no god but Allah and that Muhammad is His Messenger, establishing the prayer, giving zakat, fasting Ramadan, and pilgrimage to the House.” (Sahih al-Bukhari 8, Sahih Muslim 16)",
      ar: "قال النبي ﷺ: «بُني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمدًا رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان». (صحيح البخاري ٨، صحيح مسلم ١٦)",
      fr: "Le Prophète ﷺ a dit : « L'islam est bâti sur cinq : le témoignage qu'il n'y a de divinité qu'Allah et que Muhammad est Son Messager, l'accomplissement de la prière, la zakat, le jeûne du Ramadan et le pèlerinage. » (Sahih al-Bukhari 8, Sahih Muslim 16)",
      tr: "Peygamber ﷺ şöyle buyurdu: “İslam beş şey üzerine kurulmuştur: Allah'tan başka ilah olmadığına ve Muhammed'in O'nun elçisi olduğuna şehadet, namazı kılmak, zekâtı vermek, Ramazan orucu ve hac.” (Sahih Buhârî 8, Sahih Müslim 16)",
      ur: "نبی ﷺ نے فرمایا: ”اسلام پانچ چیزوں پر قائم ہے: اللہ کے سوا کوئی معبود نہ ہونے اور محمد ﷺ کے رسول ہونے کی گواہی، نماز قائم کرنا، زکوٰۃ دینا، رمضان کے روزے اور بیت اللہ کا حج۔“ (صحیح بخاری 8، صحیح مسلم 16)",
    },
  },
  {
    id: "prayer",
    keywords: ["how to pray", "salah", "salat", "namaz", "صلاة", "كيف أصلي", "prière", "priere", "namaz nasıl", "نماز کیسے"],
    answers: {
      en: "Pray as the Prophet ﷺ taught: face the Qiblah, say the takbir, recite Al-Fatihah, bow, prostrate, and complete the units with calm. He ﷺ said: “Pray as you have seen me praying.” (Sahih al-Bukhari 631). The Quran commands: “Establish prayer at the two ends of the day and in the first hours of the night.” (Quran 11:114)",
      ar: "صلِّ كما علّم النبي ﷺ: استقبل القبلة، وكبّر، واقرأ الفاتحة، واركع واسجد وأتم الركعات بخشوع. قال ﷺ: «صلوا كما رأيتموني أصلي». (صحيح البخاري ٦٣١). وقال تعالى: ﴿وَأَقِمِ الصَّلَاةَ طَرَفَيِ النَّهَارِ وَزُلَفًا مِّنَ اللَّيْلِ﴾ (هود: ١١٤)",
      fr: "Priez comme le Prophète ﷺ l'a enseigné : tournez-vous vers la Qibla, prononcez le takbir, récitez Al-Fatiha, inclinez-vous, prosternez-vous et accomplissez les unités avec sérénité. Il ﷺ a dit : « Priez comme vous m'avez vu prier. » (Sahih al-Bukhari 631)",
      tr: "Peygamber ﷺ'in öğrettiği gibi kılın: kıbleye yönelin, tekbir alın, Fatiha okuyun, rükû ve secde edin, rekâtları sükûnetle tamamlayın. O ﷺ şöyle buyurdu: “Beni nasıl namaz kılıyorsam öyle kılın.” (Sahih Buhârî 631)",
      ur: "نبی ﷺ کی تعلیم کے مطابق نماز پڑھیں: قبلہ کی طرف رخ کریں، تکبیر کہیں، فاتحہ پڑھیں، رکوع و سجود کریں اور رکعتیں سکون سے مکمل کریں۔ آپ ﷺ نے فرمایا: ”نماز ایسے پڑھو جیسے مجھے پڑھتے دیکھا ہے۔“ (صحیح بخاری 631)",
    },
  },
  {
    id: "wudu",
    keywords: ["wudu", "ablution", "وضوء", "الوضوء", "ablutions", "abdest", "وضو"],
    answers: {
      en: "Allah says: “O you who believe, when you rise for prayer, wash your faces and your hands up to the elbows, wipe your heads and wash your feet up to the ankles.” (Quran 5:6). Begin with the intention, say Bismillah, then wash in that order without wasting water.",
      ar: "قال تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ وَامْسَحُوا بِرُءُوسِكُمْ وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ﴾ (المائدة: ٦). ابدأ بالنية وقل بسم الله، ثم اغسل بهذا الترتيب دون إسراف في الماء.",
      fr: "Allah dit : « Ô vous qui croyez, lorsque vous vous levez pour la prière, lavez vos visages et vos mains jusqu'aux coudes, essuyez vos têtes et lavez vos pieds jusqu'aux chevilles. » (Coran 5:6)",
      tr: "Allah şöyle buyurur: “Ey iman edenler, namaza kalktığınızda yüzlerinizi ve dirseklere kadar ellerinizi yıkayın, başlarınızı mesh edin ve topuklara kadar ayaklarınızı yıkayın.” (Kur'an 5:6)",
      ur: "اللہ تعالیٰ فرماتا ہے: ”اے ایمان والو! جب تم نماز کے لیے اٹھو تو اپنے چہرے اور کہنیوں تک ہاتھ دھو لو، سر کا مسح کرو اور ٹخنوں تک پاؤں دھو لو۔“ (قرآن 5:6)",
    },
  },
  {
    id: "fasting",
    keywords: ["fast", "fasting", "ramadan", "صيام", "الصيام", "رمضان", "jeûne", "jeune", "oruç", "ramazan", "روزہ", "رمضان"],
    answers: {
      en: "Allah says: “O you who believe, fasting is prescribed for you as it was prescribed for those before you, so that you may attain taqwa.” (Quran 2:183). Fasting is from Fajr until Maghrib, with intention, abstaining from food, drink and intimacy.",
      ar: "قال تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا كُتِبَ عَلَيْكُمُ الصِّيَامُ كَمَا كُتِبَ عَلَى الَّذِينَ مِن قَبْلِكُمْ لَعَلَّكُمْ تَتَّقُونَ﴾ (البقرة: ١٨٣). الصيام من الفجر إلى المغرب، بنية، مع الإمساك عن الطعام والشراب والجماع.",
      fr: "Allah dit : « Ô vous qui croyez, le jeûne vous est prescrit comme il l'a été pour ceux avant vous, afin que vous atteigniez la taqwa. » (Coran 2:183). Le jeûne va du Fajr au Maghrib, avec l'intention.",
      tr: "Allah şöyle buyurur: “Ey iman edenler, sizden öncekilere farz kılındığı gibi size de oruç farz kılındı; umulur ki takvaya erersiniz.” (Kur'an 2:183). Oruç, niyetle imsaktan akşama kadar yemeden içmeden ve eşle ilişkiden uzak durmaktır.",
      ur: "اللہ تعالیٰ فرماتا ہے: ”اے ایمان والو! تم پر روزے فرض کیے گئے جیسے تم سے پہلے لوگوں پر فرض کیے گئے تھے، تاکہ تم تقویٰ اختیار کرو۔“ (قرآن 2:183)",
    },
  },
  {
    id: "zakat",
    keywords: ["zakat", "zakah", "charity", "صدقة", "الزكاة", "زكاة", "zakat", "zekât", "zekat", "زکوٰۃ", "زکات"],
    answers: {
      en: "Zakat is one of the five pillars, due on wealth that reaches the nisab and is held for a lunar year, at 2.5%. Allah specifies its recipients: “Charity is only for the poor, the needy, those employed to collect it, those whose hearts are to be reconciled, to free captives, the debt-ridden, in the cause of Allah, and the traveler.” (Quran 9:60)",
      ar: "الزكاة ركن من أركان الإسلام، تجب في المال الذي بلغ النصاب وحال عليه الحول، ومقدارها ٢٫٥٪. قال تعالى: ﴿إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ وَالْعَامِلِينَ عَلَيْهَا وَالْمُؤَلَّفَةِ قُلُوبُهُمْ وَفِي الرِّقَابِ وَالْغَارِمِينَ وَفِي سَبِيلِ اللَّهِ وَابْنِ السَّبِيلِ﴾ (التوبة: ٦٠)",
      fr: "La zakat est l'un des cinq piliers ; elle est due sur la richesse atteignant le nisab après une année lunaire, à 2,5 %. Allah précise ses bénéficiaires dans le Coran 9:60.",
      tr: "Zekât beş şarttan biridir; nisabı aşan ve üzerinden bir kameri yıl geçen maldan %2,5 olarak verilir. Allah, Kur'an 9:60'ta hak sahiplerini sayar.",
      ur: "زکوٰۃ اسلام کے پانچ ارکان میں سے ہے۔ نصاب تک پہنچنے اور سال گزرنے پر مال کا 2.5% واجب ہے۔ اللہ تعالیٰ نے قرآن 9:60 میں مستحقین بیان فرمائے ہیں۔",
    },
  },
  {
    id: "dua",
    keywords: ["dua", "supplication", "invocation", "دعاء", "الدعاء", "invocation", "dua", "دعا"],
    answers: {
      en: "Allah says: “And when My servants ask you about Me, I am near. I respond to the call of the caller when he calls upon Me.” (Quran 2:186). He also says: “Call upon Me; I will respond to you.” (Quran 40:60). Begin with praise of Allah and salawat upon the Prophet ﷺ.",
      ar: "قال تعالى: ﴿وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ﴾ (البقرة: ١٨٦). وقال: ﴿ادْعُونِي أَسْتَجِبْ لَكُمْ﴾ (غافر: ٦٠). ابدأ بحمد الله والصلاة على النبي ﷺ.",
      fr: "Allah dit : « Et quand Mes serviteurs t'interrogent sur Moi, Je suis proche. Je réponds à l'appel de celui qui M'appelle. » (Coran 2:186). « Invoquez-Moi, Je vous répondrai. » (Coran 40:60)",
      tr: "Allah şöyle buyurur: “Kullarım sana Beni sorarsa, şüphesiz Ben yakınım. Bana dua edenin duasına cevap veririm.” (Kur'an 2:186). “Bana dua edin, size cevap vereyim.” (Kur'an 40:60)",
      ur: "اللہ تعالیٰ فرماتا ہے: ”اور جب میرے بندے آپ سے میرے بارے میں پوچھیں تو میں قریب ہوں، پکارنے والے کی پکار کا جواب دیتا ہوں۔“ (قرآن 2:186) اور فرمایا: ”مجھے پکارو، میں تمہیں جواب دوں گا۔“ (قرآن 40:60)",
    },
  },
  {
    id: "repentance",
    keywords: ["repent", "repentance", "tawbah", "sin", "توبة", "التوبة", "ذنب", "repentir", "tövbe", "توبہ", "گناہ"],
    answers: {
      en: "Allah says: “Say: O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins.” (Quran 39:53). Sincere repentance means stopping the sin, regretting it, resolving not to return, and restoring any rights.",
      ar: "قال تعالى: ﴿قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَى أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا﴾ (الزمر: ٥٣). التوبة الصادقة: الإقلاع عن الذنب، والندم، والعزم على عدم العودة، ورد الحقوق.",
      fr: "Allah dit : « Dis : Ô Mes serviteurs qui avez commis des excès contre vous-mêmes, ne désespérez pas de la miséricorde d'Allah. Il pardonne tous les péchés. » (Coran 39:53). Le repentir sincère implique de cesser, regretter et ne pas y revenir.",
      tr: "Allah şöyle buyurur: “De ki: Ey kendilerine karşı aşırı giden kullarım, Allah'ın rahmetinden ümidinizi kesmeyin. Şüphesiz Allah bütün günahları bağışlar.” (Kur'an 39:53). Samimi tövbe, günahı bırakmak, pişman olmak ve bir daha dönmemeye karar vermektir.",
      ur: "اللہ تعالیٰ فرماتا ہے: ”کہہ دو: اے میرے بندو! جنہوں نے اپنی جانوں پر زیادتی کی، اللہ کی رحمت سے مایوس نہ ہو، بے شک اللہ سب گناہ معاف کر دیتا ہے۔“ (قرآن 39:53)",
    },
  },
  {
    id: "parents",
    keywords: ["parents", "mother", "father", "والدين", "الوالدين", "أمي", "parents", "mère", "père", "anne", "baba", "والدین", "ماں", "باپ"],
    answers: {
      en: "Allah says: “Your Lord has decreed that you worship none but Him, and that you be kind to parents… and say not to them a word of contempt, but speak to them a noble word.” (Quran 17:23). A man asked the Prophet ﷺ who deserved his good company most; he said: “Your mother, then your mother, then your mother, then your father.” (Sahih al-Bukhari 5971)",
      ar: "قال تعالى: ﴿وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا... وَلَا تَقُل لَّهُمَا أُفٍّ وَلَا تَنْهَرْهُمَا وَقُل لَّهُمَا قَوْلًا كَرِيمًا﴾ (الإسراء: ٢٣). وسُئل النبي ﷺ: من أحق الناس بحسن صحابتي؟ قال: «أمك، ثم أمك، ثم أمك، ثم أبوك». (صحيح البخاري ٥٩٧١)",
      fr: "Allah dit : « Ton Seigneur a décrété de n'adorer que Lui et d'être bienfaisant envers les parents… ne leur dis pas “fi” et ne les brusque pas. » (Coran 17:23). Le Prophète ﷺ a cité la mère trois fois avant le père (Sahih al-Bukhari 5971).",
      tr: "Allah şöyle buyurur: “Rabbin, yalnız O'na kulluk etmenizi ve ana babaya iyilik etmenizi emretti… Onlara öf bile deme, onları azarlama.” (Kur'an 17:23). Peygamber ﷺ anneyi üç kez, sonra babayı saydı (Sahih Buhârî 5971).",
      ur: "اللہ تعالیٰ فرماتا ہے: ”تیرے رب نے فیصلہ کیا کہ اس کے سوا کسی کی عبادت نہ کرو اور والدین کے ساتھ حسنِ سلوک کرو… انہیں اُف تک نہ کہو۔“ (قرآن 17:23) نبی ﷺ نے ماں کا ذکر تین بار اور پھر باپ کا فرمایا (صحیح بخاری 5971)",
    },
  },
  {
    id: "patience",
    keywords: ["patience", "hardship", "anxiety", "sabr", "صبر", "الهم", "قلق", "patience", "épreuve", "sabır", "sıkıntı", "صبر", "پریشانی"],
    answers: {
      en: "Allah says: “O you who believe, seek help through patience and prayer. Indeed, Allah is with the patient.” (Quran 2:153). And: “Indeed, with hardship comes ease.” (Quran 94:6). Pair patience with dua and trust in Allah's wisdom.",
      ar: "قال تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ﴾ (البقرة: ١٥٣). وقال: ﴿إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾ (الشرح: ٦). اجمع الصبر مع الدعاء والتوكل على حكمة الله.",
      fr: "Allah dit : « Ô vous qui croyez, cherchez secours dans la patience et la prière. Allah est avec les patients. » (Coran 2:153). « Avec la difficulté vient la facilité. » (Coran 94:6)",
      tr: "Allah şöyle buyurur: “Ey iman edenler, sabır ve namazla yardım dileyin. Şüphesiz Allah sabredenlerle beraberdir.” (Kur'an 2:153). “Şüphesiz zorlukla beraber kolaylık vardır.” (Kur'an 94:6)",
      ur: "اللہ تعالیٰ فرماتا ہے: ”اے ایمان والو! صبر اور نماز سے مدد لو، بے شک اللہ صبر کرنے والوں کے ساتھ ہے۔“ (قرآن 2:153) ”بے شک مشکل کے ساتھ آسانی ہے۔“ (قرآن 94:6)",
    },
  },
  {
    id: "hadith-intentions",
    keywords: ["intention", "niyyah", "hadith intentions", "نية", "النية", "intention", "niyet", "نیت"],
    answers: {
      en: "The Prophet ﷺ said: “Actions are only by intentions, and every person will have only what he intended.” (Sahih al-Bukhari 1, Sahih Muslim 1907). Renew your intention before acts of worship and turn ordinary habits into rewarded deeds.",
      ar: "قال النبي ﷺ: «إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى». (صحيح البخاري ١، صحيح مسلم ١٩٠٧). جدّد النية قبل العبادات، وحوّل عاداتك إلى أعمال تُؤجر عليها.",
      fr: "Le Prophète ﷺ a dit : « Les actes ne valent que par les intentions, et chacun n'aura que ce qu'il a eu l'intention de faire. » (Sahih al-Bukhari 1, Sahih Muslim 1907).",
      tr: "Peygamber ﷺ şöyle buyurdu: “Ameller niyetlere göredir ve herkese ancak niyet ettiği vardır.” (Sahih Buhârî 1, Sahih Müslim 1907)",
      ur: "نبی ﷺ نے فرمایا: ”اعمال کا دارومدار نیتوں پر ہے اور ہر شخص کو وہی ملے گا جس کی اس نے نیت کی۔“ (صحیح بخاری 1، صحیح مسلم 1907)",
    },
  },
  {
    id: "knowledge",
    keywords: ["knowledge", "learn", "study", "علم", "طلب العلم", "science", "connaissance", "ilim", "علم", "تعلیم"],
    answers: {
      en: "Allah says: “My Lord, increase me in knowledge.” (Quran 20:114). The Prophet ﷺ said: “Whoever treads a path seeking knowledge, Allah makes easy for him a path to Paradise.” (Sahih Muslim 2699). Seek it sincerely and act upon it.",
      ar: "قال تعالى: ﴿وَقُل رَّبِّ زِدْنِي عِلْمًا﴾ (طه: ١١٤). وقال النبي ﷺ: «من سلك طريقًا يطلب فيه علمًا سلك الله به طريقًا من طرق الجنة». (صحيح مسلم ٢٦٩٩). اطلب العلم بإخلاص واعمل به.",
      fr: "Allah dit : « Mon Seigneur, augmente-moi en science. » (Coran 20:114). Le Prophète ﷺ a dit : « Celui qui emprunte un chemin à la recherche du savoir, Allah lui facilite un chemin vers le Paradis. » (Sahih Muslim 2699)",
      tr: "Allah şöyle buyurur: “Rabbim, ilmimi artır.” (Kur'an 20:114). Peygamber ﷺ şöyle buyurdu: “Kim ilim öğrenmek için bir yola girerse, Allah ona cennete giden bir yol kolaylaştırır.” (Sahih Müslim 2699)",
      ur: "اللہ تعالیٰ فرماتا ہے: ”اے میرے رب! میرے علم میں اضافہ فرما۔“ (قرآن 20:114) نبی ﷺ نے فرمایا: ”جو علم کی تلاش میں راستہ اختیار کرے، اللہ اس کے لیے جنت کا راستہ آسان کر دیتا ہے۔“ (صحیح مسلم 2699)",
    },
  },
  {
    id: "music",
    keywords: ["music", "song", "listening", "موسيقى", "أغاني", "musique", "müzik", "موسیقی", "گانا"],
    answers: {
      en: "Scholars differ on music. The majority of classical scholars held that musical instruments are impermissible, citing Quran 31:6 (“idle talk”) and the hadith in Sahih al-Bukhari 5590; others permit certain forms. Islamic Bessafi blocks music by policy, while nasheed without instruments is allowed. For your personal case, ask a qualified scholar.",
      ar: "اختلف العلماء في الموسيقى. ذهب جمهور العلماء المتقدمين إلى تحريم آلات اللهو، استدلالًا بقوله تعالى في ﴿لَهْوِ الْحَدِيثِ﴾ (لقمان: ٦) وبحديث في صحيح البخاري (٥٥٩٠)، وخالفهم آخرون في بعض الصور. يمنع تطبيق إسلاميك بيسافي الموسيقى التزامًا بسياسة المحتوى، ويسمح بالأناشيد دون آلات. لحالتك الشخصية، اسأل عالمًا مؤهلًا.",
      fr: "Les savants divergent sur la musique. La majorité des classiques l'ont jugée illicite avec instruments, citant Coran 31:6 et Sahih al-Bukhari 5590 ; d'autres permettent certaines formes. Islamic Bessafi bloque la musique par politique et autorise le nasheed sans instruments. Consultez un savant pour votre cas.",
      tr: "Âlimler müzik konusunda ihtilaf etmiştir. Klasik âlimlerin çoğu enstrümanlı müziği caiz görmemiş, Kur'an 31:6 ve Sahih Buhârî 5590'a dayanmıştır; bazıları belirli türlere izin vermiştir. Islamic Bessafi politikası gereği müziği engeller, enstrümansız ilahiye izin verir.",
      ur: "علماء موسیقی کے بارے میں مختلف ہیں۔ اکثر کلاسیکی علماء نے آلاتِ موسیقی کو ناجائز کہا، قرآن 31:6 اور صحیح بخاری 5590 کی بنیاد پر؛ بعض نے کچھ صورتوں کی اجازت دی۔ اسلامک بیسافی پالیسی کے تحت موسیقی بلاک کرتا ہے اور بغیر آلات کے نعت کی اجازت دیتا ہے۔ اپنی صورت کے لیے عالم سے رجوع کریں۔",
    },
  },
  {
    id: "fallback",
    keywords: [],
    answers: {
      en: "I can help with the pillars of Islam, prayer, wudu, fasting, zakat, dua, repentance, patience, parents, hadith, and seeking knowledge. Ask a specific question and I will quote the Quran or an authentic hadith with its source.",
      ar: "يمكنني المساعدة في أركان الإسلام، والصلاة، والوضوء، والصيام، والزكاة، والدعاء، والتوبة، والصبر، وبر الوالدين، والحديث، وطلب العلم. اطرح سؤالًا محددًا وسأذكر آية أو حديثًا صحيحًا مع مصدره.",
      fr: "Je peux aider sur les piliers de l'islam, la prière, les ablutions, le jeûne, la zakat, les invocations, le repentir, la patience, les parents, les hadiths et la recherche du savoir. Posez une question précise.",
      tr: "İslam'ın şartları, namaz, abdest, oruç, zekât, dua, tövbe, sabır, anne-baba, hadis ve ilim öğrenme konularında yardımcı olabilirim. Belirli bir soru sorun.",
      ur: "میں اسلام کے ارکان، نماز، وضو، روزہ، زکوٰۃ، دعا، توبہ، صبر، والدین، حدیث اور علم حاصل کرنے کے بارے میں مدد کر سکتا ہوں۔ کوئی مخصوص سوال پوچھیں۔",
    },
  },
];

function normalize(text: string) {
  return text
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function answerIslamicQuestion(question: string, locale: string) {
  const value = normalize(question);
  let best: { entry: KnowledgeEntry; score: number } | null = null;
  for (const entry of knowledgeBase) {
    if (entry.id === "fallback") continue;
    let score = 0;
    for (const keyword of entry.keywords) {
      const normalized = normalize(keyword);
      if (!normalized) continue;
      if (normalized.includes(" ")) {
        if (value.includes(normalized)) score += 2;
      } else if (new RegExp(`(^|\\s)${normalized}(\\s|$)`).test(value)) {
        score += 1;
      }
    }
    if (score > 0 && (!best || score > best.score)) best = { entry, score };
  }
  const entry = best?.entry ?? knowledgeBase[knowledgeBase.length - 1];
  const answer = entry.answers[locale] ?? entry.answers.en;
  const needsDisclaimer = entry.id !== "salam" && entry.id !== "fallback";
  return {
    id: entry.id,
    answer: needsDisclaimer ? `${answer}\n\n${disclaimerFor(locale)}` : answer,
  };
}
