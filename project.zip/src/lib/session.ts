import { headers } from "next/headers";
import { auth } from "./auth";

export type SessionUser = {
  id: string;
  name: string;
  email: string;
  image: string | null;
  username: string | null;
  displayUsername: string | null;
  bio: string | null;
  website: string | null;
  isPrivate: boolean | null;
  verified: boolean | null;
  verifiedUntil: Date | null;
  language: string | null;
};

export async function getSessionUser(): Promise<SessionUser | null> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) return null;
  return session.user as unknown as SessionUser;
}

export function isVerified(user: {
  verified?: boolean | null;
  verifiedUntil?: Date | string | null;
}) {
  if (!user.verified) return false;
  if (!user.verifiedUntil) return true;
  return new Date(user.verifiedUntil).getTime() > Date.now();
}
