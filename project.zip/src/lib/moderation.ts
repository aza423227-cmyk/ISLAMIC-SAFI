export type ModerationResult =
  | { ok: true }
  | { ok: false; reason: "music" | "explicit" };

const latinBanned = [
  "music",
  "musical",
  "song",
  "songs",
  "instrument",
  "instruments",
  "guitar",
  "piano",
  "violin",
  "drums",
  "concert",
  "playlist",
  "spotify",
  "soundcloud",
  "karaoke",
  "hiphop",
  "hip hop",
  "hip-hop",
  "rap music",
  "nightclub",
  "night club",
  "musique",
  "chanson",
  "chansons",
  "müzik",
  "şarkı",
  "sarki",
  "muzik",
  "porn",
  "porno",
  "nude",
  "nudes",
  "xxx",
  "onlyfans",
];

const nonLatinBanned = [
  "موسيقى",
  "موسيقية",
  "أغنية",
  "أغاني",
  "اغنية",
  "اغاني",
  "موسيقار",
  "موسيقى صاخبة",
  "رقص",
  "ملهى",
  "موسقی",
  "گانا",
  "گانے",
  "گیت",
  "موسیقی",
  "فحش",
];

const explicitTerms = ["porn", "porno", "nude", "nudes", "xxx", "onlyfans", "فحش"];

function normalize(text: string) {
  return text
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function moderateText(text: string | null | undefined): ModerationResult {
  if (!text) return { ok: true };
  const value = normalize(text);
  if (!value) return { ok: true };
  if (explicitTerms.some((term) => value.includes(term) || text.toLowerCase().includes(term))) {
    return { ok: false, reason: "explicit" };
  }
  for (const term of latinBanned) {
    const normalized = normalize(term);
    if (!normalized) continue;
    const pattern = new RegExp(`(^|\\s)${normalized.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")}(\\s|$)`);
    if (pattern.test(value)) return { ok: false, reason: "music" };
  }
  for (const term of nonLatinBanned) {
    if (text.includes(term) || value.includes(normalize(term))) {
      return { ok: false, reason: "music" };
    }
  }
  return { ok: true };
}

export const ALLOWED_CONTENT_CATEGORIES = ["islamic", "quran", "nasheed", "education"] as const;
export type ContentCategory = (typeof ALLOWED_CONTENT_CATEGORIES)[number];

export function isContentCategory(value: unknown): value is ContentCategory {
  return typeof value === "string" && (ALLOWED_CONTENT_CATEGORIES as readonly string[]).includes(value);
}

export function isAllowedMime(mime: string) {
  return (
    mime.startsWith("image/") ||
    mime === "video/mp4" ||
    mime === "video/webm" ||
    mime === "video/quicktime" ||
    mime === "audio/webm" ||
    mime === "audio/mp4" ||
    mime === "audio/mpeg" ||
    mime === "audio/ogg" ||
    mime === "audio/wav"
  );
}

export function mediaKindFor(mime: string): "image" | "video" | "audio" {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  return "audio";
}

export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
export const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
export const MAX_AUDIO_BYTES = 12 * 1024 * 1024;
