import { NextResponse } from "next/server";

export function apiError(code: string, status = 400) {
  return NextResponse.json({ error: code }, { status });
}

export const unauthorized = () => apiError("errors.unauthorized", 401);
export const notFound = () => apiError("errors.notFound", 404);
export const badRequest = (code = "errors.invalid") => apiError(code, 400);

export async function readJson(request: Request): Promise<Record<string, unknown>> {
  try {
    const data = await request.json();
    if (data && typeof data === "object") return data as Record<string, unknown>;
    return {};
  } catch {
    return {};
  }
}

export function str(value: unknown, max = 2000) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

export function bool(value: unknown) {
  return value === true || value === "true";
}

export function mediaUrl(id: string | null | undefined) {
  return id ? `/api/media/${id}` : null;
}
