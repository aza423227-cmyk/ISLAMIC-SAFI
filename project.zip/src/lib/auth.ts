import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { username } from "better-auth/plugins";
import { eq } from "drizzle-orm";
import { db } from "./db";
import * as schema from "./schema";
import * as authSchema from "./auth-schema";

const isProduction = process.env.NODE_ENV === "production";

export const auth = betterAuth({
  secret: process.env.BETTER_AUTH_SECRET,
  database: drizzleAdapter(db, {
    provider: "pg",
    schema: { ...authSchema, ...schema },
  }),
  emailAndPassword: {
    enabled: true,
    minPasswordLength: 8,
    autoSignIn: true,
  },
  user: {
    additionalFields: {
      bio: { type: "string", required: false, defaultValue: "" },
      website: { type: "string", required: false, defaultValue: "" },
      isPrivate: { type: "boolean", required: false, defaultValue: false },
      verified: { type: "boolean", required: false, defaultValue: false },
      verifiedUntil: { type: "date", required: false },
      language: { type: "string", required: false, defaultValue: "en" },
    },
  },
  plugins: [
    username({
      minUsernameLength: 3,
      maxUsernameLength: 30,
    }),
  ],
  session: {
    expiresIn: 60 * 60 * 24 * 30,
    updateAge: 60 * 60 * 24,
  },
  databaseHooks: {
    user: {
      create: {
        after: async (createdUser) => {
          try {
            if (createdUser.username === "islamicbessafi") return;
            const community = await db.query.user.findFirst({
              where: eq(authSchema.user.username, "islamicbessafi"),
            });
            if (!community) return;
            await db
              .insert(schema.follows)
              .values({ followerId: createdUser.id, followingId: community.id })
              .onConflictDoNothing();
            const [conversation] = await db
              .insert(schema.conversations)
              .values({ lastMessageAt: new Date() })
              .returning();
            await db.insert(schema.conversationParticipants).values([
              { conversationId: conversation.id, userId: createdUser.id },
              { conversationId: conversation.id, userId: community.id },
            ]);
            await db.insert(schema.messages).values({
              conversationId: conversation.id,
              senderId: community.id,
              body: "Assalamu alaikum wa rahmatullahi wa barakatuh. Welcome to Islamic Bessafi. Explore the Quran library, prayer times and the Islamic assistant. May Allah bless your journey.",
            });
            await db.insert(schema.notifications).values({
              userId: createdUser.id,
              actorId: community.id,
              type: "message",
              conversationId: conversation.id,
            });
          } catch (error) {
            console.error("Welcome setup failed", error);
          }
        },
      },
    },
  },
  ...(isProduction
    ? {
        baseURL: process.env.BETTER_AUTH_URL,
      }
    : {
        baseURL: {
          allowedHosts: [
            "*",
            "*.e2b.dev",
            "*.e2b.app",
            "*.ideavo.ai",
            "*.vercel.app",
            "localhost:*",
            "127.0.0.1:*",
          ],
          fallback: process.env.BETTER_AUTH_URL,
        },
        advanced: {
          defaultCookieAttributes: {
            sameSite: "none" as const,
            secure: true,
            partitioned: true,
          },
        },
      }),
  trustedOrigins: ["*"],
});
