import crypto from "crypto";
import { eq, sql } from "drizzle-orm";
import { auth } from "./auth";
import { db } from "./db";
import {
  comments,
  follows,
  media,
  postLikes,
  posts,
  stories,
  user,
} from "./schema";

type Theme = {
  from: string;
  via: string;
  to: string;
  accent: string;
};

const THEMES: Theme[] = [
  { from: "#0f1f1a", via: "#1c3b31", to: "#0a0f12", accent: "#e7d9b4" },
  { from: "#1a1410", via: "#3a2c1c", to: "#0f0b08", accent: "#f0e3c6" },
  { from: "#101827", via: "#1d2f45", to: "#0a0f18", accent: "#dfe7f2" },
  { from: "#221018", via: "#3b1c29", to: "#120a0e", accent: "#f2dfe3" },
];

function escapeXml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function pattern(index: number) {
  return `<pattern id="p" width="120" height="120" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
    <rect width="120" height="120" fill="none"/>
    <path d="M60 0 L120 60 L60 120 L0 60 Z" fill="none" stroke="#c8a45c" stroke-opacity="0.14" stroke-width="1.5"/>
    <circle cx="60" cy="60" r="18" fill="none" stroke="#c8a45c" stroke-opacity="0.10" stroke-width="1"/>
    <path d="M0 0 L120 120 M120 0 L0 120" stroke="#c8a45c" stroke-opacity="0.06" stroke-width="1"/>
  </pattern>`;
}

function artwork({
  arabic,
  english,
  source,
  index,
  size = 1080,
}: {
  arabic: string;
  english: string;
  source: string;
  index: number;
  size?: number;
}) {
  const theme = THEMES[index % THEMES.length];
  const center = size / 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${theme.from}"/>
      <stop offset="55%" stop-color="${theme.via}"/>
      <stop offset="100%" stop-color="${theme.to}"/>
    </linearGradient>
    ${pattern(index)}
  </defs>
  <rect width="${size}" height="${size}" fill="url(#bg)"/>
  <rect width="${size}" height="${size}" fill="url(#p)"/>
  <circle cx="${center}" cy="${center * 0.42}" r="${size * 0.30}" fill="#c8a45c" opacity="0.05"/>
  <text x="${center}" y="${center * 0.44}" text-anchor="middle" font-family="Amiri, 'Noto Naskh Arabic', serif" font-size="${size * 0.062}" fill="${theme.accent}" opacity="0.85" direction="rtl">${escapeXml(arabic)}</text>
  <line x1="${center - 70}" y1="${center * 0.78}" x2="${center + 70}" y2="${center * 0.78}" stroke="#c8a45c" stroke-opacity="0.7" stroke-width="2"/>
  <text x="${center}" y="${center * 0.94}" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="${size * 0.036}" fill="${theme.accent}" opacity="0.92">${escapeXml(english)}</text>
  <text x="${center}" y="${center * 1.32}" text-anchor="middle" font-family="Georgia, serif" font-size="${size * 0.026}" fill="#c8a45c" opacity="0.9">${escapeXml(source)}</text>
  <text x="${center}" y="${size * 0.94}" text-anchor="middle" font-family="Georgia, serif" font-size="${size * 0.021}" letter-spacing="6" fill="#c8a45c" opacity="0.55">ISLAMIC BESSAFI</text>
</svg>`;
}

function avatarArt(initials: string, index: number) {
  const theme = THEMES[index % THEMES.length];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
  <defs><linearGradient id="a" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="${theme.from}"/><stop offset="100%" stop-color="${theme.via}"/>
  </linearGradient></defs>
  <rect width="400" height="400" fill="url(#a)"/>
  <circle cx="200" cy="200" r="140" fill="none" stroke="#c8a45c" stroke-opacity="0.35" stroke-width="2"/>
  <circle cx="200" cy="200" r="118" fill="none" stroke="#c8a45c" stroke-opacity="0.18" stroke-width="1"/>
  <text x="200" y="232" text-anchor="middle" font-family="Georgia, serif" font-size="120" fill="#e7d9b4">${escapeXml(initials)}</text>
</svg>`;
}

const accounts = [
  {
    email: "bessafi@islamicbessafi.app",
    name: "ISLAMIC BESSAFI",
    username: "islamicbessafi",
    bio: "A calm, halal space for the Ummah. Quran, authentic reminders and everyday guidance.",
    verified: true,
    initials: "IB",
  },
  {
    email: "quran@islamicbessafi.app",
    name: "Quran Daily",
    username: "quran_daily",
    bio: "A verse to light your day. Translations from the Quran.",
    verified: true,
    initials: "QD",
  },
  {
    email: "fiqh@islamicbessafi.app",
    name: "Fiqh Notes",
    username: "fiqh_notes",
    bio: "Everyday fiqh with authentic sources. Not a fatwa service.",
    verified: false,
    initials: "FN",
  },
  {
    email: "nasheed@islamicbessafi.app",
    name: "Nasheed Light",
    username: "nasheed_light",
    bio: "Nasheeds without instruments, reflections and reminders.",
    verified: true,
    initials: "NL",
  },
];

const postSeeds = [
  {
    account: 1,
    arabic: "وَإِنَّ مَعَ الْعُسْرِ يُسْرًا",
    english: "Indeed, with hardship comes ease.",
    source: "Quran 94:6",
    caption:
      "Allah pairs every hardship with ease. Hold on to hope, keep your prayer, and trust His wisdom.\n\n#Quran #Hope #Sabr",
    category: "quran",
  },
  {
    account: 1,
    arabic: "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ",
    english: "Verily, in the remembrance of Allah do hearts find rest.",
    source: "Quran 13:28",
    caption: "A gentle reminder for a restless heart. Begin your dhikr today.\n\n#Dhikr #Tasbih",
    category: "quran",
  },
  {
    account: 2,
    arabic: "وَقُل رَّبِّ زِدْنِي عِلْمًا",
    english: "My Lord, increase me in knowledge.",
    source: "Quran 20:114",
    caption:
      "Knowledge is light. Learn something beneficial today and teach it to someone else.\n\n#Knowledge #Islam",
    category: "education",
  },
  {
    account: 1,
    arabic: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ",
    english: "Actions are judged by intentions.",
    source: "Sahih al-Bukhari 1",
    caption:
      "Renew your intention before every deed. A small act with a sincere intention becomes immense.\n\n#Hadith #Niyyah",
    category: "islamic",
  },
  {
    account: 2,
    arabic: "فَاذْكُرُونِي أَذْكُرْكُمْ",
    english: "So remember Me; I will remember you.",
    source: "Quran 2:152",
    caption: "What a mercy: when we remember Him, He remembers us.\n\n#Quran #Reminder",
    category: "quran",
  },
  {
    account: 3,
    arabic: "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
    english: "Allah does not burden a soul beyond what it can bear.",
    source: "Quran 2:286",
    caption:
      "You are not alone in your struggle. Pray, seek help, and take one step at a time.\n\n#Sabr #Hope",
    category: "islamic",
  },
  {
    account: 4,
    arabic: "وَقُولُوا لِلنَّاسِ حُسْنًا",
    english: "And speak to people good words.",
    source: "Quran 2:83",
    caption:
      "Kind speech is charity. Guard your tongue and leave a gentle trace today.\n\n#Adab #Kindness",
    category: "islamic",
  },
  {
    account: 3,
    arabic: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
    english: "Indeed, Allah is with the patient.",
    source: "Quran 2:153",
    caption:
      "Patience is not passive. It is steady trust while you keep doing good.\n\n#Sabr #Tawakkul",
    category: "quran",
  },
];

const commentSeeds = [
  "MashaAllah, this brought peace to my heart.",
  "Jazak Allahu khayran for sharing.",
  "A beautiful reminder. May Allah reward you.",
  "I needed this today, alhamdulillah.",
];

async function insertMedia(ownerId: string, mime: string, bytes: Buffer, kind = "image") {
  const [row] = await db
    .insert(media)
    .values({ ownerId, mime, kind, bytes: bytes.length, data: bytes })
    .returning({ id: media.id });
  return row.id;
}

async function main() {
  const existing = await db.query.user.findFirst({
    where: sql`lower(${user.username}) = 'islamicbessafi'`,
  });
  if (existing) {
    console.log("Seed skipped: Islamic Bessafi community already exists.");
    process.exit(0);
  }

  console.log("Creating community accounts…");
  const created: { id: string; username: string }[] = [];

  for (const [index, account] of accounts.entries()) {
    const result = await auth.api.signUpEmail({
      body: {
        email: account.email,
        password: crypto.randomBytes(24).toString("base64url"),
        name: account.name,
        username: account.username,
        displayUsername: account.username,
      },
      headers: new Headers({
        host: "localhost:4000",
        origin: "http://localhost:4000",
      }),
    });
    const userId = result.user.id;
    const avatarId = await insertMedia(
      userId,
      "image/svg+xml",
      Buffer.from(avatarArt(account.initials, index)),
    );
    await db
      .update(user)
      .set({
        image: `/api/media/${avatarId}`,
        bio: account.bio,
        verified: account.verified,
        verifiedUntil: account.verified
          ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          : null,
        emailVerified: true,
        updatedAt: new Date(),
      })
      .where(eq(user.id, userId));
    created.push({ id: userId, username: account.username });
    console.log(`  @${account.username}`);
  }

  console.log("Publishing posts…");
  const postIds: string[] = [];
  for (const [index, seed] of postSeeds.entries()) {
    const author = created[seed.account - 1];
    const mediaId = await insertMedia(
      author.id,
      "image/svg+xml",
      Buffer.from(
        artwork({
          arabic: seed.arabic,
          english: seed.english,
          source: seed.source,
          index,
        }),
      ),
    );
    const [post] = await db
      .insert(posts)
      .values({
        userId: author.id,
        mediaId,
        caption: seed.caption,
        category: seed.category,
        kind: "image",
        createdAt: new Date(Date.now() - (index + 1) * 7 * 60 * 60 * 1000),
      })
      .returning({ id: posts.id });
    postIds.push(post.id);

    for (const [likeIndex, other] of created.entries()) {
      if (other.id === author.id) continue;
      if ((index + likeIndex) % 2 === 0) {
        await db
          .insert(postLikes)
          .values({ postId: post.id, userId: other.id })
          .onConflictDoNothing();
      }
    }

    if (index % 2 === 0) {
      const commenter = created[(seed.account + 1) % created.length];
      await db.insert(comments).values({
        postId: post.id,
        userId: commenter.id,
        body: commentSeeds[index % commentSeeds.length],
        createdAt: new Date(Date.now() - (index + 1) * 6 * 60 * 60 * 1000),
      });
    }
  }

  console.log("Following…");
  for (const follower of created) {
    for (const following of created) {
      if (follower.id === following.id) continue;
      await db
        .insert(follows)
        .values({ followerId: follower.id, followingId: following.id })
        .onConflictDoNothing();
    }
  }

  console.log("Adding stories…");
  const storySeeds = [
    {
      account: 1,
      arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
      english: "Glory be to Allah and praise Him.",
      source: "Daily dhikr",
      caption: "A quiet moment of dhikr.",
    },
    {
      account: 2,
      arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً",
      english: "Our Lord, give us good in this world.",
      source: "Quran 2:201",
      caption: "A dua for your day.",
    },
    {
      account: 3,
      arabic: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
      english: "O Allah, send blessings upon Muhammad.",
      source: "Salah upon the Prophet ﷺ",
      caption: "Send salawat today.",
    },
  ];

  for (const [index, seed] of storySeeds.entries()) {
    const author = created[seed.account - 1];
    const mediaId = await insertMedia(
      author.id,
      "image/svg+xml",
      Buffer.from(
        artwork({
          arabic: seed.arabic,
          english: seed.english,
          source: seed.source,
          index: index + 4,
          size: 1080,
        }),
      ),
    );
    await db.insert(stories).values({
      userId: author.id,
      mediaId,
      caption: seed.caption,
      createdAt: new Date(Date.now() - (index + 1) * 40 * 60 * 1000),
      expiresAt: new Date(Date.now() + 20 * 60 * 60 * 1000),
    });
  }

  console.log(`Seed complete: ${created.length} accounts, ${postIds.length} posts.`);
  process.exit(0);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
